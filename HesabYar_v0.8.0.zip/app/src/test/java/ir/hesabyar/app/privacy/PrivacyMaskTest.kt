package ir.hesabyar.app.privacy

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrivacyMaskTest {
    @Test fun cardNumberPlain_isMasked_keepingLast4() {
        val out = PrivacyMask.mask("خرید با کارت 6037991234567890 مبلغ 250,000")
        assertFalse(out.contains("6037991234567890")); assertTrue(out.contains("7890")); assertTrue(out.contains("250,000"))
    }

    @Test fun cardNumberGroupedAndPersianDigits() {
        assertEquals("کارت ****-****-****-7890", PrivacyMask.mask("کارت 6037-9912-3456-7890"))
        assertEquals("کارت ****-****-****-7890", PrivacyMask.mask("کارت ۶۰۳۷ ۹۹۱۲ ۳۴۵۶ ۷۸۹۰"))
    }

    @Test fun iban_isMasked() {
        val out = PrivacyMask.mask("شبا IR123456789012345678901234 واریز")
        assertFalse(out.contains("IR1234")); assertTrue(out.endsWith("واریز")); assertTrue(out.contains("1234 ") || out.contains("234"))
    }

    @Test fun melliSample_isUntouched() {
        val s = "بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03"
        assertEquals(s, PrivacyMask.mask(s))
    }

    @Test fun ordinaryNumbersAreNotMasked() {
        val s = "مبلغ 1000000 ریال کد 123456 ساعت 18:03"
        assertEquals(s, PrivacyMask.mask(s))
    }
}
