package ir.hesabyar.app.parser

import org.junit.Assert.assertEquals
import org.junit.Test

class TextNormalizerTest {
    @Test fun digitsAllScriptsBecomeLatin() {
        assertEquals("0123456789", TextNormalizer.normalize("۰۱۲۳۴۵۶۷۸۹"))
        assertEquals("0123456789", TextNormalizer.normalize("٠١٢٣٤٥٦٧٨٩"))
        assertEquals("0123456789", TextNormalizer.normalize("0123456789"))
    }

    @Test fun arabicLettersBecomePersian() {
        assertEquals("بانک ملی ایران", TextNormalizer.normalize("بانك ملي ايران"))
        assertEquals("ی", TextNormalizer.normalize("ى")) // alef maksura
    }

    @Test fun separatorsAndSigns() {
        assertEquals("1,234.5", TextNormalizer.normalize("۱٬۲۳۴٫۵"))
        assertEquals("1,234", TextNormalizer.normalize("1،234"))
        assertEquals("-5+5-5", TextNormalizer.normalize("−5+5–5"))
    }

    @Test fun invisibleMarksRemovedAndSpacesCollapsed() {
        assertEquals("انتقال: 5", TextNormalizer.normalize("‏انتقال: ‫5‬"))
        assertEquals(listOf("a b", "c"), TextNormalizer.lines("a   b\r\n\r\n  c  \n"))
    }
}
