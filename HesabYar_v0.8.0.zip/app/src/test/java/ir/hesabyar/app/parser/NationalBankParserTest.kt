package ir.hesabyar.app.parser

import ir.hesabyar.app.money.Currency
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NationalBankParserTest {

    // ---- helpers: build the "bad" real-world spellings explicitly -----------------------
    /** Turn Persian letters into the Arabic look-alikes real SMS use: ی->ي, ک->ك */
    private fun arabicLetters(s: String) = s.replace('ی', 'ي').replace('ک', 'ك')
    private fun persianDigits(s: String) = s.map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
    private fun arabicDigits(s: String) = s.map { if (it in '0'..'9') '٠' + (it - '0') else it }.joinToString("")

    private val withdrawalClean = "بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03"
    private val depositClean = "بانک ملی ایران\nانتقالی:1,000,000+\nحساب:60007\nمانده:3,433,816\n0818-18:06"

    // The two real samples exactly in their original Arabic-letter spelling (ك ي)
    private val withdrawalSample = arabicLetters("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03")
    private val depositSample = arabicLetters("بانک ملی ایران\nانتقالی:1,000,000+\nحساب:60007\nمانده:3,433,816\n0818-18:06")

    private fun parse(text: String) = BankParserRegistry.parse(text)
    private fun success(text: String): ParsedTransaction {
        val r = parse(text)
        assertTrue("expected Success but was $r", r is ParseResult.Success)
        return (r as ParseResult.Success).transaction
    }
    private fun review(text: String): ParseResult.NeedsReview {
        val r = parse(text)
        assertTrue("expected NeedsReview but was $r", r is ParseResult.NeedsReview)
        return r as ParseResult.NeedsReview
    }

    // ---- the two real samples ------------------------------------------------------------
    @Test fun sampleWithdrawal_isParsedCorrectly() {
        assertTrue("sample must really contain Arabic ك/ي", withdrawalSample.contains('ك') && withdrawalSample.contains('ي'))
        val t = success(withdrawalSample)
        assertEquals("MELLI", t.bankId)
        assertEquals("بانک ملی ایران", t.bankName)
        assertEquals(TransactionType.WITHDRAWAL, t.type)
        assertEquals(2_011_000L, t.amount)
        assertEquals(Currency.RIAL, t.currency)
        assertEquals(2_433_816L, t.balance)
        assertEquals("60007", t.accountId)
        assertEquals(8, t.month); assertEquals(18, t.day)
        assertEquals(18, t.hour); assertEquals(3, t.minute)
    }

    @Test fun sampleDeposit_isParsedCorrectly() {
        assertTrue(depositSample.contains("انتقالي:"))
        val t = success(depositSample)
        assertEquals(TransactionType.DEPOSIT, t.type)
        assertEquals(1_000_000L, t.amount)
        assertEquals(Currency.RIAL, t.currency)
        assertEquals(3_433_816L, t.balance)
        assertEquals("60007", t.accountId)
        assertEquals(8, t.month); assertEquals(18, t.day)
        assertEquals(18, t.hour); assertEquals(6, t.minute)
    }

    @Test fun balanceIsNeverUsedAsAmount() {
        listOf(withdrawalSample, depositSample).forEach {
            val t = success(it)
            assertNotEquals(t.balance, t.amount)
        }
    }

    @Test fun amountIsStoredPositive_directionOnlyInType() {
        assertTrue(success(withdrawalSample).amount > 0)
        assertTrue(success(depositSample).amount > 0)
    }

    // ---- digits / letters / separators ---------------------------------------------------
    @Test fun persianDigits() {
        val t = success(persianDigits(withdrawalClean))
        assertEquals(2_011_000L, t.amount); assertEquals(2_433_816L, t.balance)
        assertEquals("60007", t.accountId); assertEquals(18, t.hour); assertEquals(3, t.minute)
    }

    @Test fun arabicIndicDigits() {
        val t = success(arabicDigits(depositClean))
        assertEquals(1_000_000L, t.amount); assertEquals(3_433_816L, t.balance)
        assertEquals("60007", t.accountId); assertEquals(TransactionType.DEPOSIT, t.type)
    }

    @Test fun latinDigits_cleanPersianLetters() {
        assertEquals(2_011_000L, success(withdrawalClean).amount)
    }

    @Test fun persianThousandsSeparators() {
        val t = success("بانک ملی ایران\nانتقال:2٬011٬000-\nحساب:60007\nمانده:2،433،816\n0818-18:03")
        assertEquals(2_011_000L, t.amount); assertEquals(2_433_816L, t.balance)
    }

    @Test fun dotSeparatorsAndNoSeparators() {
        assertEquals(2_011_000L, success("بانک ملی ایران\nانتقال:2.011.000-\nحساب:60007\nمانده:2433816\n0818-18:03").amount)
        assertEquals(500L, success("بانک ملی ایران\nانتقال:500-\nحساب:60007\nمانده:1000\n0818-18:03").amount)
    }

    @Test fun arabicYehAndPersianYeh_bothAccepted() {
        assertEquals(TransactionType.DEPOSIT, success(depositClean).type)                       // انتقالی
        assertEquals(TransactionType.DEPOSIT, success(depositClean.replace("انتقالی", "انتقال")).type) // انتقال+
        assertEquals(TransactionType.DEPOSIT, success(depositSample).type)                      // انتقالي
    }

    @Test fun unicodeMinusAndSpacesAndCrlf() {
        val t = success("بانک ملی ایران\r\nانتقال: 2,011,000− \r\n\r\nحساب : 60007\r\nمانده: 2,433,816\r\n  0818-18:03  ")
        assertEquals(TransactionType.WITHDRAWAL, t.type); assertEquals(2_011_000L, t.amount)
    }

    @Test fun leadingSignAlsoAccepted() {
        assertEquals(TransactionType.WITHDRAWAL, success(withdrawalClean.replace("2,011,000-", "-2,011,000")).type)
        assertEquals(TransactionType.DEPOSIT, success(depositClean.replace("1,000,000+", "+1,000,000")).type)
    }

    // ---- manual-review cases ---------------------------------------------------------------
    @Test fun missingSign_goesToReview() {
        val r = review(withdrawalClean.replace("2,011,000-", "2,011,000"))
        assertTrue(ReviewReason.MISSING_SIGN in r.reasons)
        assertEquals(2_011_000L, r.partial.amount)
        assertEquals(null, r.partial.type)
    }

    @Test fun signsOnBothSides_goesToReview() {
        assertTrue(ReviewReason.CONFLICTING_SIGN in review(withdrawalClean.replace("2,011,000-", "-2,011,000+")).reasons)
    }

    @Test fun missingBalance_goesToReview() {
        assertTrue(ReviewReason.MISSING_BALANCE in review("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\n0818-18:03").reasons)
    }

    @Test fun missingAccount_goesToReview() {
        assertTrue(ReviewReason.MISSING_ACCOUNT in review("بانک ملی ایران\nانتقال:2,011,000-\nمانده:2,433,816\n0818-18:03").reasons)
    }

    @Test fun missingTime_goesToReview() {
        assertTrue(ReviewReason.MISSING_TIME in review("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816").reasons)
    }

    @Test fun missingTransferLineButBalancePresent_goesToReview() {
        val r = review("بانک ملی ایران\nحساب:60007\nمانده:2,433,816\n0818-18:03")
        assertTrue(ReviewReason.MISSING_TRANSFER_LINE in r.reasons)
    }

    @Test fun invalidTime_goesToReview() {
        assertTrue(ReviewReason.INVALID_TIME in review(withdrawalClean.replace("0818-18:03", "1345-25:99")).reasons)
    }

    @Test fun invalidOrZeroAmount_goesToReview() {
        assertTrue(ReviewReason.INVALID_AMOUNT in review(withdrawalClean.replace("2,011,000-", "abc-")).reasons)
        assertTrue(ReviewReason.INVALID_AMOUNT in review(withdrawalClean.replace("2,011,000-", "0-")).reasons)
        assertTrue(ReviewReason.INVALID_AMOUNT in review(withdrawalClean.replace("2,011,000-", "2,01,00-")).reasons)
    }

    @Test fun duplicateTransferLine_goesToReview() {
        assertTrue(ReviewReason.DUPLICATE_FIELD in review(withdrawalClean + "\nانتقال:5,000-").reasons)
    }

    @Test fun unknownExtraLine_goesToReview() {
        assertTrue(ReviewReason.UNRECOGNIZED_LINE in review(withdrawalClean + "\nتخفیف ویژه").reasons)
    }

    @Test fun reviewIsNeverAutoRegistered() {
        listOf(
            withdrawalClean.replace("2,011,000-", "2,011,000"),
            "بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\n0818-18:03"
        ).forEach { assertFalse(parse(it) is ParseResult.Success) }
    }

    // ---- not a transaction / not this bank -------------------------------------------------
    @Test fun bankHeaderWithOtpOnly_isNotATransaction() {
        assertTrue(parse("بانک ملی ایران\nرمز پویا: 123456") is ParseResult.NotTransaction)
    }

    @Test fun otherBank_isNoParser() {
        assertEquals(ParseResult.NoParser, parse("بانک ملت\nبرداشت:2,011,000\nمانده:2,433,816"))
    }

    @Test fun promoMentioningMelliInsideText_isNoParser() {
        assertEquals(ParseResult.NoParser, parse("جشنواره ویژه بانک ملی ایران: تا ۵۰ درصد تخفیف!"))
        assertEquals(ParseResult.NoParser, parse("تخفیف\nبانک ملی ایران\nانتقال:2,011,000-"))
    }

    @Test fun emptyAndGarbage_areNoParser() {
        assertEquals(ParseResult.NoParser, parse(""))
        assertEquals(ParseResult.NoParser, parse("   \n \n"))
        assertEquals(ParseResult.NoParser, parse("سلام، فردا ساعت ۵ می‌بینمت"))
    }

    // ---- duplicate key ---------------------------------------------------------------------
    @Test fun dedupKey_sameAcrossDigitScriptsAndLetterVariants() {
        assertEquals(success(withdrawalSample).dedupKey, success(persianDigits(withdrawalClean)).dedupKey)
    }

    @Test fun dedupKey_isLatinEvenOnPersianLocalePhone() {
        val saved = java.util.Locale.getDefault()
        try {
            val expected = success(withdrawalSample).dedupKey
            java.util.Locale.setDefault(java.util.Locale("fa", "IR"))
            val underFa = success(withdrawalSample).dedupKey
            assertEquals(expected, underFa)
            assertEquals("MELLI|60007|-2011000|2433816|0818-1803", underFa)
        } finally {
            java.util.Locale.setDefault(saved)
        }
    }

    @Test fun dedupKey_differsForDepositVsWithdrawal() {
        assertNotEquals(success(withdrawalSample).dedupKey, success(depositSample).dedupKey)
    }

    @Test fun dedupKey_differsWhenBalanceDiffers() {
        val other = withdrawalClean.replace("2,433,816", "2,433,817")
        assertNotEquals(success(withdrawalClean).dedupKey, success(other).dedupKey)
    }

    // ---- independence of parsers -----------------------------------------------------------
    private class FakeBankParser(override val bankId: String, private val header: String) : BankParser {
        var parseCalls = 0
        override val bankName = header
        override fun canHandle(lines: List<String>) = lines.firstOrNull() == header
        override fun parse(lines: List<String>): ParseResult { parseCalls++; return ParseResult.NotTransaction(bankId) }
    }

    @Test fun addingAnotherBank_doesNotChangeMelliResults() {
        val fake = FakeBankParser("FAKE", "بانک آزمایشی")
        val parsers = listOf(NationalBankParser(), fake)
        val before = BankParserRegistry.parse(withdrawalSample, listOf(NationalBankParser()))
        val after = BankParserRegistry.parse(withdrawalSample, parsers)
        assertEquals(before, after)
        assertEquals(0, fake.parseCalls)
        assertTrue(BankParserRegistry.parse("بانک آزمایشی\nxyz", parsers) is ParseResult.NotTransaction)
    }

    @Test fun twoParsersClaimingSameMessage_goesToReview() {
        val a = FakeBankParser("A", "بانک ملی ایران")
        val r = BankParserRegistry.parse(withdrawalSample, listOf(NationalBankParser(), a))
        assertTrue(r is ParseResult.NeedsReview)
        assertTrue(ReviewReason.AMBIGUOUS_BANK in (r as ParseResult.NeedsReview).reasons)
    }

    private class ThrowingParser : BankParser {
        override val bankId = "BOOM"; override val bankName = "x"
        override fun canHandle(lines: List<String>) = true
        override fun parse(lines: List<String>): ParseResult = throw IllegalStateException("bug")
    }

    @Test fun parserCrash_neverPropagates() {
        val r = BankParserRegistry.parse("anything", listOf(ThrowingParser()))
        assertTrue(r is ParseResult.NeedsReview)
    }
}
