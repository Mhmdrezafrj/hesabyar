package ir.hesabyar.app.report

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.widget.CategoryOps
import ir.hesabyar.app.widget.Categories
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.util.TimeZone

class ReportCalculatorTest {
    private fun ms(iso: String) = Instant.parse(iso).toEpochMilli()
    // "now" = 2026-11-10 = 19 Aban 1405
    private val now = ms("2026-11-10T12:00:00Z")
    private val calc = ReportCalculator(now, TimeZone.getTimeZone("UTC"))

    private fun tx(id: String, iso: String?, amount: Long, income: Boolean = false, cat: String = "",
                   cur: Currency = Currency.RIAL) =
        Transaction(id, id, "b", amount, "t", income, cat, cur.code, timestamp = iso?.let { ms(it) } ?: 0L)

    private val data = listOf(
        tx("e1", "2026-11-10T08:00:00Z", 1_000_000, cat = "خوراک و مواد غذایی"),               // today expense
        tx("e2", "2026-11-10T09:00:00Z", 500_000, cat = "حمل‌ونقل"),                          // today expense
        tx("i1", "2026-11-10T07:00:00Z", 8_000_000, income = true, cat = Categories.INCOME),  // today income
        tx("t1", "2026-11-10T06:00:00Z", 3_000_000, cat = Categories.TRANSFER),               // transfer out (ignored)
        tx("t2", "2026-11-10T06:01:00Z", 3_000_000, income = true, cat = Categories.TRANSFER),// transfer in (ignored)
        tx("e3", "2026-10-30T10:00:00Z", 200_000, cat = "خوراک و مواد غذایی"),                // earlier this Jalali month (Aban 8)
        tx("u1", "2026-11-09T10:00:00Z", 100_000),                                            // uncategorised, this month
        tx("p1", "2026-10-10T10:00:00Z", 600_000, cat = "قبوض"),                              // last month (Mehr 18)
        tx("p2", "2026-10-11T10:00:00Z", 5_000_000, income = true, cat = Categories.INCOME),  // last month income
        tx("old", null, 999_999)                                                              // legacy row, no date
    )

    @Test fun todayExpense_excludesTransfers_andOtherDays() {
        assertEquals(1_500_000L, calc.summary(data).todayExpenseRial)
    }

    @Test fun monthTotals() {
        val s = calc.summary(data)
        assertEquals(1_800_000L, s.monthExpenseRial)   // 1.0M + 0.5M + 0.2M + 0.1M
        assertEquals(8_000_000L, s.monthIncomeRial)    // transfers NOT counted as income
    }

    @Test fun previousMonthSeparate() {
        val s = calc.summary(data)
        assertEquals(600_000L, s.prevMonthExpenseRial)
        assertEquals(5_000_000L, s.prevMonthIncomeRial)
    }

    @Test fun transfersNeverCountedTwice() {
        val t = calc.totals(data.filter { it.category == Categories.TRANSFER })
        assertEquals(0L, t.expenseRial); assertEquals(0L, t.incomeRial)
    }

    @Test fun categoryBreakdown_sortedAndWithUncategorised() {
        val c = calc.summary(data).monthExpenseByCategory
        assertEquals(listOf("خوراک و مواد غذایی", "حمل‌ونقل", Categories.UNCATEGORIZED_LABEL), c.map { it.category })
        assertEquals(1_200_000L, c[0].totalRial)
        assertEquals(1_800_000L, c.sumOf { it.totalRial })
    }

    @Test fun mixedCurrencies_areNormalisedToRial_withoutChangingStoredValues() {
        val mixed = listOf(
            tx("a", "2026-11-10T08:00:00Z", 1_000, cur = Currency.TOMAN),   // 1,000 toman = 10,000 rial
            tx("b", "2026-11-10T08:00:00Z", 10_000, cur = Currency.RIAL)
        )
        assertEquals(20_000L, calc.summary(mixed).todayExpenseRial)
        assertEquals(1_000L, mixed[0].amount)
    }

    @Test fun percentChange() {
        assertEquals(200, ReportCalculator.percentChange(300, 100))
        assertEquals(-50, ReportCalculator.percentChange(50, 100))
        assertNull(ReportCalculator.percentChange(50, 0))
    }

    @Test fun filters() {
        assertEquals(listOf("e2", "e1", "i1", "t2", "t1").toSet(), calc.filter(data, ReportFilter(RangePreset.TODAY)).map { it.id }.toSet())
        assertTrue(calc.filter(data, ReportFilter(RangePreset.TODAY, TypeFilter.INCOME)).all { it.isIncome })
        assertEquals(listOf("p1"), calc.filter(data, ReportFilter(RangePreset.LAST_MONTH, TypeFilter.EXPENSE)).map { it.id })
        assertEquals(listOf("e1", "e3").toSet(), calc.filter(data, ReportFilter(RangePreset.THIS_MONTH, category = "خوراک و مواد غذایی")).map { it.id }.toSet())
        assertEquals(listOf("u1"), calc.filter(data, ReportFilter(RangePreset.THIS_MONTH, category = Categories.UNCATEGORIZED_LABEL)).map { it.id })
    }

    @Test fun legacyRowsWithoutDate_onlyInAll() {
        assertTrue(calc.filter(data, ReportFilter(RangePreset.ALL)).any { it.id == "old" })
        assertTrue(calc.filter(data, ReportFilter(RangePreset.THIS_MONTH)).none { it.id == "old" })
        assertEquals(0L, calc.summary(listOf(tx("old", null, 5))).monthExpenseRial)
    }

    @Test fun filterResultIsNewestFirst() {
        val ids = calc.filter(data, ReportFilter(RangePreset.THIS_MONTH)).map { it.id }
        assertEquals("e2", ids.first())
    }

    // ---- category editing ----
    @Test fun addRenameDeleteCategories() {
        val base = Categories.defaults
        assertEquals(base.size + 1, CategoryOps.add(base, "  سفر  ").list.size)
        assertEquals("این دسته قبلاً وجود دارد", CategoryOps.add(base, "قبوض").error)
        assertEquals("نام دسته خالی است", CategoryOps.add(base, "   ").error)
        val r = CategoryOps.rename(base, "قبوض", "قبض‌ها")
        assertTrue("قبض‌ها" in r.list && "قبوض" !in r.list)
        assertEquals("این دسته قبلاً وجود دارد", CategoryOps.rename(base, "قبوض", "تفریح").error)
        assertTrue(CategoryOps.delete(base, "تفریح").list.size == base.size - 1)
    }

    @Test fun protectedCategoriesCannotBeChanged() {
        val base = Categories.defaults
        assertEquals(base, CategoryOps.delete(base, Categories.TRANSFER).list)
        assertEquals(base, CategoryOps.rename(base, Categories.OTHER, "x").list)
    }

    @Test fun defaultsContainEverythingTheBriefAsks() {
        listOf("خوراک و مواد غذایی", "حمل‌ونقل", "خرید و پوشاک", "مسکن و اجاره", "قبوض", "درمان و سلامت",
            "تفریح", "آموزش", "درآمد", "انتقال بین حساب‌ها", "سایر").forEach { assertTrue(it in Categories.defaults) }
    }
}
