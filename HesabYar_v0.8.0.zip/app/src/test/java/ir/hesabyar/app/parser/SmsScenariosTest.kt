package ir.hesabyar.app.parser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The 15 SMS scenarios from the product brief, against the parsers that exist today (Bank Melli only).
 * Scenarios whose bank format is not yet known (e.g. card purchase) are verified to go to REVIEW / be ignored,
 * never to be silently registered as a transaction.
 */
class SmsScenariosTest {
    private fun parse(t: String) = BankParserRegistry.parse(t)
    private fun isAutoRegistered(t: String) = parse(t) is ParseResult.Success

    @Test fun s1_withdrawal() = assertTrue(isAutoRegistered("بانک ملی ایران\nانتقال:500,000-\nحساب:60007\nمانده:1,000,000\n0818-10:00"))
    @Test fun s2_deposit() = assertTrue(isAutoRegistered("بانک ملی ایران\nانتقالی:500,000+\nحساب:60007\nمانده:1,500,000\n0818-10:05"))

    @Test fun s3_cardPurchaseOfUnknownLayout_isNeverAutoRegistered() {
        val t = "بانک ملی ایران\nخرید:250,000-\nکارت:1234\nمانده:1,000,000\n0818-10:00"
        assertFalse(isAutoRegistered(t))
        assertTrue(parse(t) is ParseResult.NeedsReview)
    }

    @Test fun s4_transfer() = assertTrue(isAutoRegistered("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03"))
    @Test fun s5_amountAndBalance_amountIsNotBalance() {
        val t = (parse("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03") as ParseResult.Success).transaction
        assertEquals(2_011_000L, t.amount); assertEquals(2_433_816L, t.balance)
    }
    @Test fun s6_otp_isNotATransaction() {
        assertFalse(isAutoRegistered("بانک ملی ایران\nرمز پویا: 482913\nمبلغ: 2,000,000"))
        assertFalse(isAutoRegistered("رمز دوم پویا 482913 برای خرید 2,000,000 ریال"))
        assertFalse(isAutoRegistered("کد تایید ورود به حساب شما: 123456"))
    }
    @Test fun s7_promoWithNumbers() {
        assertFalse(isAutoRegistered("جشنواره ویژه! تا ۵۰٪ تخفیف و ۱۰۰٬۰۰۰ تومان هدیه برای خرید شما"))
        assertEquals(ParseResult.NoParser, parse("باشگاه مشتریان: ۲۰٪ تخفیف تا ۵۰٬۰۰۰ تومان"))
    }
    @Test fun s8_bankInfoWithoutTransaction() {
        assertTrue(parse("بانک ملی ایران\nسامانه بانکداری شما به‌روزرسانی شد") is ParseResult.NotTransaction)
    }
    @Test fun s9_nonBankSmsWithAmount() {
        assertFalse(isAutoRegistered("فاکتور شما به مبلغ ۲۵۰٬۰۰۰ تومان صادر شد"))
        assertEquals(ParseResult.NoParser, parse("سلام، ۲۵۰۰۰۰ تومان بده"))
    }
    @Test fun s10_persianDigits() = assertTrue(isAutoRegistered("بانک ملی ایران\nانتقال:۲٬۰۱۱٬۰۰۰-\nحساب:۶۰۰۰۷\nمانده:۲٬۴۳۳٬۸۱۶\n۰۸۱۸-۱۸:۰۳"))
    @Test fun s11_arabicDigits() = assertTrue(isAutoRegistered("بانك ملي ايران\nانتقال:٢,٠١١,٠٠٠-\nحساب:٦٠٠٠٧\nمانده:٢,٤٣٣,٨١٦\n٠٨١٨-١٨:٠٣"))
    @Test fun s12_latinDigits() = assertTrue(isAutoRegistered("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03"))
    @Test fun s13_duplicateSmsHasSameKey() {
        val a = (parse("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03") as ParseResult.Success).transaction
        val b = (parse("بانك ملي ايران\nانتقال:۲٬۰۱۱٬۰۰۰-\nحساب:60007\nمانده:2,433,816\n0818-18:03") as ParseResult.Success).transaction
        assertEquals(a.dedupKey, b.dedupKey)
    }
    @Test fun s14_unknownFormat() {
        assertFalse(isAutoRegistered("بانک ملی ایران\nچیز عجیب: 12345\nحساب:60007"))
        assertEquals(ParseResult.NoParser, parse("بانک ناشناخته\nبرداشت 100000 ریال"))
    }
    @Test fun s15_incompleteOrNoAmount() {
        assertFalse(isAutoRegistered("بانک ملی ایران\nانتقال:\nحساب:60007\nمانده:2,433,816\n0818-18:03"))
        assertFalse(isAutoRegistered("بانک ملی ایران\nحساب:60007\nمانده:2,433,816"))
    }
}
