package ir.hesabyar.app.report

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.widget.Categories
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.util.TimeZone

class HistoryGrouperTest {
    private fun ms(iso: String) = Instant.parse(iso).toEpochMilli()
    private val g = HistoryGrouper(TimeZone.getTimeZone("UTC"))

    private fun tx(id: String, iso: String?, amount: Long, income: Boolean = false, cat: String = "x", cur: Currency = Currency.RIAL) =
        Transaction(id, id, "b", amount, "t", income, cat, cur.code, timestamp = iso?.let { ms(it) } ?: 0L)

    private val data = listOf(
        tx("a1", "2026-11-10T08:00:00Z", 100_000),                          // 19 Aban 1405 (Tuesday)
        tx("a2", "2026-11-10T20:00:00Z", 50_000),                           // same day, later
        tx("a3", "2026-11-09T10:00:00Z", 30_000, income = true),            // 18 Aban
        tx("a4", "2026-10-30T10:00:00Z", 10_000),                           // 8 Aban
        tx("m1", "2026-10-10T10:00:00Z", 70_000),                           // 18 Mehr
        tx("tr", "2026-11-10T09:00:00Z", 999_000, cat = Categories.TRANSFER),
        tx("old", null, 5)
    )

    @Test fun monthsAndDays_newestFirst() {
        val h = g.group(data)
        assertEquals(listOf(8 to 1405, 7 to 1405), h.months.map { it.month to it.year })
        assertEquals(listOf(19, 18, 8), h.months[0].days.map { it.day })
    }

    @Test fun transactionsWithinDay_newestFirst() {
        val day = g.group(data).months[0].days[0]
        assertEquals("a2", day.transactions.first().id)
        assertEquals(setOf("a1", "a2", "tr"), day.transactions.map { it.id }.toSet())
    }

    @Test fun weekdayName() {
        assertEquals("سه‌شنبه", g.group(data).months[0].days[0].weekdayName)
        assertEquals("دوشنبه", g.group(data).months[0].days[1].weekdayName)
    }

    @Test fun totals_excludeTransfers() {
        val h = g.group(data)
        assertEquals(150_000L, h.months[0].days[0].totals.expenseRial)
        assertEquals(0L, h.months[0].days[0].totals.incomeRial)
        assertEquals(30_000L, h.months[0].totals.incomeRial)
        assertEquals(160_000L, h.months[0].totals.expenseRial)   // 100k + 50k + 10k, transfer ignored
        assertEquals(5, h.months[0].count)
    }

    @Test fun monthNameAndUndated() {
        val h = g.group(data)
        assertEquals("آبان", h.months[0].monthName)
        assertEquals("مهر", h.months[1].monthName)
        assertEquals(listOf("old"), h.undated.map { it.id })
        assertTrue(h.months.flatMap { it.days }.flatMap { it.transactions }.none { it.id == "old" })
    }

    @Test fun mixedCurrencyTotalsNormalisedToRial() {
        val h = g.group(listOf(tx("t", "2026-11-10T08:00:00Z", 1_000, cur = Currency.TOMAN), tx("r", "2026-11-10T08:00:00Z", 10_000)))
        assertEquals(20_000L, h.months[0].totals.expenseRial)
    }

    @Test fun emptyInput() {
        val h = g.group(emptyList())
        assertTrue(h.months.isEmpty() && h.undated.isEmpty())
    }

    @Test fun yearBoundary_esfandToFarvardin() {
        val h = g.group(listOf(tx("e", "2026-03-20T12:00:00Z", 1), tx("f", "2026-03-21T12:00:00Z", 1)))
        assertEquals(listOf(1405 to 1, 1404 to 12), h.months.map { it.year to it.month })
    }
}
