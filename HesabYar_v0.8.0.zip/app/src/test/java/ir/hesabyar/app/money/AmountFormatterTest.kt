package ir.hesabyar.app.money

import org.junit.Assert.assertEquals
import org.junit.Test

class AmountFormatterTest {
    private val R = Currency.RIAL
    private val T = Currency.TOMAN

    @Test fun rialToToman_isDivisionByTen() {
        assertEquals("201,100", AmountFormatter.number(2_011_000, R, T, persianDigits = false))
        assertEquals("243,381.6", AmountFormatter.number(2_433_816, R, T, persianDigits = false))
    }

    @Test fun rialShownAsRial_unchanged() {
        assertEquals("2,011,000", AmountFormatter.number(2_011_000, R, R, persianDigits = false))
    }

    @Test fun tomanToRial_isTimesTen() {
        assertEquals("3,200,000", AmountFormatter.number(320_000, T, R, persianDigits = false))
    }

    @Test fun sameCurrency_neverConverted() {
        assertEquals("320,000", AmountFormatter.number(320_000, T, T, persianDigits = false))
    }

    @Test fun unitLabelIsAlwaysShown() {
        assertEquals("201,100 تومان", AmountFormatter.format(2_011_000, R, T, persianDigits = false))
        assertEquals("2,011,000 ریال", AmountFormatter.format(2_011_000, R, R, persianDigits = false))
    }

    @Test fun repeatedFormatting_doesNotCompound() {
        val stored = 2_011_000L
        val first = AmountFormatter.format(stored, R, T)
        val second = AmountFormatter.format(stored, R, T)
        assertEquals(first, second)
        assertEquals("2,011,000 ریال", AmountFormatter.format(stored, R, R, persianDigits = false)) // stored value untouched
    }

    @Test fun persianDigitsAndSeparators() {
        assertEquals("۲۰۱٬۱۰۰ تومان", AmountFormatter.format(2_011_000, R, T))
        assertEquals("۲۴۳٬۳۸۱٫۶ تومان", AmountFormatter.format(2_433_816, R, T))
    }

    @Test fun signedFormatting() {
        assertEquals("−201,100 تومان", AmountFormatter.formatSigned(2_011_000, false, R, T, persianDigits = false))
        assertEquals("+100,000 تومان", AmountFormatter.formatSigned(1_000_000, true, R, T, persianDigits = false))
    }

    @Test fun smallAndZeroAndNegativeBalance() {
        assertEquals("0", AmountFormatter.number(0, R, T, persianDigits = false))
        assertEquals("0.5", AmountFormatter.number(5, R, T, persianDigits = false))
        assertEquals("-1,000", AmountFormatter.number(-10_000, R, T, persianDigits = false))
    }

    @Test fun legacyRowsWithoutCurrencyDefaultToToman_noConversion() {
        assertEquals(Currency.TOMAN, Currency.fromCode(null))
        assertEquals(Currency.TOMAN, Currency.fromCode(""))
        assertEquals(Currency.RIAL, Currency.fromCode("IRR"))
        assertEquals("320,000", AmountFormatter.number(320_000, Currency.fromCode(null), T, persianDigits = false))
    }
}
