package ir.hesabyar.app.widget

/** Gregorian -> Jalali (Persian) conversion, pure Kotlin (jalaali algorithm). */
object JalaliCalendar {
    data class Date(val year: Int, val month: Int, val day: Int)

    private val breaks = intArrayOf(-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)

    val monthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")

    fun fromGregorian(gy: Int, gm: Int, gd: Int): Date = d2j(g2d(gy, gm, gd))

    private fun g2d(gy: Int, gm: Int, gd: Int): Int {
        var d = ((gy + (gm - 8) / 6 + 100100) * 1461) / 4 + (153 * ((gm + 9) % 12) + 2) / 5 + gd - 34840408
        d = d - (((gy + 100100 + (gm - 8) / 6) / 100) * 3) / 4 + 752
        return d
    }

    private fun d2gYear(jdn: Int): Int {
        var j = 4 * jdn + 139361631
        j += (((4 * jdn + 183187720) / 146097) * 3 / 4) * 4 - 3908
        val i = ((j % 1461) / 4) * 5 + 308
        val gm = (i / 153) % 12 + 1
        return j / 1461 - 100100 + (8 - gm) / 6
    }

    /** Returns (marchDay of Nowruz in gregorian year gy). */
    private fun marchDay(jy: Int): Pair<Int, Int> {
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        var jump = 0
        for (i in 1 until breaks.size) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += (jump / 33) * 8 + (jump % 33) / 4
            jp = jm
        }
        val n = jy - jp
        leapJ += (n / 33) * 8 + ((n % 33) + 3) / 4
        if (jump % 33 == 4 && jump - n == 4) leapJ += 1
        val leapG = gy / 4 - ((gy / 100 + 1) * 3) / 4 - 150
        return Pair(gy, 20 + leapJ - leapG)
    }

    private fun d2j(jdn: Int): Date {
        val gy = d2gYear(jdn)
        var jy = gy - 621
        val (_, march) = marchDay(jy)
        val jdn1f = g2d(gy, 3, march)
        var k = jdn - jdn1f
        if (k >= 0) {
            if (k <= 185) return Date(jy, 1 + k / 31, k % 31 + 1)
            k -= 186
        } else {
            jy -= 1
            k += 179
            // leap year adjustment of the previous Jalali year
            if (isLeap(jy)) k += 1
        }
        return Date(jy, 7 + k / 30, k % 30 + 1)
    }

    private fun isLeap(jy: Int): Boolean {
        var jp = breaks[0]
        var jump = 0
        for (i in 1 until breaks.size) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            jp = jm
        }
        var n = jy - jp
        if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33
        var leap = ((n + 1) % 33 - 1) % 4
        if (leap == -1) leap = 4
        return leap == 0
    }
}
