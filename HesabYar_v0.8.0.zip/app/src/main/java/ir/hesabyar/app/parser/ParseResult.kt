package ir.hesabyar.app.parser

import ir.hesabyar.app.money.Currency

enum class TransactionType { DEPOSIT, WITHDRAWAL }

enum class Confidence { HIGH, MEDIUM, LOW }

/** Why a message that looks like it belongs to a bank could not be auto-registered. */
enum class ReviewReason {
    MISSING_TRANSFER_LINE,
    MISSING_SIGN,
    CONFLICTING_SIGN,
    INVALID_AMOUNT,
    MISSING_BALANCE,
    INVALID_BALANCE,
    MISSING_ACCOUNT,
    INVALID_ACCOUNT,
    MISSING_TIME,
    INVALID_TIME,
    DUPLICATE_FIELD,
    UNRECOGNIZED_LINE,
    AMBIGUOUS_BANK
}

/**
 * A fully-parsed, trustworthy transaction.
 *
 * [amount] is ALWAYS positive and in [currency] exactly as it appeared in the SMS
 * (no unit conversion). The direction is carried by [type]. [balance] is the account
 * balance AFTER the transaction and must never be used as the transaction amount.
 *
 * The SMS does not contain a year, so month/day are kept exactly as written
 * (in the bank's own calendar) and the real receive time of the SMS is used by the app
 * as the canonical timestamp.
 */
data class ParsedTransaction(
    val bankId: String,
    val bankName: String,
    val type: TransactionType,
    val amount: Long,
    val currency: Currency,
    val balance: Long,
    val accountId: String,
    val month: Int,
    val day: Int,
    val hour: Int,
    val minute: Int
) {
    /**
     * Semantic duplicate key: the same bank SMS yields the same key even if it is
     * received live and later imported from history (whose timestamps differ slightly).
     * Two genuine transactions cannot share it because the balance after each differs.
     */
    val dedupKey: String
        get() {
            val signed = if (type == TransactionType.WITHDRAWAL) -amount else amount
            // padStart (not String.format) so digits stay Latin even on a Persian-locale phone.
            return "$bankId|$accountId|$signed|$balance|" +
                "${two(month)}${two(day)}-${two(hour)}${two(minute)}"
        }
}

private fun two(n: Int) = n.toString().padStart(2, '0')

/** Whatever could be extracted from a message that needs manual review. Any field may be null. */
data class PartialTransaction(
    val type: TransactionType? = null,
    val amount: Long? = null,
    val balance: Long? = null,
    val accountId: String? = null,
    val timeText: String? = null
)

sealed class ParseResult {
    /** High confidence: safe to register automatically. */
    data class Success(
        val transaction: ParsedTransaction,
        val confidence: Confidence = Confidence.HIGH
    ) : ParseResult()

    /** Recognised as this bank's message, but incomplete/ambiguous: send to manual review, never auto-register. */
    data class NeedsReview(
        val bankId: String,
        val reasons: List<ReviewReason>,
        val partial: PartialTransaction
    ) : ParseResult() {
        val confidence: Confidence get() = Confidence.MEDIUM
    }

    /** Belongs to this bank but is clearly not a transaction (e.g. OTP / info message). */
    data class NotTransaction(val bankId: String) : ParseResult()

    /** No registered parser recognised this message. */
    object NoParser : ParseResult() {
        override fun toString() = "NoParser"
    }
}
