package ir.hesabyar.app

import android.content.Context
import ir.hesabyar.app.money.Currency

/** User choice of the unit used to SHOW amounts. It never changes stored values. */
object DisplaySettings {
    private const val PREFS = "hesabyar_settings"
    private const val KEY = "display_currency"

    fun get(context: Context): Currency =
        Currency.fromCode(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, Currency.TOMAN.code))

    fun set(context: Context, currency: Currency) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, currency.code).apply()
    }

    fun toggle(context: Context): Currency {
        val next = if (get(context) == Currency.TOMAN) Currency.RIAL else Currency.TOMAN
        set(context, next)
        return next
    }
}
