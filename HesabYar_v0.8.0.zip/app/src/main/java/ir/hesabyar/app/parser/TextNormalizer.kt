package ir.hesabyar.app.parser

/**
 * Pure-Kotlin text normalisation shared by all bank parsers (no Android imports,
 * so it can be unit-tested on a normal JVM).
 *
 * Normalisation rules:
 *  - Persian (۰-۹), Arabic-Indic (٠-٩) and full-width digits -> Latin 0-9
 *  - Arabic letters ي ى ك -> Persian ی ی ک
 *  - Thousands/decimal separators ٬ ، ٫ -> , , .
 *  - All minus/plus look-alikes (− – — ‐ ‑ ﹣ － ＋) -> ASCII - and +
 *  - Full-width colon -> ':'
 *  - Invisible direction marks, tatweel and Arabic diacritics are removed
 *  - ZWNJ and non-breaking spaces become normal spaces; runs of spaces collapse
 *  - Line endings (CRLF / CR) become LF
 */
object TextNormalizer {

    fun normalize(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            when (c) {
                in '۰'..'۹' -> sb.append('0' + (c - '۰'))
                in '٠'..'٩' -> sb.append('0' + (c - '٠'))
                in '０'..'９' -> sb.append('0' + (c - '０'))
                'ي', 'ى' -> sb.append('ی') // ي ى -> ی
                'ك' -> sb.append('ک')           // ك -> ک
                '٬', '،' -> sb.append(',')      // ٬ ، -> ,
                '٫' -> sb.append('.')                // ٫ -> .
                '−', '–', '—', '‐', '‑', '﹣', '－' -> sb.append('-')
                '＋' -> sb.append('+')
                '：' -> sb.append(':')
                '‌', ' ', ' ', ' ', '\t' -> sb.append(' ')
                '​', '‍', '‎', '‏', '؜', '﻿', 'ـ' -> Unit
                in '‪'..'‮', in '⁦'..'⁩' -> Unit
                in 'ً'..'ٟ' -> Unit // Arabic diacritics
                else -> sb.append(c)
            }
        }
        return sb.toString().replace("\r\n", "\n").replace('\r', '\n')
    }

    /** Normalised, trimmed, non-blank lines with inner whitespace collapsed. */
    fun lines(input: String): List<String> =
        normalize(input).split('\n')
            .map { it.replace(Regex(" {2,}"), " ").trim() }
            .filter { it.isNotEmpty() }
}
