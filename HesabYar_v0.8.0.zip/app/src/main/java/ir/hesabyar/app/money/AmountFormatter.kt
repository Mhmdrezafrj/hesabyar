package ir.hesabyar.app.money

import java.math.BigDecimal

/**
 * DISPLAY-ONLY formatting. The conversion Rial <-> Toman (1 Toman = 10 Rial) happens here
 * and nowhere else; it returns text and never changes the stored number.
 *
 * Because the caller always passes the stored amount together with its stored currency,
 * calling [format] repeatedly on the same stored value always gives the same text
 * (no double conversion is possible).
 */
object AmountFormatter {

    private const val FA_THOUSANDS = '٬'
    private const val FA_DECIMAL = '٫'

    /** Number only (no unit), converted from [stored] to [display]. */
    fun number(amount: Long, stored: Currency, display: Currency, persianDigits: Boolean = true): String {
        val exact: BigDecimal = when {
            stored == display -> BigDecimal(amount)
            stored == Currency.RIAL && display == Currency.TOMAN -> BigDecimal(amount).movePointLeft(1)
            stored == Currency.TOMAN && display == Currency.RIAL -> BigDecimal(amount).movePointRight(1)
            else -> BigDecimal(amount)
        }
        var d = exact.stripTrailingZeros()
        if (d.scale() < 0) d = d.setScale(0)
        return groupPlain(d.toPlainString(), persianDigits)
    }

    /** Number followed by the display unit, e.g. "۲۰۱٬۱۰۰ تومان". */
    fun format(amount: Long, stored: Currency, display: Currency, persianDigits: Boolean = true): String =
        number(amount, stored, display, persianDigits) + " " + display.labelFa

    /** "+" / "−" prefix + number + unit, for transaction rows. */
    fun formatSigned(amount: Long, isIncome: Boolean, stored: Currency, display: Currency, persianDigits: Boolean = true): String =
        (if (isIncome) "+" else "−") + format(amount, stored, display, persianDigits)

    fun toPersianDigits(text: String): String {
        val sb = StringBuilder(text.length)
        for (c in text) sb.append(if (c in '0'..'9') '۰' + (c - '0') else c)
        return sb.toString()
    }

    private fun groupPlain(plain: String, persian: Boolean): String {
        val negative = plain.startsWith("-")
        val unsigned = if (negative) plain.drop(1) else plain
        val intPart = unsigned.substringBefore('.')
        val frac = if (unsigned.contains('.')) unsigned.substringAfter('.') else ""
        val sep = if (persian) FA_THOUSANDS else ','
        val dec = if (persian) FA_DECIMAL else '.'
        val grouped = StringBuilder()
        intPart.forEachIndexed { i, ch ->
            if (i > 0 && (intPart.length - i) % 3 == 0) grouped.append(sep)
            grouped.append(ch)
        }
        var result = (if (negative) "-" else "") + grouped + (if (frac.isNotEmpty()) "$dec$frac" else "")
        if (persian) result = toPersianDigits(result)
        return result
    }
}

/** Report arithmetic only. Stored values are never modified; amounts are normalised to Rial for summing. */
object Money {
    fun toRial(amount: Long, currency: Currency): Long = if (currency == Currency.TOMAN) amount * 10 else amount
}
