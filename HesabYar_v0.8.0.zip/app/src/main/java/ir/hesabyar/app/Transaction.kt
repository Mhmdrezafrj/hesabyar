package ir.hesabyar.app

import ir.hesabyar.app.money.Currency

/**
 * [amount] is the raw stored number, ALWAYS expressed in [currency] (a Currency code such as "IRR").
 * It is never converted when saved; conversion to Rial/Toman happens only when displaying
 * (see AmountFormatter). Rows saved before currency tracking existed have no code and are
 * read as Toman (that is how they were entered), without any numeric change.
 */
data class Transaction(
    val id: String,
    val title: String,
    val bank: String,
    val amount: Long,
    val time: String,
    val isIncome: Boolean,
    val category: String = "",
    val currency: String = Currency.TOMAN.code,
    val source: String = "MANUAL",       // MANUAL or SMS
    val sourceRef: String = "",          // duplicate-detection key for SMS rows
    val balance: Long? = null,           // balance after the transaction, same currency
    val accountId: String = "",
    val timestamp: Long = 0L             // epoch millis, used only for ordering
) {
    val currencyType: Currency get() = Currency.fromCode(currency)
}
