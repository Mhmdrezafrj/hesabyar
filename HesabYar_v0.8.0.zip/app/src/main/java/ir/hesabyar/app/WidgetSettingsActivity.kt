package ir.hesabyar.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.widget.WidgetConfig

/** Widget customisation screen. Also used as the widget's configure activity. */
class WidgetSettingsActivity : Activity() {
    private var cfg = WidgetConfig()
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        cfg = WidgetConfigStore.load(this)
        build()
    }

    private fun label(text: String, size: Float = 14f, bold: Boolean = true) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 22, 0, 8)
    }

    private fun radios(labels: List<String>, selected: Int, onPick: (Int) -> Unit): RadioGroup {
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        labels.forEachIndexed { index, text ->
            group.addView(RadioButton(this).apply {
                this.text = text; setTextColor(Color.WHITE); id = View.generateViewId(); isChecked = index == selected
                setPadding(8, 8, 24, 8)
            })
        }
        group.setOnCheckedChangeListener { g, checkedId ->
            val idx = g.indexOfChild(g.findViewById(checkedId))
            if (idx >= 0) onPick(idx)
        }
        return group
    }

    private fun check(text: String, value: Boolean, onChange: (Boolean) -> Unit) = CheckBox(this).apply {
        this.text = text; setTextColor(Color.WHITE); isChecked = value
        setOnCheckedChangeListener { _, b -> onChange(b) }
    }

    private fun build() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(this).apply { text = "⚙ تنظیمات ویجت"; textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })

        val fontNames = listOf("کوچک", "متوسط", "بزرگ")

        root.addView(label("تعداد تراکنش‌های نمایش‌داده‌شده"))
        root.addView(radios(WidgetConfig.COUNTS.map { AmountFormatter.toPersianDigits(it.toString()) }, WidgetConfig.COUNTS.indexOf(cfg.count).coerceAtLeast(0)) { cfg = cfg.copy(count = WidgetConfig.COUNTS[it]) })

        root.addView(label("اندازه فونت عنوان‌ها"))
        root.addView(radios(fontNames, cfg.titleFont) { cfg = cfg.copy(titleFont = it) })
        root.addView(label("اندازه فونت مبالغ"))
        root.addView(radios(fontNames, cfg.amountFont) { cfg = cfg.copy(amountFont = it) })
        root.addView(label("اندازه فونت ساعت و توضیحات"))
        root.addView(radios(fontNames, cfg.metaFont) { cfg = cfg.copy(metaFont = it) })

        val opacityText = TextView(this).apply { setTextColor(Color.LTGRAY); gravity = Gravity.START }
        fun showOpacity() { opacityText.text = AmountFormatter.toPersianDigits("${cfg.opacityPercent}٪") }
        root.addView(label("میزان شفافیت پس‌زمینه"))
        root.addView(SeekBar(this).apply {
            max = 70; progress = cfg.opacityPercent - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { cfg = cfg.copy(opacityPercent = p + 30); showOpacity() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        showOpacity(); root.addView(opacityText)

        root.addView(label("سبک نمایش"))
        root.addView(radios(listOf("شیشه‌ای تیره", "بنفش و آبی"), cfg.style) { cfg = cfg.copy(style = it) })

        root.addView(label("نمایش اجزا"))
        root.addView(check("تصویر کیف پول", cfg.showWallet) { cfg = cfg.copy(showWallet = it) })
        root.addView(check("تاریخ امروز", cfg.showDate) { cfg = cfg.copy(showDate = it) })
        root.addView(check("موجودی حساب (فقط از مانده معتبر پیامک)", cfg.showBalance) { cfg = cfg.copy(showBalance = it) })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, 32, 0, 0) }
        buttons.addView(Button(this).apply {
            text = "✓ تأیید تغییرات"
            setOnClickListener {
                WidgetConfigStore.save(this@WidgetSettingsActivity, cfg)
                PendingTransactionsWidget.updateAll(this@WidgetSettingsActivity)
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                finish()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply {
            text = "↺ بازنشانی به پیش‌فرض"
            setOnClickListener { cfg = WidgetConfig(); root.removeAllViews(); build() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)

        setContentView(ScrollView(this).apply { addView(root); SystemInsets.apply(this) })
    }
}
