package ir.hesabyar.app.parser

/**
 * Chooses the parser that recognises a message. To add a bank: create a new BankParser
 * file and add one line to [defaultParsers]. Existing parsers are not touched.
 */
object BankParserRegistry {

    val defaultParsers: List<BankParser> = listOf(
        NationalBankParser()
    )

    fun parse(body: String, parsers: List<BankParser> = defaultParsers): ParseResult {
        val lines = TextNormalizer.lines(body)
        if (lines.isEmpty()) return ParseResult.NoParser
        val claimed = parsers.filter { runCatching { it.canHandle(lines) }.getOrDefault(false) }
        return when (claimed.size) {
            0 -> ParseResult.NoParser
            1 -> try {
                claimed[0].parse(lines)
            } catch (_: Exception) {
                // A parser bug must never crash SMS reception; send to manual review instead.
                ParseResult.NeedsReview(claimed[0].bankId, listOf(ReviewReason.UNRECOGNIZED_LINE), PartialTransaction())
            }
            else -> ParseResult.NeedsReview("MULTIPLE", listOf(ReviewReason.AMBIGUOUS_BANK), PartialTransaction())
        }
    }
}
