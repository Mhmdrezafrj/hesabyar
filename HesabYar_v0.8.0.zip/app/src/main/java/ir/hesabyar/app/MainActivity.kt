package ir.hesabyar.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.parser.TextNormalizer

class MainActivity : Activity() {
    private val ink = Ui.ink
    private lateinit var list: LinearLayout
    private lateinit var unitButton: Button
    private lateinit var autoButton: Button
    private val smsPermissions = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
    private val smsRequestCode = 2102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)
        root.addView(Ui.title(this, "حساب‌یار", "تراکنش‌های دسته‌بندی‌نشده و پیامک‌های بانکی"))

        fun tiles(vararg t: View) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            t.forEachIndexed { i, v ->
                row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    marginStart = Ui.dp(this@MainActivity, if (i > 0) 10 else 0)
                })
            }
            root.addView(row, Ui.margins(this, 0, 10))
        }
        tiles(
            Ui.tile(this, "🗓️", "تاریخچه (روزانه و ماهانه)", Color.argb(190, 232, 224, 255)) { startActivity(Intent(this, HistoryActivity::class.java)) },
            Ui.tile(this, "📊", "گزارش مالی و دسته‌ها", Color.argb(190, 219, 234, 255)) { startActivity(Intent(this, ReportsActivity::class.java)) }
        )
        tiles(
            Ui.tile(this, "✉️", "صندوق پیامک‌ها", Color.argb(190, 255, 226, 241)) { startActivity(Intent(this, SmsInboxActivity::class.java)) },
            Ui.tile(this, "➕", "افزودن دستی تراکنش", Color.argb(190, 223, 247, 235)) { showAddDialog() }
        )

        root.addView(Ui.primary(this, "فعال‌سازی دریافت پیامک بانکی") { explainAndRequestSmsPermissions() }, Ui.margins(this, 0, 8))
        val settingsRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        settingsRow.addView(Ui.soft(this, "وارد کردن پیامک‌های قبلی (۹۰ روز اخیر)") { importHistory() }, Ui.margins(this, 0, 6))
        unitButton = Ui.soft(this, "") {
            DisplaySettings.toggle(this@MainActivity)
            updateUnitButton(); PendingTransactionsWidget.updateAll(this@MainActivity); render()
        }
        settingsRow.addView(unitButton, Ui.margins(this, 0, 6))
        updateUnitButton()
        autoButton = Ui.soft(this, "") {
            SmsSettings.setAutoEnabled(this@MainActivity, !SmsSettings.autoEnabled(this@MainActivity))
            updateAutoButton(); runCatchUp()
        }
        settingsRow.addView(autoButton, Ui.margins(this, 0, 6))
        updateAutoButton()
        settingsRow.addView(Ui.soft(this, "حریم خصوصی و حذف داده‌ها") { showPrivacyDialog() }, Ui.margins(this, 0, 6))

        root.addView(Ui.text(this, "تراکنش‌های منتظر دسته‌بندی", 16f, ink, true).apply { setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 6)) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        content.addView(Ui.text(this, "تنظیمات", 16f, ink, true).apply { setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 6)) })
        content.addView(settingsRow)
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)

        handleWidgetIntent(intent)
        render()
        // First launch: explain and ask for SMS access automatically (once).
        if (!SmsSettings.permissionAsked(this) && smsPermissions.any { !hasPermission(it) }) {
            SmsSettings.setPermissionAsked(this)
            explainAndRequestSmsPermissions()
        }
    }

    private fun showPrivacyDialog() {
        AlertDialog.Builder(this).setTitle("حریم خصوصی")
            .setMessage("• همه اطلاعات فقط روی همین گوشی ذخیره می‌شود. برنامه مجوز اینترنت ندارد و هیچ اطلاعاتی ارسال نمی‌کند.\n" +
                "• پشتیبان‌گیری ابری برنامه خاموش است.\n" +
                "• شماره کارت و شبا پیش از ذخیره‌شدن متن پیامک، پوشانده می‌شود (فقط ۴ رقم آخر می‌ماند).\n" +
                "• اعلانی با متن پیامک نمایش داده نمی‌شود و متن پیامک در گزارش خطا ثبت نمی‌شود.\n" +
                "• دسترسی پیامک فقط برای تشخیص پیامک‌های بانکی است؛ هر زمان خواستی از «دریافت و تشخیص خودکار» خاموشش کن یا مجوز را در تنظیمات اندروید بگیر.\n" +
                "• حذف یک تراکنش: در «گزارش مالی»، روی تراکنش نگه‌دار.")
            .setNegativeButton("بستن", null)
            .setPositiveButton("حذف همه داده‌ها…") { _, _ -> confirmWipe() }
            .show()
    }

    private fun confirmWipe() {
        AlertDialog.Builder(this).setTitle("حذف همه داده‌ها؟")
            .setMessage("همه تراکنش‌ها، دسته‌ها و صندوق پیامک‌ها برای همیشه از این گوشی پاک می‌شود و قابل بازیابی نیست. پیامک‌های قدیمی دوباره خودکار وارد نمی‌شوند؛ فقط پیامک‌های جدید از این لحظه بررسی می‌شوند.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("حذف کن") { _, _ ->
                DataWiper.wipeAll(this); render()
                Toast.makeText(this, "همه داده‌ها حذف شد", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun updateAutoButton() {
        autoButton.text = "دریافت و تشخیص خودکار پیامک بانکی: " + if (SmsSettings.autoEnabled(this)) "روشن" else "خاموش"
    }

    /** Automatic catch-up of SMS that arrived while the app was closed. */
    private fun runCatchUp() {
        Thread {
            SmsCatchUp.run(this)
            runOnUiThread { if (!isFinishing && ::list.isInitialized) render() }
        }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); handleWidgetIntent(intent)
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) render(); runCatchUp() }

    private fun handleWidgetIntent(intent: Intent?) {
        if (intent?.action == "ADD_TRANSACTION") showAddDialog()
        if (intent?.action == "CATEGORIZE_TRANSACTION") intent.getStringExtra("transaction_id")?.let { showCategoryDialog(it) }
    }

    private fun updateUnitButton() {
        val unit = DisplaySettings.get(this)
        val other = if (unit == ir.hesabyar.app.money.Currency.TOMAN) ir.hesabyar.app.money.Currency.RIAL else ir.hesabyar.app.money.Currency.TOMAN
        unitButton.text = "واحد نمایش مبلغ: ${unit.labelFa} (تغییر به ${other.labelFa})"
    }

    private fun hasPermission(permission: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun explainAndRequestSmsPermissions() {
        val missing = smsPermissions.filterNot { hasPermission(it) }
        if (missing.isEmpty()) {
            AlertDialog.Builder(this).setTitle("دسترسی پیامک فعال است")
                .setMessage("دریافت پیامک‌های جدید فعال است. برای واردکردن پیامک‌های قبلی نیز می‌توانی از دکمه مربوط استفاده کنی.")
                .setPositiveButton("باشه", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("اجازه دسترسی به پیامک‌ها")
            .setMessage("حساب‌یار برای شناسایی پیامک‌های بانکی به دریافت پیامک‌های جدید نیاز دارد. برای واردکردن پیامک‌های ۹۰ روز اخیر، دسترسی خواندن پیامک‌ها هم لازم است. فقط پیامک‌هایی که شبیه تراکنش مالی هستند روی همین گوشی ذخیره می‌شوند و شماره کارت در آن‌ها پوشانده می‌شود. برنامه مجوز اینترنت ندارد و هیچ پیامکی ارسال نمی‌شود. هر زمان بخواهی می‌توانی همه داده‌ها را حذف کنی. ممکن است اندروید یا روش نصب APK دسترسی را محدود کند.")
            .setNegativeButton("فعلاً نه", null)
            .setPositiveButton("ادامه و درخواست مجوز") { _, _ -> requestPermissions(missing.toTypedArray(), smsRequestCode) }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == smsRequestCode) {
            val granted = permissions.zip(grantResults.toList()).filter { it.second == PackageManager.PERMISSION_GRANTED }.map { it.first }
            val message = buildString {
                append(if (granted.isEmpty()) "مجوزی داده نشد." else "مجوزهای تأییدشده: ${granted.joinToString()}.")
                if (!hasPermission(Manifest.permission.RECEIVE_SMS)) append(" دریافت پیامک جدید فعال نیست.")
                if (!hasPermission(Manifest.permission.READ_SMS)) append(" واردکردن پیامک‌های قبلی فعال نیست.")
                append(" اگر اندروید دسترسی را مسدود کرده، وضعیت مجوزها را در تنظیمات برنامه بررسی کن.")
            }
            runCatchUp()
            AlertDialog.Builder(this).setTitle("وضعیت دسترسی").setMessage(message).setPositiveButton("باشه", null).show()
        }
    }

    private fun importHistory() {
        if (!hasPermission(Manifest.permission.READ_SMS)) {
            explainAndRequestSmsPermissions(); return
        }
        AlertDialog.Builder(this).setTitle("واردکردن پیامک‌های قبلی")
            .setMessage("تا ۱۰۰۰ پیامک دریافتی از ۹۰ روز اخیر بررسی می‌شود. فقط پیامک‌های مشکوک به تراکنش مالی ذخیره می‌شوند. متن سایر پیامک‌ها ذخیره نخواهد شد. ادامه می‌دهی؟")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("شروع") { _, _ ->
                try {
                    val result = SmsHistoryImporter.importRecent(this)
                    render()
                    AlertDialog.Builder(this).setTitle("پایان بررسی")
                        .setMessage("بررسی‌شده: ${result.scanned}\nذخیره‌شده: ${result.saved}\nتکراری یا غیرمالی: ${result.duplicatesOrSkipped}")
                        .setPositiveButton("مشاهده صندوق") { _, _ -> startActivity(Intent(this, SmsInboxActivity::class.java)) }.show()
                } catch (e: SecurityException) {
                    Toast.makeText(this, "دسترسی خواندن پیامک داده نشده است.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "خطا در واردکردن پیامک‌ها: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun render() {
        list.removeAllViews()
        val items = TransactionStore.pending(this)
        if (items.isEmpty()) list.addView(Ui.glass(this, 18).apply {
            addView(Ui.text(context, "همه تراکنش‌ها دسته‌بندی شده‌اند ✓", 15f, ink).apply { gravity = Gravity.CENTER })
        }, Ui.margins(this, 0, 8))
        items.forEach { tx ->
            val card = Ui.glass(this, 14)
            card.addView(Ui.text(this, tx.title, 16f, ink, true))
            card.addView(Ui.text(this, "${tx.bank}  •  ${tx.time}", 12f, Ui.muted))
            card.addView(Ui.text(this, AmountFormatter.formatSigned(tx.amount, tx.isIncome, tx.currencyType, DisplaySettings.get(this)), 15f,
                if (tx.isIncome) Ui.green else Ui.red, true).apply { setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8)) })
            card.addView(Ui.primary(this, "انتخاب دسته‌بندی") { showCategoryDialog(tx.id) })
            list.addView(card, Ui.margins(this, 0, 10))
        }
    }

    private fun showCategoryDialog(id: String) {
        CategoryPicker.show(this, "دسته‌بندی تراکنش") { picked ->
            TransactionStore.categorize(this, id, picked); PendingTransactionsWidget.updateAll(this); render()
        }
    }

    private fun showAddDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22,8,22,0) }
        val titleInput = EditText(this).apply { hint = "عنوان تراکنش" }
        val unit = DisplaySettings.get(this)
        val amountInput = EditText(this).apply { hint = "مبلغ به ${unit.labelFa}"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("هزینه", "درآمد")) }
        panel.addView(titleInput); panel.addView(amountInput); panel.addView(type)
        AlertDialog.Builder(this).setTitle("ثبت دستی تراکنش").setView(panel).setPositiveButton("ثبت") { _, _ ->
            val amount = TextNormalizer.normalize(amountInput.text.toString()).replace(",", "").trim().toLongOrNull()
            // Stored exactly as typed, together with the unit the user was typing in.
            if (amount != null && amount > 0) { TransactionStore.add(this, titleInput.text.toString(), amount, type.selectedItemPosition == 1, unit); PendingTransactionsWidget.updateAll(this); render() }
            else Toast.makeText(this, "مبلغ معتبر وارد کن", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("لغو", null).show()
    }
}
