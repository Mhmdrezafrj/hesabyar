package ir.hesabyar.app.money

/**
 * Currency of a STORED amount. Every transaction records its own currency so the raw
 * number is never ambiguous. Bank SMS amounts (Bank Melli) are RIAL and stored as-is.
 *
 * New currencies/units for other banks can be added here later without touching
 * existing data.
 */
enum class Currency(val code: String, val labelFa: String) {
    RIAL("IRR", "ریال"),
    TOMAN("IRT", "تومان");

    companion object {
        /**
         * Rows saved before currency tracking existed have no code. Those amounts were
         * typed/shown in Toman, so the safe default is TOMAN (no conversion is applied).
         */
        fun fromCode(code: String?): Currency =
            values().firstOrNull { it.code == code } ?: TOMAN
    }
}
