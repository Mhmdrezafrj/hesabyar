package ir.hesabyar.app

import android.view.View

/** Keeps content below the status bar / above the navigation bar on Android 15 edge-to-edge. */
object SystemInsets {
    @Suppress("DEPRECATION")
    fun apply(view: View) {
        val l = view.paddingLeft; val t = view.paddingTop; val r = view.paddingRight; val b = view.paddingBottom
        view.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(l + insets.systemWindowInsetLeft, t + insets.systemWindowInsetTop, r + insets.systemWindowInsetRight, b + insets.systemWindowInsetBottom)
            insets
        }
        view.requestApplyInsets()
    }
}
