package ir.hesabyar.app

import android.content.Context
import ir.hesabyar.app.widget.WidgetConfig

/** Persistent (SharedPreferences) storage of widget customisation; survives restart. */
object WidgetConfigStore {
    private const val PREFS = "hesabyar_widget"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): WidgetConfig {
        val d = WidgetConfig()
        val s = p(c)
        return WidgetConfig(
            count = s.getInt("count", d.count),
            titleFont = s.getInt("titleFont", d.titleFont),
            amountFont = s.getInt("amountFont", d.amountFont),
            metaFont = s.getInt("metaFont", d.metaFont),
            opacityPercent = s.getInt("opacity", d.opacityPercent),
            style = s.getInt("style", d.style),
            showWallet = s.getBoolean("showWallet", d.showWallet),
            showDate = s.getBoolean("showDate", d.showDate),
            showBalance = s.getBoolean("showBalance", d.showBalance)
        ).sanitized()
    }

    fun save(c: Context, cfg: WidgetConfig) {
        val v = cfg.sanitized()
        p(c).edit()
            .putInt("count", v.count).putInt("titleFont", v.titleFont).putInt("amountFont", v.amountFont)
            .putInt("metaFont", v.metaFont).putInt("opacity", v.opacityPercent).putInt("style", v.style)
            .putBoolean("showWallet", v.showWallet).putBoolean("showDate", v.showDate).putBoolean("showBalance", v.showBalance)
            .apply()
    }
}
