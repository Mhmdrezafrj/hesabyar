package ir.hesabyar.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.parser.BankParserRegistry
import ir.hesabyar.app.parser.ParseResult
import ir.hesabyar.app.parser.ParsedTransaction
import ir.hesabyar.app.parser.TransactionType
import ir.hesabyar.app.privacy.PrivacyMask
import java.security.MessageDigest
import java.util.UUID

/**
 * Local SMS inbox. Every incoming message goes through the bank parsers first:
 *  - parsed with high confidence  -> saved (PARSED) AND registered as a transaction (once);
 *  - recognised bank but unclear  -> saved for manual review (REVIEW), no transaction;
 *  - bank's non-transaction SMS   -> not saved (e.g. OTP);
 *  - unknown format               -> old broad filter decides; saved as UNPARSED, no transaction.
 * No SMS content leaves this device.
 */
class SmsInboxStore(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    private val appContext: Context = context.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE sms_inbox (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fingerprint TEXT NOT NULL UNIQUE,
            sender TEXT NOT NULL,
            body TEXT NOT NULL,
            received_at INTEGER NOT NULL,
            source TEXT NOT NULL,
            review_state TEXT NOT NULL DEFAULT 'NEW',
            parse_status TEXT,
            parser_id TEXT,
            tx_type TEXT,
            amount INTEGER,
            currency TEXT,
            balance INTEGER,
            account_id TEXT,
            tx_time_text TEXT,
            review_reasons TEXT,
            dedup_key TEXT
        )""")
        db.execSQL("CREATE INDEX idx_sms_received_at ON sms_inbox(received_at DESC)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sms_dedup ON sms_inbox(dedup_key) WHERE dedup_key IS NOT NULL")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v1 -> v2: add parse columns. Existing rows are kept untouched (new columns are NULL).
        if (oldVersion < 2) {
            listOf(
                "parse_status TEXT", "parser_id TEXT", "tx_type TEXT", "amount INTEGER", "currency TEXT",
                "balance INTEGER", "account_id TEXT", "tx_time_text TEXT", "review_reasons TEXT", "dedup_key TEXT"
            ).forEach { db.execSQL("ALTER TABLE sms_inbox ADD COLUMN $it") }
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sms_dedup ON sms_inbox(dedup_key) WHERE dedup_key IS NOT NULL")
        }
    }

    /** Returns true when a NEW row was stored. */
    fun insertCandidate(sender: String?, body: String?, receivedAt: Long, source: String): Boolean {
        val safeSender = sender.orEmpty().trim().ifBlank { "فرستنده نامشخص" }
        val safeBody = body.orEmpty().trim()
        if (safeBody.isBlank()) return false

        return when (val result = BankParserRegistry.parse(safeBody)) {
            is ParseResult.Success -> {
                val inserted = insertRow(safeSender, safeBody, receivedAt, source, parsedValues(result.transaction))
                if (inserted) registerTransaction(result.transaction, receivedAt)
                inserted
            }
            is ParseResult.NeedsReview ->
                insertRow(safeSender, safeBody, receivedAt, source, reviewValues(result))
            is ParseResult.NotTransaction -> false
            ParseResult.NoParser -> {
                if (!SmsCandidateFilter.isLikelyFinancial(safeSender, safeBody)) false
                else insertRow(safeSender, safeBody, receivedAt, source, ContentValues().apply { put("parse_status", "UNPARSED") })
            }
        }
    }

    data class ReprocessResult(val scanned: Int, val newTransactions: Int, val review: Int, val duplicates: Int)

    /**
     * Re-runs the parsers over messages already stored (e.g. saved before the Bank Melli parser
     * existed). Nothing is deleted. Transactions are registered at most once (duplicate key).
     */
    fun reprocessStored(): ReprocessResult {
        class Row(val id: Long, val sender: String, val body: String, val receivedAt: Long)
        val rows = mutableListOf<Row>()
        readableDatabase.query("sms_inbox", arrayOf("id", "sender", "body", "received_at"),
            null, null, null, null, "received_at ASC").use { c ->
            while (c.moveToNext()) rows.add(Row(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3)))
        }
        var newTx = 0; var review = 0; var dup = 0
        val db = writableDatabase
        db.beginTransaction()
        try {
        for (row in rows) {
            val masked = PrivacyMask.mask(row.body)
            if (masked != row.body) {
                db.update("sms_inbox", ContentValues().apply { put("body", masked) }, "id=?", arrayOf(row.id.toString()))
            }
            when (val result = BankParserRegistry.parse(row.body)) {
                is ParseResult.Success -> {
                    val values = parsedValues(result.transaction)
                    try {
                        writableDatabase.update("sms_inbox", values, "id=?", arrayOf(row.id.toString()))
                        if (registerTransaction(result.transaction, row.receivedAt)) newTx++
                    } catch (_: SQLiteConstraintException) {
                        // Same bank message already stored under another row: keep raw copy, mark duplicate.
                        val v = ContentValues().apply { put("parse_status", "DUPLICATE"); putNull("dedup_key") }
                        writableDatabase.update("sms_inbox", v, "id=?", arrayOf(row.id.toString()))
                        dup++
                    }
                }
                is ParseResult.NeedsReview -> {
                    writableDatabase.update("sms_inbox", reviewValues(result), "id=?", arrayOf(row.id.toString()))
                    review++
                }
                is ParseResult.NotTransaction -> {
                    val v = ContentValues().apply { put("parse_status", "NOT_TRANSACTION"); put("review_state", "REJECTED") }
                    writableDatabase.update("sms_inbox", v, "id=?", arrayOf(row.id.toString()))
                }
                ParseResult.NoParser -> {
                    val v = ContentValues().apply { put("parse_status", "UNPARSED") }
                    writableDatabase.update("sms_inbox", v, "id=? AND parse_status IS NULL", arrayOf(row.id.toString()))
                }
            }
        }
        db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return ReprocessResult(rows.size, newTx, review, dup)
    }

    fun latest(limit: Int = 300): List<RawSms> {
        val result = mutableListOf<RawSms>()
        readableDatabase.query("sms_inbox",
            arrayOf("id", "sender", "body", "received_at", "source", "review_state",
                "parse_status", "tx_type", "amount", "currency", "balance", "review_reasons"),
            null, null, null, null, "received_at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) {
                result.add(RawSms(
                    id = c.getLong(0), sender = c.getString(1), body = c.getString(2),
                    receivedAt = c.getLong(3), source = c.getString(4), reviewState = c.getString(5),
                    parseStatus = if (c.isNull(6)) null else c.getString(6),
                    txType = if (c.isNull(7)) null else c.getString(7),
                    amount = if (c.isNull(8)) null else c.getLong(8),
                    currency = if (c.isNull(9)) null else c.getString(9),
                    balance = if (c.isNull(10)) null else c.getLong(10),
                    reviewReasons = if (c.isNull(11)) null else c.getString(11)
                ))
            }
        }
        return result
    }

    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM sms_inbox", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun delete(id: Long) { writableDatabase.delete("sms_inbox", "id=?", arrayOf(id.toString())) }

    private fun insertRow(sender: String, body: String, receivedAt: Long, source: String, extra: ContentValues): Boolean {
        val values = ContentValues(extra).apply {
            put("fingerprint", fingerprint(sender, body, receivedAt))
            put("sender", sender)
            put("body", PrivacyMask.mask(body))   // fingerprint above uses the original; stored text has no card numbers
            put("received_at", receivedAt)
            put("source", source)
            if (!containsKey("review_state")) put("review_state", "NEW")
        }
        return writableDatabase.insertWithOnConflict("sms_inbox", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    private fun parsedValues(t: ParsedTransaction) = ContentValues().apply {
        put("parse_status", "PARSED")
        put("parser_id", t.bankId)
        put("tx_type", t.type.name)
        put("amount", t.amount)
        put("currency", t.currency.code)
        put("balance", t.balance)
        put("account_id", t.accountId)
        put("tx_time_text", timeText(t))
        put("dedup_key", t.dedupKey)
        putNull("review_reasons")
        put("review_state", "NEW")
    }

    private fun reviewValues(r: ParseResult.NeedsReview) = ContentValues().apply {
        put("parse_status", "REVIEW")
        put("parser_id", r.bankId)
        put("review_reasons", r.reasons.joinToString(",") { it.name })
        r.partial.type?.let { put("tx_type", it.name) }
        r.partial.amount?.let { put("amount", it) }
        r.partial.balance?.let { put("balance", it) }
        r.partial.accountId?.let { put("account_id", it) }
        r.partial.timeText?.let { put("tx_time_text", it) }
        putNull("dedup_key")
        put("review_state", "NEEDS_REVIEW")
    }

    private fun registerTransaction(t: ParsedTransaction, receivedAt: Long): Boolean {
        val account = AmountFormatter.toPersianDigits(t.accountId)
        val title = if (t.type == TransactionType.DEPOSIT) "واریز به حساب $account" else "برداشت از حساب $account"
        val time = AmountFormatter.toPersianDigits(timeText(t))
        return TransactionStore.addFromSms(appContext, Transaction(
            id = UUID.randomUUID().toString(),
            title = title,
            bank = t.bankName,
            amount = t.amount,
            time = time,
            isIncome = t.type == TransactionType.DEPOSIT,
            currency = t.currency.code,
            source = "SMS",
            sourceRef = t.dedupKey,
            balance = t.balance,
            accountId = t.accountId,
            timestamp = receivedAt
        ))
    }

    private fun timeText(t: ParsedTransaction): String {
        fun two(n: Int) = n.toString().padStart(2, '0')
        return "${two(t.month)}/${two(t.day)} ${two(t.hour)}:${two(t.minute)}"
    }

    private fun fingerprint(sender: String, body: String, time: Long): String {
        val normalized = (sender.trim() + "|" + body.replace(Regex("\\s+"), " ").trim() + "|" + time).toByteArray(Charsets.UTF_8)
        return MessageDigest.getInstance("SHA-256").digest(normalized).joinToString("") { "%02x".format(it) }
    }

    companion object { private const val DB_NAME = "hesabyar_sms.db"; private const val DB_VERSION = 2 }
}

data class RawSms(
    val id: Long, val sender: String, val body: String, val receivedAt: Long, val source: String, val reviewState: String,
    val parseStatus: String? = null, val txType: String? = null, val amount: Long? = null,
    val currency: String? = null, val balance: Long? = null, val reviewReasons: String? = null
)

/** Broad intake filter for messages NO bank parser recognised. Not the bank/parser engine. */
object SmsCandidateFilter {
    private val terms = listOf(
        "برداشت", "واریز", "خرید", "انتقال", "تراکنش", "مانده", "موجودی", "کارت",
        "پرداخت", "شاپرک", "شتاب", "مبلغ", "حساب", "بانک", "رسید", "شارژ", "تومان", "ریال",
        "withdraw", "deposit", "transaction", "balance", "purchase", "transfer", "irr", "rial"
    )
    fun isLikelyFinancial(sender: String, body: String): Boolean {
        val text = normalize(sender + " " + body)
        return terms.any { text.contains(normalize(it)) } && body.length >= 5
    }
    private fun normalize(value: String): String = value
        .replace('ي', 'ی').replace('ك', 'ک')
        .replace('۰','0').replace('۱','1').replace('۲','2').replace('۳','3').replace('۴','4')
        .replace('۵','5').replace('۶','6').replace('۷','7').replace('۸','8').replace('۹','9')
        .lowercase()
}
