package ir.hesabyar.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Automatic catch-up, no button needed. Runs when the app opens, after phone restart and after an app update:
 *  1. once per parser version, re-parses messages already stored;
 *  2. imports inbox messages received since the last scan (first run: last 90 days).
 * Duplicates are impossible (semantic duplicate key). Blocking: call from a background thread.
 */
object SmsCatchUp {
    const val PARSER_VERSION = 2   // 2: also masks card numbers in already-stored SMS texts
    private const val OVERLAP_MS = 60L * 60 * 1000
    private val running = AtomicBoolean(false)

    fun hasReadPermission(context: Context) =
        context.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    fun run(context: Context): Int {
        val app = context.applicationContext
        if (!SmsSettings.autoEnabled(app)) return 0
        if (!running.compareAndSet(false, true)) return 0
        var added = 0
        try {
            if (SmsSettings.reprocessedVersion(app) < PARSER_VERSION) {
                SmsInboxStore(app).use { added += it.reprocessStored().newTransactions }
                SmsSettings.setReprocessedVersion(app, PARSER_VERSION)
            }
            if (hasReadPermission(app)) {
                val now = System.currentTimeMillis()
                val last = SmsSettings.lastScan(app)
                val since = if (last <= 0L) now - 90L * 24 * 60 * 60 * 1000 else last - OVERLAP_MS
                added += SmsHistoryImporter.importSince(app, since).saved
                SmsSettings.setLastScan(app, now)
            }
        } catch (_: Exception) {
            // never crash because of SMS access problems
        } finally {
            running.set(false)
        }
        PendingTransactionsWidget.updateAll(app)
        return added
    }
}
