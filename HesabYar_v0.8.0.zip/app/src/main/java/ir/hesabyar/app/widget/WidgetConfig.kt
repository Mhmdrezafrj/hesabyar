package ir.hesabyar.app.widget

/** User customisation of the home-screen widget. Always pass through [sanitized] after loading. */
data class WidgetConfig(
    val count: Int = 3,              // 3, 5 or 7 rows
    val titleFont: Int = 1,          // 0 small, 1 medium, 2 large
    val amountFont: Int = 1,
    val metaFont: Int = 1,           // time / description
    val opacityPercent: Int = 85,    // background opacity 30..100
    val style: Int = 0,              // 0 dark glass, 1 purple-blue
    val showWallet: Boolean = true,
    val showDate: Boolean = true,
    val showBalance: Boolean = true
) {
    fun sanitized() = copy(
        count = if (count in COUNTS) count else 3,
        titleFont = titleFont.coerceIn(0, 2),
        amountFont = amountFont.coerceIn(0, 2),
        metaFont = metaFont.coerceIn(0, 2),
        opacityPercent = opacityPercent.coerceIn(30, 100),
        style = style.coerceIn(0, 1)
    )

    companion object {
        val COUNTS = listOf(3, 5, 7)
        fun fontScale(level: Int): Float = when (level) { 0 -> 0.86f; 2 -> 1.18f; else -> 1f }
    }
}

object WidgetLayoutMath {
    private const val ROW_DP = 47
    private const val BASE_DP = 74          // padding + header + counter/details row
    private const val BALANCE_DP = 28

    /** How many rows fit in [heightDp] (0 = unknown -> use the wanted count). Always at least 1. */
    fun rowsThatFit(heightDp: Int, wanted: Int, showBalance: Boolean): Int {
        if (heightDp <= 0) return wanted
        val free = heightDp - BASE_DP - (if (showBalance) BALANCE_DP else 0)
        return (free / ROW_DP).coerceIn(1, wanted)
    }
}

/** Default categories (user can add / rename / delete them) and the two with special meaning. */
object Categories {
    const val INCOME = "درآمد"
    const val OTHER = "سایر"
    /** Moving money between the user's own accounts: never counted as income or expense. */
    const val TRANSFER = "انتقال بین حساب‌ها"
    const val UNCATEGORIZED_LABEL = "دسته‌بندی‌نشده"

    val defaults = listOf(
        "خوراک و مواد غذایی", "حمل‌ونقل", "خرید و پوشاک", "مسکن و اجاره", "قبوض",
        "درمان و سلامت", "تفریح", "آموزش", INCOME, TRANSFER, OTHER
    )
    val protectedNames = setOf(TRANSFER, OTHER)

    /** Category names used by earlier versions -> new names (applied once, no data lost). */
    val legacyRenames = mapOf(
        "خوراک" to "خوراک و مواد غذایی", "خرید" to "خرید و پوشاک", "مسکن" to "مسکن و اجاره",
        "سلامت" to "درمان و سلامت", "درآمد کاری" to INCOME
    )
}

/** Pure list operations for editing categories. [error] is a Persian message when the operation is refused. */
object CategoryOps {
    const val MAX_LEN = 30
    data class Result(val list: List<String>, val error: String? = null)

    fun clean(raw: String) = raw.trim().replace(Regex("\\s+"), " ")

    fun add(list: List<String>, raw: String): Result {
        val name = clean(raw)
        if (name.isEmpty()) return Result(list, "نام دسته خالی است")
        if (name.length > MAX_LEN) return Result(list, "نام دسته حداکثر ۳۰ نویسه")
        if (list.any { it == name }) return Result(list, "این دسته قبلاً وجود دارد")
        return Result(list + name)
    }

    fun rename(list: List<String>, old: String, raw: String): Result {
        if (old in Categories.protectedNames) return Result(list, "این دسته قابل تغییر نام نیست")
        val name = clean(raw)
        if (name.isEmpty()) return Result(list, "نام دسته خالی است")
        if (name.length > MAX_LEN) return Result(list, "نام دسته حداکثر ۳۰ نویسه")
        if (name != old && list.any { it == name }) return Result(list, "این دسته قبلاً وجود دارد")
        return Result(list.map { if (it == old) name else it })
    }

    fun delete(list: List<String>, name: String): Result {
        if (name in Categories.protectedNames) return Result(list, "این دسته قابل حذف نیست")
        return Result(list.filterNot { it == name })
    }
}
