package ir.hesabyar.app

import android.app.Activity
import android.os.Bundle
import ir.hesabyar.app.money.AmountFormatter

/** Tiny dialog opened from the widget: pick a category, widget refreshes, no app screen is shown. */
class QuickCategoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("transaction_id")
        val tx = TransactionStore.all(this).firstOrNull { it.id == id }
        if (id == null || tx == null || tx.category.isNotBlank()) {
            // already categorised or gone: just refresh the widget
            PendingTransactionsWidget.updateAll(this); finish(); return
        }
        val summary = AmountFormatter.format(tx.amount, tx.currencyType, DisplaySettings.get(this))
        CategoryPicker.show(this, "دسته‌بندی: " + (if (tx.isIncome) "+" else "−") + summary, onCancel = { finish() }) { picked ->
            TransactionStore.categorize(this, id, picked)
            PendingTransactionsWidget.updateAll(this)
            finish()
        }
    }
}
