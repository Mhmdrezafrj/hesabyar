package ir.hesabyar.app.parser

/**
 * One implementation per bank. Each parser lives in its own file and knows ONLY its own
 * bank's format, so adding a new bank can never change how an existing bank is parsed.
 *
 * Both methods receive already-normalised lines (see [TextNormalizer.lines]).
 * The sender number/name is deliberately NOT an input: it is not a reliable criterion.
 */
interface BankParser {
    val bankId: String
    val bankName: String

    /** Strict check: does this message have THIS bank's own header/format? */
    fun canHandle(lines: List<String>): Boolean

    /** Only called when [canHandle] returned true. Must never throw. */
    fun parse(lines: List<String>): ParseResult
}
