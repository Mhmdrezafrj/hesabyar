package ir.hesabyar.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Shared look of the app screens: pastel purple/blue/pink, soft glass cards, rounded buttons, RTL. */
object Ui {
    val ink = Color.rgb(45, 36, 79)
    val muted = Color.rgb(112, 103, 140)
    val green = Color.rgb(0, 140, 90)
    val red = Color.rgb(210, 55, 85)
    val purple = Color.rgb(124, 92, 255)
    val blue = Color.rgb(47, 128, 237)

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(radiusPx: Float, color: Int, strokeColor: Int? = null, strokePx: Int = 0) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE; cornerRadius = radiusPx; setColor(color)
        if (strokeColor != null) setStroke(strokePx, strokeColor)
    }

    /** Soft pastel gradient for the whole screen (lavender -> light blue -> pink). */
    fun pastelGradient() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(240, 233, 255), Color.rgb(226, 236, 255), Color.rgb(255, 232, 244))
    )

    /** Page root: vertical, RTL, gradient background, system-bar insets handled. */
    fun page(a: Activity): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(a, 16), dp(a, 20), dp(a, 16), dp(a, 12))
        background = pastelGradient()
    }

    /** Translucent white "glass" card. */
    fun glass(c: Context, pad: Int = 14): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(c, pad), dp(c, pad - 2), dp(c, pad), dp(c, pad - 2))
        background = rounded(dp(c, 20).toFloat(), Color.argb(190, 255, 255, 255), Color.argb(230, 255, 255, 255), dp(c, 1))
        elevation = dp(c, 2).toFloat()
    }

    fun margins(c: Context, top: Int = 0, bottom: Int = 10) =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, top); bottomMargin = dp(c, bottom) }

    fun text(c: Context, t: String, size: Float = 14f, color: Int = ink, bold: Boolean = false) = TextView(c).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    fun title(c: Context, t: String, sub: String? = null): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        addView(text(c, t, 26f, ink, true))
        if (sub != null) addView(text(c, sub, 13f, muted).apply { setPadding(0, dp(c, 4), 0, dp(c, 10)) })
    }

    private fun styleButton(b: Button, bg: GradientDrawable, textColor: Int) {
        val c = b.context
        b.background = bg; b.setTextColor(textColor); b.isAllCaps = false
        b.stateListAnimator = null; b.elevation = 0f
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10))
        b.minHeight = dp(c, 44); b.minimumHeight = dp(c, 44)
    }

    /** Main action: purple -> blue gradient pill. */
    fun primary(c: Context, label: String, onClick: () -> Unit) = Button(c).apply {
        text = label; setTypeface(null, Typeface.BOLD)
        styleButton(this, GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(purple, blue)).apply { cornerRadius = dp(c, 24).toFloat() }, Color.WHITE)
        setOnClickListener { onClick() }
    }

    /** Secondary action: soft translucent pill. */
    fun soft(c: Context, label: String, onClick: () -> Unit) = Button(c).apply {
        text = label
        styleButton(this, rounded(dp(c, 24).toFloat(), Color.argb(200, 255, 255, 255), Color.argb(120, 124, 92, 255), dp(c, 1)), ink)
        setOnClickListener { onClick() }
    }

    /** Square-ish home tile with emoji + caption. */
    fun tile(c: Context, emoji: String, label: String, tint: Int, onClick: () -> Unit): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(c, 8), dp(c, 14), dp(c, 8), dp(c, 12))
        background = rounded(dp(c, 22).toFloat(), tint, Color.argb(230, 255, 255, 255), dp(c, 1))
        elevation = dp(c, 2).toFloat()
        addView(text(c, emoji, 28f).apply { gravity = Gravity.CENTER })
        addView(text(c, label, 13f, ink, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(c, 6), 0, 0) })
        isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }

    /** Small rounded "chip" label (e.g. date badge). */
    fun chip(c: Context, t: String, color: Int = purple): TextView = TextView(c).apply {
        text = t; textSize = 12f; setTextColor(color); setTypeface(null, Typeface.BOLD)
        setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4))
        background = rounded(dp(c, 14).toFloat(), Color.argb(40, Color.red(color), Color.green(color), Color.blue(color)))
    }

    fun dot(c: Context, color: Int): View = View(c).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        layoutParams = LinearLayout.LayoutParams(dp(c, 10), dp(c, 10)).apply { marginStart = dp(c, 8) }
    }
}
