package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.widget.EditText
import android.widget.Toast
import ir.hesabyar.app.widget.CategoryOps

/** One shared "choose category" dialog (app, reports and widget) with "+ new category". */
object CategoryPicker {
    fun show(activity: Activity, title: String, onCancel: () -> Unit = {}, onPicked: (String) -> Unit) {
        val cats = CategoryStore.all(activity)
        val items = (cats + "＋ دسته جدید…").toTypedArray()
        AlertDialog.Builder(activity).setTitle(title)
            .setItems(items) { _, which ->
                if (which < cats.size) onPicked(cats[which]) else askNew(activity, onCancel, onPicked)
            }
            .setNegativeButton("انصراف") { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .show()
    }

    private fun askNew(activity: Activity, onCancel: () -> Unit, onPicked: (String) -> Unit) {
        val input = EditText(activity).apply { hint = "نام دسته جدید" }
        AlertDialog.Builder(activity).setTitle("دسته جدید").setView(input)
            .setPositiveButton("افزودن") { _, _ ->
                val name = CategoryOps.clean(input.text.toString())
                val error = CategoryStore.add(activity, name)
                if (error != null) { Toast.makeText(activity, error, Toast.LENGTH_SHORT).show(); onCancel() }
                else onPicked(name)
            }
            .setNegativeButton("لغو") { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .show()
    }
}
