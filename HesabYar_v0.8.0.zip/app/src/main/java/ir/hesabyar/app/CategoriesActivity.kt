package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import ir.hesabyar.app.widget.CategoryOps
import ir.hesabyar.app.widget.Categories

/** Add / rename / delete categories. */
class CategoriesActivity : Activity() {
    private val ink = Ui.ink
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)
        root.addView(Ui.title(this, "مدیریت دسته‌ها", "با تغییر نام، تراکنش‌های آن دسته هم به‌روز می‌شوند. با حذف، تراکنش‌ها به «سایر» می‌روند. دسته‌های «سایر» و «انتقال بین حساب‌ها» ثابت‌اند؛ انتقال بین حساب‌ها در گزارش‌ها دوباره‌شماری نمی‌شود."))
        root.addView(Ui.primary(this, "＋ افزودن دسته") { askName("دسته جدید", "") { n ->
            CategoryStore.add(this@CategoriesActivity, n)?.let { Toast.makeText(this@CategoriesActivity, it, Toast.LENGTH_SHORT).show() }; render() } }, Ui.margins(this, 0, 10))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)
        render()
    }

    private fun render() {
        list.removeAllViews()
        CategoryStore.all(this).forEach { name ->
            val row = Ui.glass(this, 12).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = name; textSize = 15f; setTextColor(ink) }, LinearLayout.LayoutParams(0, -2, 1f))
            if (name in Categories.protectedNames) {
                row.addView(TextView(this).apply { text = "ثابت"; textSize = 12f; setTextColor(Color.GRAY) })
            } else {
                row.addView(Ui.soft(this, "ویرایش") { askName("تغییر نام دسته", name) { n ->
                    CategoryStore.rename(this@CategoriesActivity, name, n)?.let { Toast.makeText(this@CategoriesActivity, it, Toast.LENGTH_SHORT).show() }; render() } }
                row.addView(Ui.soft(this, "حذف") {
                    AlertDialog.Builder(this@CategoriesActivity).setTitle("حذف «$name»؟")
                        .setMessage("تراکنش‌های این دسته به «سایر» منتقل می‌شوند.")
                        .setNegativeButton("انصراف", null)
                        .setPositiveButton("حذف") { _, _ -> CategoryStore.delete(this@CategoriesActivity, name); render() }.show() }
            }
            list.addView(row, Ui.margins(this, 0, 8))
        }
    }

    private fun askName(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply { setText(initial); hint = "نام دسته" }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setNegativeButton("لغو", null)
            .setPositiveButton("تأیید") { _, _ -> onOk(CategoryOps.clean(input.text.toString())) }.show()
    }
}
