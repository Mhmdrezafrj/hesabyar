package ir.hesabyar.app.widget

import ir.hesabyar.app.Transaction

/**
 * The widget shows the NEWEST uncategorised transactions from the WHOLE history
 * (not only today). Categorised ones can never appear.
 */
object PendingQueue {
    /** All uncategorised, newest first (stable for equal timestamps). */
    fun pending(all: List<Transaction>): List<Transaction> =
        all.filter { it.category.isBlank() }.sortedByDescending { it.timestamp }

    fun visible(all: List<Transaction>, limit: Int): List<Transaction> = pending(all).take(limit)

    /**
     * Latest balance known from a real bank SMS: the newest transaction that carries a balance.
     * Returns null when there is none (the widget then hides the balance).
     */
    fun latestBalance(all: List<Transaction>): Transaction? =
        all.filter { it.balance != null }.maxByOrNull { it.timestamp }
}
