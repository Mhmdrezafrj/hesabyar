package ir.hesabyar.app

import android.content.Context
import ir.hesabyar.app.widget.CategoryOps
import ir.hesabyar.app.widget.Categories
import org.json.JSONArray

/** User-editable category list (persistent). First run: defaults + one-time rename of old category names. */
object CategoryStore {
    private const val PREFS = "hesabyar_categories"
    private const val KEY = "list"

    @Synchronized
    fun all(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw == null) {
            Categories.legacyRenames.forEach { (old, new) -> TransactionStore.renameCategory(context, old, new) }
            save(context, Categories.defaults)
            return Categories.defaults
        }
        val array = JSONArray(raw)
        return (0 until array.length()).map { array.getString(it) }
    }

    private fun save(context: Context, list: List<String>) {
        val array = JSONArray(); list.forEach { array.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    /** Returns a Persian error message, or null on success. */
    @Synchronized
    fun add(context: Context, name: String): String? {
        val r = CategoryOps.add(all(context), name)
        if (r.error == null) save(context, r.list)
        return r.error
    }

    @Synchronized
    fun rename(context: Context, old: String, name: String): String? {
        val r = CategoryOps.rename(all(context), old, name)
        if (r.error == null) {
            save(context, r.list)
            TransactionStore.renameCategory(context, old, CategoryOps.clean(name))
        }
        return r.error
    }

    /** Transactions of the deleted category are moved to "سایر" (nothing is lost, nothing returns to the pending queue). */
    @Synchronized
    fun delete(context: Context, name: String): String? {
        val r = CategoryOps.delete(all(context), name)
        if (r.error == null) {
            save(context, r.list)
            TransactionStore.renameCategory(context, name, Categories.OTHER)
        }
        return r.error
    }
}
