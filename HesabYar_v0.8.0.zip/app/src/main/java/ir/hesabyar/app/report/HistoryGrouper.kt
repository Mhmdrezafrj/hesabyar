package ir.hesabyar.app.report

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.widget.JalaliCalendar
import java.util.Calendar
import java.util.TimeZone

data class DayGroup(
    val year: Int, val month: Int, val day: Int, val weekdayName: String,
    val transactions: List<Transaction>, val totals: Totals
)

data class MonthGroup(
    val year: Int, val month: Int, val days: List<DayGroup>, val totals: Totals, val count: Int
) {
    val monthName: String get() = JalaliCalendar.monthNames[month - 1]
}

/** [months] newest first; [undated] = old rows saved before dates were recorded (timestamp 0). */
data class History(val months: List<MonthGroup>, val undated: List<Transaction>)

/** Groups transactions by Jalali month, then Jalali day (newest first). Pure and unit-tested. */
class HistoryGrouper(private val zone: TimeZone = TimeZone.getDefault()) {

    private val weekdays = mapOf(
        Calendar.SATURDAY to "شنبه", Calendar.SUNDAY to "یکشنبه", Calendar.MONDAY to "دوشنبه",
        Calendar.TUESDAY to "سه‌شنبه", Calendar.WEDNESDAY to "چهارشنبه", Calendar.THURSDAY to "پنجشنبه",
        Calendar.FRIDAY to "جمعه"
    )

    fun group(all: List<Transaction>): History {
        val undated = all.filter { it.timestamp <= 0 }
        val dated = all.filter { it.timestamp > 0 }.sortedByDescending { it.timestamp }

        class Key(val y: Int, val m: Int, val d: Int, val weekday: String)
        fun keyOf(ts: Long): Key {
            val c = Calendar.getInstance(zone); c.timeInMillis = ts
            val j = JalaliCalendar.fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
            return Key(j.year, j.month, j.day, weekdays[c.get(Calendar.DAY_OF_WEEK)] ?: "")
        }

        val byDay = LinkedHashMap<Triple<Int, Int, Int>, Pair<Key, MutableList<Transaction>>>()
        dated.forEach { t ->
            val k = keyOf(t.timestamp)
            byDay.getOrPut(Triple(k.y, k.m, k.d)) { Pair(k, mutableListOf()) }.second.add(t)
        }
        val dayGroups = byDay.values.map { (k, list) ->
            DayGroup(k.y, k.m, k.d, k.weekday, list, TotalsMath.totals(list))
        }
        val months = dayGroups.groupBy { it.year to it.month }
            .map { (ym, days) ->
                val sortedDays = days.sortedByDescending { it.day }
                val txs = sortedDays.flatMap { it.transactions }
                MonthGroup(ym.first, ym.second, sortedDays, TotalsMath.totals(txs), txs.size)
            }
            .sortedWith(compareByDescending<MonthGroup> { it.year }.thenByDescending { it.month })
        return History(months, undated)
    }
}
