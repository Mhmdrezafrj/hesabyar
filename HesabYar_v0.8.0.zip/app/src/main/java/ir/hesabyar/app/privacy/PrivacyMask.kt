package ir.hesabyar.app.privacy

import ir.hesabyar.app.parser.TextNormalizer

/**
 * Removes full card numbers / IBANs from SMS text BEFORE it is stored (the parser still works on the
 * original text in memory). Only the last 4 digits are kept. Short account ids (e.g. 60007) and amounts are untouched.
 */
object PrivacyMask {
    private val grouped = Regex("(?<!\\d)\\d{4}[ -]\\d{4}[ -]\\d{4}[ -]\\d{1,7}(?!\\d)")
    private val plain = Regex("(?<!\\d)\\d{13,19}(?!\\d)")
    private val iban = Regex("(?i)(?<![A-Za-z0-9])IR\\d{24}(?!\\d)")

    private fun last4(s: String) = s.filter { it.isDigit() }.takeLast(4)

    /** Returns [text] unchanged when nothing sensitive is found; otherwise a normalised, masked copy. */
    fun mask(text: String): String {
        val n = TextNormalizer.normalize(text)
        if (!grouped.containsMatchIn(n) && !plain.containsMatchIn(n) && !iban.containsMatchIn(n)) return text
        return n
            .replace(grouped) { "****-****-****-" + last4(it.value) }
            .replace(plain) { "****-****-****-" + last4(it.value) }
            .replace(iban) { "IR**********************" + last4(it.value) }
    }
}
