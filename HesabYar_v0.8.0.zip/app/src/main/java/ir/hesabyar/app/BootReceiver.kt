package ir.hesabyar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After phone restart or app update: catch up missed SMS and refresh the widget. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val pending = goAsync()
        val app = context.applicationContext
        Thread {
            try { SmsCatchUp.run(app) } catch (_: Exception) {} finally {
                try { PendingTransactionsWidget.updateAll(app) } catch (_: Exception) {}
                pending.finish()
            }
        }.start()
    }
}
