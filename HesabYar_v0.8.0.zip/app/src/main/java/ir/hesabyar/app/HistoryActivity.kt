package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.report.History
import ir.hesabyar.app.report.HistoryGrouper
import ir.hesabyar.app.report.MonthGroup
import ir.hesabyar.app.widget.Categories
import ir.hesabyar.app.widget.JalaliCalendar
import java.util.Calendar

/**
 * Transactions grouped by Jalali month, then Jalali day. Tap a month to expand/collapse it.
 * Tap a transaction to change its category; long-press to delete (same rules as the reports screen).
 * All data comes from the real local store; nothing is sent anywhere.
 */
class HistoryActivity : Activity() {
    private lateinit var body: LinearLayout
    private val expanded = HashSet<String>()
    private var firstRender = true

    private fun fa(s: String) = AmountFormatter.toPersianDigits(s)
    private fun money(rial: Long) = AmountFormatter.format(rial, Currency.RIAL, DisplaySettings.get(this))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)
        root.addView(Ui.title(this, "تاریخچه تراکنش‌ها", "دسته‌بندی روزانه و ماهانه بر اساس تاریخ شمسی"))
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isFillViewport = false; addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        body.removeAllViews()
        val history = HistoryGrouper().group(TransactionStore.all(this))
        if (history.months.isEmpty() && history.undated.isEmpty()) {
            body.addView(Ui.glass(this, 20).apply {
                addView(Ui.text(context, "هنوز تراکنشی ثبت نشده است.", 15f, Ui.muted).apply { gravity = Gravity.CENTER })
            }, Ui.margins(this, 20))
            return
        }
        if (firstRender) {   // open the newest month by default
            history.months.firstOrNull()?.let { expanded.add(key(it)) }
            firstRender = false
        }
        history.months.forEach { body.addView(monthCard(it), Ui.margins(this, 0, 12)) }
        if (history.undated.isNotEmpty()) body.addView(undatedCard(history), Ui.margins(this, 0, 12))
    }

    private fun key(m: MonthGroup) = "${m.year}-${m.month}"

    private fun monthCard(m: MonthGroup): View {
        val card = Ui.glass(this, 14)
        val open = key(m) in expanded
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isClickable = true
            setOnClickListener { if (!expanded.remove(key(m))) expanded.add(key(m)); render() }
        }
        header.addView(Ui.text(this, "${m.monthName} ${fa("${m.year}")}", 18f, Ui.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Ui.chip(this, "${fa("${m.count}")} تراکنش"))
        header.addView(Ui.text(this, if (open) "  ▲" else "  ▼", 12f, Ui.muted))
        card.addView(header)
        card.addView(totalsLine(m.totals.expenseRial, m.totals.incomeRial).apply { setPadding(0, Ui.dp(context, 6), 0, 0) })
        if (open) m.days.forEach { d ->
            val dayHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 4))
            }
            dayHeader.addView(Ui.text(this, "${d.weekdayName} ${fa("${d.day}")} ${JalaliCalendar.monthNames[d.month - 1]}", 15f, Ui.purple, true), LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(dayHeader)
            card.addView(totalsLine(d.totals.expenseRial, d.totals.incomeRial))
            d.transactions.forEach { card.addView(txRow(it), Ui.margins(this, 6, 0)) }
        }
        return card
    }

    private fun undatedCard(h: History): View {
        val card = Ui.glass(this, 14)
        val k = "undated"
        val open = k in expanded
        card.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL; isClickable = true
            setOnClickListener { if (!expanded.remove(k)) expanded.add(k); render() }
            addView(Ui.text(context, "بدون تاریخ", 17f, Ui.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.chip(context, "${fa("${h.undated.size}")} تراکنش", Ui.muted))
            addView(Ui.text(context, if (open) "  ▲" else "  ▼", 12f, Ui.muted))
        })
        card.addView(Ui.text(this, "تراکنش‌های قدیمی که تاریخ دقیقشان ذخیره نشده است.", 12f, Ui.muted))
        if (open) h.undated.forEach { card.addView(txRow(it), Ui.margins(this, 6, 0)) }
        return card
    }

    private fun totalsLine(expense: Long, income: Long): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        addView(Ui.text(context, "هزینه: ${money(expense)}", 12f, Ui.red, true), LinearLayout.LayoutParams(0, -2, 1f))
        addView(Ui.text(context, "درآمد: ${money(income)}", 12f, Ui.green, true), LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun clock(ts: Long): String {
        if (ts <= 0) return ""
        val c = Calendar.getInstance().apply { timeInMillis = ts }
        fun two(n: Int) = n.toString().padStart(2, '0')
        return fa("${two(c.get(Calendar.HOUR_OF_DAY))}:${two(c.get(Calendar.MINUTE))}")
    }

    private fun txRow(tx: Transaction): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(context, 4), Ui.dp(context, 8), Ui.dp(context, 4), Ui.dp(context, 8))
            isClickable = true
        }
        row.addView(Ui.dot(this, if (tx.isIncome) Ui.green else Ui.red))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(Ui.text(this, tx.title, 14f, Ui.ink, true))
        val cat = if (tx.category.isBlank()) Categories.UNCATEGORIZED_LABEL else tx.category
        val time = clock(tx.timestamp).let { if (it.isEmpty()) tx.time else it }
        mid.addView(Ui.text(this, "${tx.bank} • $time • $cat", 11f, Ui.muted))
        row.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Ui.text(this, AmountFormatter.formatSigned(tx.amount, tx.isIncome, tx.currencyType, DisplaySettings.get(this)), 13f,
            if (tx.isIncome) Ui.green else Ui.red, true))
        row.setOnClickListener {
            CategoryPicker.show(this, "تغییر دسته: ${tx.title}") { picked ->
                TransactionStore.categorize(this, tx.id, picked)
                PendingTransactionsWidget.updateAll(this); render()
            }
        }
        row.setOnLongClickListener {
            AlertDialog.Builder(this).setTitle("حذف تراکنش؟")
                .setMessage("«${tx.title}» حذف می‌شود. اگر از پیامک ساخته شده باشد، دوباره خودکار ثبت نخواهد شد.")
                .setNegativeButton("انصراف", null)
                .setPositiveButton("حذف") { _, _ ->
                    TransactionStore.delete(this, tx.id); PendingTransactionsWidget.updateAll(this); render()
                }.show()
            true
        }
        return row
    }
}
