package ir.hesabyar.app

data class Transaction(
    val id: String,
    val title: String,
    val bank: String,
    val amount: Long,
    val time: String,
    val isIncome: Boolean,
    val category: String = ""
)
