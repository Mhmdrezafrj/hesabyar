package ir.hesabyar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import java.text.DecimalFormat

class PendingTransactionsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, PendingTransactionsWidget::class.java)
            manager.getAppWidgetIds(component).forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_pending)
            val pending = TransactionStore.pending(context).take(3)
            views.setViewVisibility(R.id.widget_empty, if (pending.isEmpty()) View.VISIBLE else View.GONE)
            views.setViewVisibility(R.id.widget_rows, if (pending.isEmpty()) View.GONE else View.VISIBLE)

            val rowIds = listOf(R.id.row_one, R.id.row_two, R.id.row_three)
            val titleIds = listOf(R.id.tx_title_one, R.id.tx_title_two, R.id.tx_title_three)
            val metaIds = listOf(R.id.tx_meta_one, R.id.tx_meta_two, R.id.tx_meta_three)
            val amountIds = listOf(R.id.tx_amount_one, R.id.tx_amount_two, R.id.tx_amount_three)
            val categoryIds = listOf(R.id.tx_categorize_one, R.id.tx_categorize_two, R.id.tx_categorize_three)
            val number = DecimalFormat("#,###")
            rowIds.forEachIndexed { index, rowId ->
                if (index < pending.size) {
                    val tx = pending[index]
                    views.setViewVisibility(rowId, View.VISIBLE)
                    views.setTextViewText(titleIds[index], tx.title)
                    views.setTextViewText(metaIds[index], "${tx.bank} • ${tx.time}")
                    val sign = if (tx.isIncome) "+" else "−"
                    views.setTextViewText(amountIds[index], "$sign${number.format(tx.amount)}")
                    views.setTextColor(amountIds[index],
                        if (tx.isIncome) 0xFF07945B.toInt() else 0xFFD9435D.toInt())
                    val intent = Intent(context, MainActivity::class.java).apply {
                        action = "CATEGORIZE_TRANSACTION"
                        putExtra("transaction_id", tx.id)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    val pi = PendingIntent.getActivity(context, tx.id.hashCode(), intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    views.setOnClickPendingIntent(categoryIds[index], pi)
                } else {
                    views.setViewVisibility(rowId, View.GONE)
                }
            }

            val addIntent = Intent(context, MainActivity::class.java).apply {
                action = "ADD_TRANSACTION"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val addPi = PendingIntent.getActivity(context, 9001, addIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_add, addPi)
            manager.updateAppWidget(id, views)
        }

        private fun childId(parent: Int, child: Int): Int {
            // Included row layouts expose their child IDs directly in RemoteViews.
            return child
        }
    }
}
