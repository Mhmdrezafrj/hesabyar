package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val purple = Color.rgb(112, 87, 232)
    private val ink = Color.rgb(45, 36, 79)
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 20)
            setBackgroundColor(Color.rgb(246, 242, 255))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val title = TextView(this).apply {
            text = "حساب‌یار"
            textSize = 26f
            setTextColor(ink)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "تراکنش‌هایی که هنوز دسته‌بندی نشده‌اند"
            textSize = 14f
            setTextColor(Color.rgb(105, 96, 130))
            setPadding(0, 6, 0, 18)
        }
        root.addView(subtitle)
        val add = Button(this).apply {
            text = "+ افزودن دستی تراکنش"
            setOnClickListener { showAddDialog() }
        }
        root.addView(add)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val action = intent?.action
        if (action == "ADD_TRANSACTION") showAddDialog()
        if (action == "CATEGORIZE_TRANSACTION") {
            val id = intent.getStringExtra("transaction_id")
            if (id != null) showCategoryDialog(id)
        }
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == "ADD_TRANSACTION") showAddDialog()
        if (intent.action == "CATEGORIZE_TRANSACTION") {
            intent.getStringExtra("transaction_id")?.let { showCategoryDialog(it) }
        }
    }

    private fun render() {
        list.removeAllViews()
        val items = TransactionStore.pending(this)
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "همه تراکنش‌ها دسته‌بندی شده‌اند ✓"
                textSize = 16f; setTextColor(ink); gravity = Gravity.CENTER
                setPadding(12, 40, 12, 40)
            })
        }
        items.forEach { tx ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundColor(Color.WHITE)
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val heading = TextView(this).apply {
                text = tx.title
                textSize = 16f; setTextColor(ink)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }
            val details = TextView(this).apply {
                text = "${tx.bank}  •  ${tx.time}"
                textSize = 12f; setTextColor(Color.GRAY)
            }
            val amount = TextView(this).apply {
                text = "${if (tx.isIncome) "+" else "−"}${tx.amount} تومان"
                textSize = 15f
                setTextColor(if (tx.isIncome) Color.rgb(0, 145, 88) else Color.rgb(215, 55, 78))
                setPadding(0, 8, 0, 8)
            }
            val button = Button(this).apply {
                text = "انتخاب دسته‌بندی"
                setOnClickListener { showCategoryDialog(tx.id) }
            }
            card.addView(heading); card.addView(details); card.addView(amount); card.addView(button)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = 12
            list.addView(card, params)
        }
    }

    private fun showCategoryDialog(id: String) {
        val categories = arrayOf("خوراک", "خرید", "حمل‌ونقل", "مسکن", "درآمد کاری", "قبوض", "سلامت", "سایر")
        AlertDialog.Builder(this)
            .setTitle("دسته‌بندی تراکنش")
            .setItems(categories) { _, which ->
                TransactionStore.categorize(this, id, categories[which])
                PendingTransactionsWidget.updateAll(this)
                render()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun showAddDialog() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 8, 22, 0)
        }
        val titleInput = EditText(this).apply { hint = "عنوان تراکنش" }
        val amountInput = EditText(this).apply {
            hint = "مبلغ به تومان"; inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("هزینه", "درآمد"))
        }
        panel.addView(titleInput); panel.addView(amountInput); panel.addView(type)
        AlertDialog.Builder(this).setTitle("ثبت دستی تراکنش").setView(panel)
            .setPositiveButton("ثبت") { _, _ ->
                val amount = amountInput.text.toString().toLongOrNull()
                if (amount != null && amount > 0) {
                    TransactionStore.add(this, titleInput.text.toString(), amount, type.selectedItemPosition == 1)
                    PendingTransactionsWidget.updateAll(this)
                    render()
                } else {
                    Toast.makeText(this, "مبلغ معتبر وارد کن", Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("لغو", null).show()
    }
}
