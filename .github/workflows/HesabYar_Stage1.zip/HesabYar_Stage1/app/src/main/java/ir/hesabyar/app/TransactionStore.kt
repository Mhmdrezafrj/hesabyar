package ir.hesabyar.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object TransactionStore {
    private const val PREFS = "hesabyar_local"
    private const val KEY = "transactions"

    fun all(context: Context): MutableList<Transaction> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw == null) {
            val samples = mutableListOf(
                Transaction("sample-1", "خرید سوپرمارکت", "بانک ملت", 320000, "امروز ۱۹:۴۷", false),
                Transaction("sample-2", "واریز حقوق", "بانک ملی", 8500000, "امروز ۱۰:۲۵", true),
                Transaction("sample-3", "هزینه تاکسی", "بانک سامان", 95000, "دیروز ۱۸:۱۰", false)
            )
            save(context, samples)
            return samples
        }
        val result = mutableListOf<Transaction>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(Transaction(
                o.getString("id"), o.getString("title"), o.getString("bank"),
                o.getLong("amount"), o.getString("time"), o.getBoolean("income"),
                o.optString("category", "")
            ))
        }
        return result
    }

    fun pending(context: Context) = all(context).filter { it.category.isBlank() }

    fun save(context: Context, transactions: List<Transaction>) {
        val array = JSONArray()
        transactions.forEach { t ->
            array.put(JSONObject().apply {
                put("id", t.id); put("title", t.title); put("bank", t.bank)
                put("amount", t.amount); put("time", t.time)
                put("income", t.isIncome); put("category", t.category)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    fun add(context: Context, title: String, amount: Long, income: Boolean) {
        val items = all(context)
        items.add(0, Transaction(UUID.randomUUID().toString(), title.ifBlank { "تراکنش دستی" },
            "ثبت دستی", amount, "همین الان", income))
        save(context, items)
    }

    fun categorize(context: Context, id: String, category: String) {
        val items = all(context).map {
            if (it.id == id) it.copy(category = category) else it
        }
        save(context, items)
    }
}
