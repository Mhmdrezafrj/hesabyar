package ir.hesabyar.app.ui

import ir.hesabyar.app.design.Contrast

/** Colour tokens of the app. Two complete palettes (light / dark); contrast is checked by unit tests. */
data class Palette(
    val dark: Boolean,
    val bgTop: Int, val bgMid: Int, val bgBottom: Int,
    val card: Int, val cardStroke: Int, val soft: Int, val softStroke: Int,
    val sheet: Int, val navBg: Int, val navStroke: Int,
    val ink: Int, val muted: Int,
    val accent: Int, val accent2: Int, val onAccent: Int,
    val green: Int, val red: Int, val amber: Int,
    val trackLine: Int, val pastel: List<Int>
)

object Palettes {
    private fun c(v: Long) = v.toInt()

    val light = Palette(
        dark = false,
        bgTop = c(0xFFF0E9FF), bgMid = c(0xFFE2ECFF), bgBottom = c(0xFFFFE8F4),
        card = c(0xBEFFFFFF), cardStroke = c(0xE6FFFFFF), soft = c(0xC8FFFFFF), softStroke = c(0x787C5CFF),
        sheet = c(0xFFFAF7FF), navBg = c(0xF5FFFFFF), navStroke = c(0xFFE2D8FF),
        ink = c(0xFF2D244F), muted = c(0xFF6A5F8C),
        accent = c(0xFF6B4DEB), accent2 = c(0xFF2F80ED), onAccent = c(0xFFFFFFFF),
        green = c(0xFF00805A), red = c(0xFFC8304F), amber = c(0xFFB86E00),
        trackLine = c(0x226B4DEB),
        pastel = listOf(c(0xFFEDE7FF), c(0xFFE0ECFF), c(0xFFFFE6F2), c(0xFFDEF7EC), c(0xFFFFF3DC))
    )

    val dark = Palette(
        dark = true,
        bgTop = c(0xFF0B0D17), bgMid = c(0xFF10142A), bgBottom = c(0xFF151B36),
        card = c(0xFF1A1F38), cardStroke = c(0xFF2A3157), soft = c(0xFF232949), softStroke = c(0xFF3A4375),
        sheet = c(0xFF171C33), navBg = c(0xFF161B33), navStroke = c(0xFF2A3157),
        ink = c(0xFFEEF0FA), muted = c(0xFFA3AACB),
        accent = c(0xFF8B7BFF), accent2 = c(0xFF4C7DFF), onAccent = c(0xFF10142A),
        green = c(0xFF3DDC97), red = c(0xFFFF7A97), amber = c(0xFFFFB547),
        trackLine = c(0x338B7BFF),
        pastel = listOf(c(0xFF26264A), c(0xFF1F2E4F), c(0xFF3A2540), c(0xFF1F3A38), c(0xFF3D3320))
    )

    const val SYSTEM = 0
    const val LIGHT = 1
    const val DARK = 2

    fun resolve(mode: Int, systemDark: Boolean): Palette = when (mode) { LIGHT -> light; DARK -> dark; else -> if (systemDark) dark else light }

    /** WCAG contrast ratio (1..21) between two colours (alpha colours are first blended over [over]). */
    fun ratio(fg: Int, bg: Int, over: Int = bg): Double {
        val b = Contrast.blend(bg, over)
        val a = Contrast.luminance(Contrast.blend(fg, b)); val d = Contrast.luminance(b)
        val hi = maxOf(a, d); val lo = minOf(a, d)
        return (hi + 0.05) / (lo + 0.05)
    }
}
