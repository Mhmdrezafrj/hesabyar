package ir.hesabyar.app

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.report.DashboardMath
import ir.hesabyar.app.report.MonthlyTrend
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.report.Summary
import ir.hesabyar.app.widget.JalaliCalendar
import ir.hesabyar.app.widget.PendingQueue
import java.util.Calendar

/** Builds the cards of the home screen (summary card, donut, trend, bottom bar). All data is computed elsewhere (tested). */
object DashboardUi {
    private val palette = intArrayOf(
        Color.rgb(124, 92, 255), Color.rgb(47, 128, 237), Color.rgb(255, 122, 168),
        Color.rgb(52, 195, 143), Color.rgb(255, 181, 71)
    )
    private val weekdays = mapOf(
        Calendar.SATURDAY to "شنبه", Calendar.SUNDAY to "یکشنبه", Calendar.MONDAY to "دوشنبه",
        Calendar.TUESDAY to "سه‌شنبه", Calendar.WEDNESDAY to "چهارشنبه", Calendar.THURSDAY to "پنجشنبه", Calendar.FRIDAY to "جمعه"
    )

    private fun fa(s: String) = AmountFormatter.toPersianDigits(s)

    fun todayText(now: Long): String {
        val c = Calendar.getInstance(); c.timeInMillis = now
        val j = JalaliCalendar.fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return fa("امروز، ${weekdays[c.get(Calendar.DAY_OF_WEEK)] ?: ""} ${j.day} ${JalaliCalendar.monthNames[j.month - 1]} ${j.year}")
    }

    private fun currentMonthName(now: Long): String {
        val c = Calendar.getInstance(); c.timeInMillis = now
        val j = JalaliCalendar.fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return JalaliCalendar.monthNames[j.month - 1]
    }

    /** Big gradient card: this month's spending, income, change vs last month, last known bank balance. */
    fun hero(a: Activity, all: List<Transaction>, s: Summary, unit: Currency, now: Long): View {
        fun money(rial: Long) = AmountFormatter.format(rial, Currency.RIAL, unit)
        val soft = Color.argb(215, 255, 255, 255)
        val card = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(a, 20), Ui.dp(a, 18), Ui.dp(a, 20), Ui.dp(a, 18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(124, 92, 255), Color.rgb(47, 128, 237), Color.rgb(98, 190, 255))).apply {
                cornerRadius = Ui.dp(a, 28).toFloat()
            }
            elevation = Ui.dp(a, 4).toFloat()
        }
        card.addView(Ui.text(a, "هزینهٔ ${currentMonthName(now)}", 13f, soft))
        card.addView(Ui.text(a, money(s.monthExpenseRial), 30f, Color.WHITE, true).apply { setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 6)) })
        val change = ReportCalculator.percentChange(s.monthExpenseRial, s.prevMonthExpenseRial)
        val changeText = when {
            change == null -> "ماه قبل هزینه‌ای برای مقایسه نیست"
            change > 0 -> "▲ ${fa("$change")}٪ بیشتر از ماه قبل"
            change < 0 -> "▼ ${fa("${-change}")}٪ کمتر از ماه قبل"
            else -> "برابر با ماه قبل"
        }
        card.addView(Ui.text(a, changeText, 12f, soft))
        card.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, Ui.dp(a, 14), 0, 0)
            addView(Ui.text(a, "درآمد: ${money(s.monthIncomeRial)}", 13f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            val bal = PendingQueue.latestBalance(all)
            if (bal != null && bal.balance != null) {
                addView(Ui.text(a, "آخرین مانده: ${AmountFormatter.format(bal.balance, bal.currencyType, unit)}", 12f, soft))
            }
        })
        return card
    }

    /** "SMS access is off" notice with a button; shown only while the permission is missing. */
    fun permissionBanner(a: Activity, onClick: () -> Unit): View {
        val card = Ui.glass(a, 14)
        card.addView(Ui.text(a, "دریافت خودکار پیامک بانکی خاموش است", 14f, Ui.ink, true))
        card.addView(Ui.text(a, "برای ثبت خودکار تراکنش‌ها، دسترسی پیامک را فعال کن.", 12f, Ui.muted).apply { setPadding(0, Ui.dp(a, 2), 0, Ui.dp(a, 8)) })
        card.addView(Ui.primary(a, "فعال‌سازی") { onClick() })
        return card
    }

    /** Ring chart of this month's spending per category with a legend. */
    fun donutCard(a: Activity, s: Summary): View {
        val card = Ui.glass(a, 16)
        card.addView(Ui.text(a, "هزینه‌ها بر اساس دسته", 15f, Ui.ink, true))
        val slices = DashboardMath.donut(s.monthExpenseByCategory)
        if (slices.isEmpty()) {
            card.addView(Ui.text(a, "هنوز هزینه‌ای در این ماه ثبت نشده است.", 12f, Ui.muted).apply { setPadding(0, Ui.dp(a, 8), 0, 0) })
            return card
        }
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(a, 10), 0, 0)
        }
        val donut = DonutView(a)
        donut.setData(slices.map { it.percent / 100f }, slices.indices.map { palette[it % palette.size] },
            fa("${slices[0].percent}٪"), slices[0].label.take(10))
        row.addView(donut, LinearLayout.LayoutParams(Ui.dp(a, 150), Ui.dp(a, 150)))
        val legend = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(a, 12), 0, 0, 0) }
        slices.forEachIndexed { i, sl ->
            legend.addView(LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 4))
                addView(Ui.dot(a, palette[i % palette.size]))
                addView(Ui.text(a, sl.label, 12f, Ui.ink), LinearLayout.LayoutParams(0, -2, 1f))
                addView(Ui.text(a, fa("${sl.percent}٪"), 12f, Ui.muted, true))
            })
        }
        row.addView(legend, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row)
        return card
    }

    /** Expense and income lines for the last 6 Jalali months. */
    fun trendCard(a: Activity, all: List<Transaction>, now: Long): View {
        val card = Ui.glass(a, 16)
        card.addView(Ui.text(a, "روند ۶ ماه اخیر", 15f, Ui.ink, true))
        val bars = MonthlyTrend.last(all, 6, now)
        val view = TrendView(a)
        view.setData(bars.map { it.expenseRial }, bars.map { it.incomeRial }, bars.map { it.monthName })
        card.addView(view, LinearLayout.LayoutParams(-1, Ui.dp(a, 150)).apply { topMargin = Ui.dp(a, 8) })
        card.addView(LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
            addView(Ui.dot(a, Ui.purple)); addView(Ui.text(a, "هزینه", 12f, Ui.muted))
            addView(Ui.dot(a, Ui.green).apply { (layoutParams as LinearLayout.LayoutParams).marginStart = Ui.dp(a, 18) }); addView(Ui.text(a, "درآمد", 12f, Ui.muted))
        })
        return card
    }

    class NavItem(val emoji: String, val label: String, val onClick: () -> Unit)

    /** Rounded bar fixed at the bottom of the home screen. */
    fun navBar(a: Activity, items: List<NavItem>): View {
        val bar = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8))
            background = Ui.rounded(Ui.dp(a, 30).toFloat(), Color.argb(245, 255, 255, 255), Color.argb(255, 226, 216, 255), Ui.dp(a, 1))
            elevation = Ui.dp(a, 6).toFloat()
        }
        items.forEach { item ->
            bar.addView(LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 4))
                isClickable = true
                addView(Ui.text(a, item.emoji, 22f).apply { gravity = Gravity.CENTER })
                addView(Ui.text(a, item.label, 11f, Ui.ink, true).apply { gravity = Gravity.CENTER })
                setOnClickListener { item.onClick() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return bar
    }
}
