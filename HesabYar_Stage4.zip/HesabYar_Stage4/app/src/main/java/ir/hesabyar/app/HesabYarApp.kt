package ir.hesabyar.app

import android.app.Application
import android.content.Intent

class HesabYarApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        if (CrashLog.pending(this) != null) {
            try { startActivity(Intent(this, CrashActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { }
        }
    }
}
