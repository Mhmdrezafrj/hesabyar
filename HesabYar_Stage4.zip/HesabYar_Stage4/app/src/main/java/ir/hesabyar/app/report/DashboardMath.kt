package ir.hesabyar.app.report

data class DonutSlice(val label: String, val valueRial: Long, val percent: Int)

/** Maths for the home-screen donut chart (pure, unit-tested). */
object DashboardMath {
    const val OTHERS_LABEL = "سایر دسته‌ها"

    /**
     * Biggest categories first; everything beyond [maxSlices]-1 is merged into one "others" slice.
     * Percents are whole numbers that always add up to exactly 100 (largest-remainder rounding).
     * Categories with no spending are ignored; no spending at all -> empty list.
     */
    fun donut(byCategory: List<CategoryTotal>, maxSlices: Int = 5): List<DonutSlice> {
        val positive = byCategory.filter { it.totalRial > 0 }.sortedByDescending { it.totalRial }
        if (positive.isEmpty() || maxSlices < 2) return emptyList()
        val merged: List<Pair<String, Long>> =
            if (positive.size <= maxSlices) positive.map { it.category to it.totalRial }
            else positive.take(maxSlices - 1).map { it.category to it.totalRial } +
                (OTHERS_LABEL to positive.drop(maxSlices - 1).sumOf { it.totalRial })
        val total = merged.sumOf { it.second }
        val exact = merged.map { it.second * 100.0 / total }
        val floors = exact.map { it.toInt() }.toMutableList()
        var left = 100 - floors.sum()
        exact.indices.sortedByDescending { exact[it] - floors[it] }.forEach { i -> if (left > 0) { floors[i]++; left-- } }
        return merged.mapIndexed { i, (label, value) -> DonutSlice(label, value, floors[i]) }
    }
}
