package ir.hesabyar.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.app.Notification
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.money.Money
import ir.hesabyar.app.plan.*
import ir.hesabyar.app.report.BudgetCalc
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.widget.Categories

/**
 * Local notifications only (nothing leaves the phone). Messages never contain SMS text:
 * only category names, percentages, amounts that the user typed or the app computed.
 */
object Notifier {
    private const val CHANNEL = "hesabyar_alerts"
    private const val MAX_UNUSUAL_KEYS = 50

    fun canNotify(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun post(c: Context, id: Int, title: String, body: String) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "هشدارهای مالی", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(id, n)
    }

    /** Runs all checks and shows each new alert once. Safe to call often; does nothing when alerts are off. */
    fun check(context: Context) {
        try {
            if (!AlertSettings.enabled(context) || !canNotify(context)) return
            val now = System.currentTimeMillis()
            val all = TransactionStore.all(context)
            val today = Jx.dayOf(now)
            val monthKey = Jx.monthKey(today)
            val unit = DisplaySettings.get(context)
            var sent = AlertEngine.prune(AlertSettings.sent(context), monthKey) + AlertSettings.sent(context).filter { it.startsWith("U|") }.takeLast(MAX_UNUSUAL_KEYS)
            val fresh = ArrayList<AlertItem>()

            // 1) budgets
            val summary = ReportCalculator(now).summary(all)
            val statuses = BudgetCalc.statuses(summary.monthExpenseByCategory, BudgetStore.all(context))
            fresh += AlertEngine.budgetAlerts(statuses, monthKey, sent)

            // 2) bills due within 2 days (once per bill per month per day-offset bucket) and overdue
            val plan = PlanStore.load(context)
            BillCalc.upcoming(plan.bills, today, 2).forEach { d ->
                val key = "$monthKey|BILL${d.bill.id}|${if (d.overdue) "LATE" else "SOON"}"
                if (key !in sent) fresh += AlertItem(key,
                    if (d.overdue) "«${d.bill.title}» عقب افتاد" else "«${d.bill.title}» نزدیک است",
                    (if (d.daysUntil == 0) "سررسید امروز است" else if (d.overdue) "${AmountFormatter.toPersianDigits("${-d.daysUntil}")} روز از سررسید گذشته" else "${AmountFormatter.toPersianDigits("${d.daysUntil}")} روز تا سررسید") +
                        " • " + AmountFormatter.format(d.bill.amountRial, Currency.RIAL, unit))
            }

            // 3) debts due soon / overdue
            val todayKey = Jx.dateKey(today)
            DebtCalc.dueSoon(plan.debts, todayKey, todayKey + 2).forEach { dbt ->
                val key = "$monthKey|DEBT${dbt.id}|${if (DebtCalc.overdue(dbt, todayKey)) "LATE" else "SOON"}"
                if (key !in sent) fresh += AlertItem(key,
                    if (dbt.iOwe) "بدهی به ${dbt.person} در راه است" else "طلب از ${dbt.person} سررسید شده",
                    AmountFormatter.format(dbt.amountRial, Currency.RIAL, unit))
            }

            // 4) unusually large expense in the last 24 h
            val recent = all.filter { !it.isIncome && it.category != Categories.TRANSFER && it.timestamp >= now - 86_400_000L && "U|${it.id}" !in sent }
            recent.forEach { t ->
                val earlier = all.filter { !it.isIncome && it.category != Categories.TRANSFER && it.timestamp in 1 until t.timestamp }
                    .map { Money.toRial(it.amount, it.currencyType) }
                val rial = Money.toRial(t.amount, t.currencyType)
                if (AlertEngine.isUnusualExpense(rial, earlier))
                    fresh += AlertItem("U|${t.id}", "هزینهٔ غیرمعمول", "یک هزینه به مبلغ ${AmountFormatter.format(rial, Currency.RIAL, unit)} بسیار بیشتر از معمول است")
            }

            fresh.forEach { a -> post(context, a.key.hashCode(), a.title, a.body); sent = sent + a.key }
            AlertSettings.saveSent(context, sent)
        } catch (_: Exception) { /* a notification problem must never crash SMS handling */ }
    }

    // ---- daily check ----
    private fun alarmIntent(c: Context) =
        PendingIntent.getBroadcast(c, 4401, Intent(c, DailyCheckReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun scheduleDaily(c: Context) {
        try {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (AlertSettings.enabled(c)) {
                am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + 3_600_000L, AlarmManager.INTERVAL_DAY, alarmIntent(c))
            } else am.cancel(alarmIntent(c))
        } catch (_: Exception) { }
    }
}
