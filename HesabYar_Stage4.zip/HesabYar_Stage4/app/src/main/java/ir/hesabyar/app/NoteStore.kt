package ir.hesabyar.app

import android.content.Context

/** One sticky note shown by the note widget. Stored only on this phone. */
object NoteStore {
    private const val PREFS = "hesabyar_notes"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun text(c: Context): String = p(c).getString("text", "") ?: ""
    fun savedAt(c: Context): Long = p(c).getLong("saved_at", 0L)
    fun save(c: Context, text: String) { p(c).edit().putString("text", text.trim().take(600)).putLong("saved_at", System.currentTimeMillis()).apply() }
}
