package ir.hesabyar.app.backup

import ir.hesabyar.app.Transaction

/**
 * Plain-text backup file (tab separated, one record per line). Pure and unit-tested.
 * The file is NOT encrypted: whoever holds it can read the user's transactions.
 */
object BackupCodec {
    const val HEADER = "HESABYAR-BACKUP"
    const val VERSION = 1

    data class Decoded(val transactions: List<Transaction>, val categories: List<String>, val budgets: Map<String, Long>)
    data class Result(val data: Decoded? = null, val error: String? = null)

    private fun esc(s: String): String {
        val sb = StringBuilder()
        for (c in s) when (c) {
            '\\' -> sb.append("\\\\"); '\t' -> sb.append("\\t"); '\n' -> sb.append("\\n"); '\r' -> sb.append("\\r")
            else -> sb.append(c)
        }
        return sb.toString()
    }

    private fun unesc(s: String): String? {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c != '\\') { sb.append(c); i++; continue }
            if (i + 1 >= s.length) return null
            when (s[i + 1]) { '\\' -> sb.append('\\'); 't' -> sb.append('\t'); 'n' -> sb.append('\n'); 'r' -> sb.append('\r'); else -> return null }
            i += 2
        }
        return sb.toString()
    }

    fun encode(transactions: List<Transaction>, categories: List<String>, budgets: Map<String, Long>): String {
        val sb = StringBuilder()
        sb.append(HEADER).append('\t').append(VERSION).append('\n')
        categories.forEach { sb.append("C\t").append(esc(it)).append('\n') }
        budgets.forEach { (k, v) -> sb.append("B\t").append(esc(k)).append('\t').append(v).append('\n') }
        transactions.forEach { t ->
            sb.append("T\t").append(listOf(t.id, t.title, t.bank, t.amount.toString(), t.time, if (t.isIncome) "1" else "0",
                t.category, t.currency, t.source, t.sourceRef, t.balance?.toString() ?: "", t.accountId, t.timestamp.toString())
                .joinToString("\t") { esc(it) }).append('\n')
        }
        return sb.toString()
    }

    fun decode(text: String): Result {
        val lines = text.replace("\r\n", "\n").split('\n').filter { it.isNotEmpty() }
        if (lines.isEmpty()) return Result(error = "فایل خالی است")
        val head = lines[0].split('\t')
        if (head.size != 2 || head[0] != HEADER) return Result(error = "این فایل پشتیبان حساب‌یار نیست")
        val version = head[1].toIntOrNull() ?: return Result(error = "نسخهٔ فایل نامعتبر است")
        if (version > VERSION) return Result(error = "این فایل با نسخهٔ جدیدتری ساخته شده؛ برنامه را به‌روز کن")
        val txs = mutableListOf<Transaction>(); val cats = mutableListOf<String>(); val budgets = LinkedHashMap<String, Long>()
        for ((index, line) in lines.drop(1).withIndex()) {
            val n = index + 2
            val parts = line.split('\t')
            when (parts[0]) {
                "C" -> {
                    if (parts.size != 2) return Result(error = "خط $n: دسته نامعتبر")
                    cats.add(unesc(parts[1]) ?: return Result(error = "خط $n: نویسهٔ نامعتبر"))
                }
                "B" -> {
                    if (parts.size != 3) return Result(error = "خط $n: بودجه نامعتبر")
                    val name = unesc(parts[1]) ?: return Result(error = "خط $n: نویسهٔ نامعتبر")
                    val limit = parts[2].toLongOrNull() ?: return Result(error = "خط $n: مبلغ بودجه نامعتبر")
                    if (limit > 0) budgets[name] = limit
                }
                "T" -> {
                    if (parts.size != 14) return Result(error = "خط $n: تراکنش ناقص است")
                    val f = parts.drop(1).map { unesc(it) ?: return Result(error = "خط $n: نویسهٔ نامعتبر") }
                    val amount = f[3].toLongOrNull() ?: return Result(error = "خط $n: مبلغ نامعتبر")
                    val ts = f[12].toLongOrNull() ?: return Result(error = "خط $n: زمان نامعتبر")
                    val balance = if (f[10].isEmpty()) null else (f[10].toLongOrNull() ?: return Result(error = "خط $n: موجودی نامعتبر"))
                    if (f[0].isBlank()) return Result(error = "خط $n: شناسه خالی است")
                    if (f[5] != "0" && f[5] != "1") return Result(error = "خط $n: نوع تراکنش نامعتبر")
                    txs.add(Transaction(id = f[0], title = f[1], bank = f[2], amount = amount, time = f[4], isIncome = f[5] == "1",
                        category = f[6], currency = f[7], source = f[8], sourceRef = f[9], balance = balance,
                        accountId = f[11], timestamp = ts))
                }
                else -> { /* unknown record type from a newer minor version: ignore */ }
            }
        }
        return Result(Decoded(txs, cats, budgets))
    }
}
