package ir.hesabyar.app

import android.content.Context
import android.graphics.Typeface

/** Typefaces from res/font. Never throws: falls back to the system font. */
object Fonts {
    private fun load(c: Context, res: Int): Typeface = try { c.resources.getFont(res) } catch (_: Exception) { Typeface.DEFAULT }

    /** App-wide font: Digi Hamishe (regular / bold). */
    fun app(c: Context, bold: Boolean): Typeface = load(c, if (bold) R.font.digi_hamishe_bold else R.font.digi_hamishe_regular)

    /** Font chosen in the widget designer. Single-weight fonts use the same file for bold. */
    fun forDesign(c: Context, id: String, bold: Boolean): Typeface = when (id) {
        "sarvenaz" -> load(c, R.font.digi_sarvenaz)
        "rastin" -> load(c, R.font.digi_rastin_bold)
        "lalezar" -> load(c, R.font.digi_lalezar_plus)
        "lalezar_grunge" -> load(c, R.font.digi_lalezar_plus_grunge)
        "lalezar_circle" -> load(c, R.font.digi_lalezar_plus_circle)
        "craft" -> load(c, R.font.digi_craft_ultra_black)
        else -> app(c, bold)
    }
}
