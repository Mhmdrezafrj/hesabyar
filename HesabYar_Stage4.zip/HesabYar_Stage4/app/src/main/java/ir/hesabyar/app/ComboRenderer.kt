package ir.hesabyar.app

import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.TextUtils
import ir.hesabyar.app.design.*
import ir.hesabyar.app.plan.Insights
import ir.hesabyar.app.plan.Jx
import ir.hesabyar.app.plan.GoalCalc
import ir.hesabyar.app.plan.Light
import ir.hesabyar.app.plan.TrafficLight
import ir.hesabyar.app.plan.UrgentLevel
import ir.hesabyar.app.widget.JalaliCalendar

/**
 * Draws a whole composite widget as one picture (background, cards, texts, small charts) from a DesignConfig.
 * Layout comes from design.Grid (tested); this file only paints. Taps are handled by an invisible grid in the widget layout.
 */
object ComboRenderer {
    private val faceRegular = ThreadLocal<Typeface?>()
    private val faceBold = ThreadLocal<Typeface?>()
    private class P(
        val cv: Canvas, val r: Grid.RectF, val dp: Float, val fs: Float, val ink: Int, val muted: Int,
        val accent: Int, val fill: Int, val cfg: DesignConfig, val d: ComboData
    ) {
        val u get() = dp * fs
        fun t(s: String) = if (cfg.persianDigits) d.fa(s) else toAscii(s)
    }

    private fun toAscii(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) sb.append(if (ch in '۰'..'۹') ('0' + (ch - '۰')) else if (ch in '٠'..'٩') ('0' + (ch - '٠')) else ch)
        return sb.toString()
    }

    fun render(cfg0: DesignConfig, size: WidgetSize, wPx: Int, hPx: Int, dp: Float, d: ComboData): Bitmap {
        val cfg = Design.sanitize(cfg0)
        faceRegular.set(try { Fonts.forDesign(d.ctx, cfg.fontId, false) } catch (_: Exception) { null })
        faceBold.set(try { Fonts.forDesign(d.ctx, cfg.fontId, true) } catch (_: Exception) { null })
        val w = wPx.toFloat(); val h = hPx.toFloat()
        val bmp = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val alpha = cfg.opacity * 255 / 100
        val outer = (cfg.cornerDp + 6) * dp
        cv.drawRoundRect(RectF(0f, 0f, w, h), outer, outer, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, w, h, cfg.bg1, cfg.bg2, Shader.TileMode.CLAMP); this.alpha = alpha
        })
        val fs = floatArrayOf(0.9f, 1f, 1.15f)[cfg.fontLevel]
        val pad = floatArrayOf(6f, 9f, 13f)[cfg.density] * dp
        val gap = floatArrayOf(4f, 6f, 9f)[cfg.density] * dp
        val cells = Grid.cells(size, Design.effectiveExtras(cfg, d.snap.dayIndex, Grid.extraCount(size)), cfg.mirror)
        var extraIdx = 0
        cells.forEachIndexed { i, cell ->
            val r = Grid.rect(cell, w, h, pad, gap)
            val fill = when (cell.block) {
                BlockType.ALLOWANCE -> when (d.light) { Light.GREEN -> 0xFF12A872.toInt(); Light.AMBER -> 0xFFE9960B.toInt(); Light.RED -> 0xFFE0334F.toInt(); Light.NONE -> cfg.cards[0] }
                BlockType.URGENT -> when (d.urgent.level) { UrgentLevel.HIGH -> 0xFFE0334F.toInt(); UrgentLevel.MEDIUM -> 0xFFE9960B.toInt(); UrgentLevel.NONE -> 0xFF12A872.toInt() }
                BlockType.QUICK_ADD -> cfg.accent
                else -> cfg.cards[extraIdx++ % cfg.cards.size]
            }
            val real = Contrast.blend(Contrast.withAlpha(fill, alpha), cfg.bg1)
            val ink = Contrast.textOn(real)
            val rad = (cfg.cornerDp * dp).coerceAtMost(minOf(r.width, r.height) / 2f)
            val path = shapePath(r, rad, cfg.shape, i)
            cv.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill; this.alpha = alpha })
            cv.save(); cv.clipPath(path)
            try {
                draw(P(cv, r, dp, fs, ink, Contrast.withAlpha(ink, 175), cfg.accent, fill, cfg, d), cell.block)
            } catch (_: Exception) { /* one broken block must not blank the widget */ }
            cv.restore()
        }
        return bmp
    }

    private fun shapePath(r: Grid.RectF, rad: Float, shape: CardShape, idx: Int): Path {
        val rect = RectF(r.left, r.top, r.right, r.bottom)
        val p = Path(); p.addRoundRect(rect, rad, rad, Path.Direction.CW)
        val cut = Path()
        when (shape) {
            CardShape.ROUND -> return p
            CardShape.NOTCH -> {
                val nr = minOf(rad * 0.9f, minOf(r.width, r.height) * 0.16f).coerceAtLeast(2f)
                cut.addCircle(if (idx % 2 == 0) r.right else r.left, if (idx % 3 == 0) r.top else r.bottom, nr, Path.Direction.CW)
            }
            CardShape.TICKET -> {
                val nr = minOf(rad * 0.55f, r.height * 0.14f).coerceAtLeast(2f)
                cut.addCircle(r.left, (r.top + r.bottom) / 2f, nr, Path.Direction.CW)
                cut.addCircle(r.right, (r.top + r.bottom) / 2f, nr, Path.Direction.CW)
            }
        }
        p.op(cut, Path.Op.DIFFERENCE)
        return p
    }

    // ------------------------------------------------------------------ text helpers
    private fun tp(size: Float, color: Int, bold: Boolean) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color
        (if (bold) faceBold.get() else faceRegular.get())?.let { this.typeface = it } ?: run { isFakeBoldText = bold }
    }

    /** One line, right-aligned (the app is RTL), shrunk to fit. Returns the line height. */
    private fun line(cv: Canvas, s: String, left: Float, right: Float, top: Float, size: Float, color: Int, bold: Boolean, center: Boolean = false): Float {
        val p = tp(size, color, bold)
        val maxW = right - left
        val w = p.measureText(s)
        if (w > maxW && w > 0f) p.textSize = (size * maxW / w).coerceAtLeast(size * 0.5f)
        p.textAlign = if (center) Paint.Align.CENTER else Paint.Align.RIGHT
        val fm = p.fontMetrics
        cv.drawText(s, if (center) (left + right) / 2f else right, top - fm.ascent, p)
        return fm.descent - fm.ascent
    }

    private fun multi(cv: Canvas, s: String, left: Float, top: Float, right: Float, bottom: Float, size: Float, color: Int, bold: Boolean) {
        val w = (right - left).toInt().coerceAtLeast(1)
        val avail = bottom - top
        if (avail <= 0f || s.isEmpty()) return
        fun build(sz: Float, maxLines: Int): StaticLayout =
            StaticLayout.Builder.obtain(s, 0, s.length, tp(sz, color, bold), w)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
                .setIncludePad(false).setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END).build()
        var sz = size
        var lay = build(sz, Int.MAX_VALUE)
        while (lay.height > avail && sz > size * 0.62f) { sz *= 0.92f; lay = build(sz, Int.MAX_VALUE) }
        if (lay.height > avail) {
            val lines = (avail / (sz * 1.2f)).toInt().coerceAtLeast(1)
            lay = build(sz, lines)
        }
        cv.save(); cv.translate(left, top); lay.draw(cv); cv.restore()
    }

    private fun pill(cv: Canvas, r: RectF, color: Int) = cv.drawRoundRect(r, r.height() / 2f, r.height() / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })

    // ------------------------------------------------------------------ blocks
    private fun draw(p: P, b: BlockType) {
        val d = p.d
        when (b) {
            BlockType.ALLOWANCE -> {
                val plan = d.snap.plan
                val (value, sub) = when (d.light) {
                    Light.NONE -> "بودجه بگذار" to "برای دیدن سقف روزانه"
                    Light.RED -> "بودجه تمام شد" to p.t("${plan.daysLeft} روز تا آخر ماه")
                    Light.AMBER -> d.money(plan.dailyAllowanceRial) to "با این روند از بودجه رد می‌شوی"
                    Light.GREEN -> d.money(plan.dailyAllowanceRial) to "روی مسیر خوبی هستی"
                }
                tvs(p, "امروز می‌توانی خرج کنی", p.t(value), sub)
            }
            BlockType.URGENT -> {
                val u = d.urgent
                val icon = when (u.level) { UrgentLevel.HIGH -> "🚨"; UrgentLevel.MEDIUM -> "⚠️"; UrgentLevel.NONE -> "✅" }
                msg(p, icon, p.t(u.title), p.t(u.detail))
            }
            BlockType.QUICK_ADD -> {
                val r = p.r; val m = 6 * p.dp
                val mid = (r.left + r.right) / 2f
                val a = RectF(mid + m / 2, r.top + m, r.right - m, r.bottom - m)      // right half = expense (RTL)
                val c = RectF(r.left + m, r.top + m, mid - m / 2, r.bottom - m)
                pill(p.cv, a, Contrast.withAlpha(p.ink, 48)); pill(p.cv, c, Contrast.withAlpha(p.ink, 48))
                val sz = minOf(a.height() * 0.42f, 15f * p.u)
                line(p.cv, "➖ هزینه", a.left, a.right, a.centerY() - sz * 0.6f, sz, p.ink, true, true)
                line(p.cv, "➕ درآمد", c.left, c.right, c.centerY() - sz * 0.6f, sz, p.ink, true, true)
            }
            BlockType.RING -> {
                val pct = TrafficLight.percentUsed(d.snap.plan)
                val has = d.light != Light.NONE
                val r = p.r; val dia = minOf(r.width, r.height) * 0.78f
                val cx = r.right - r.width / 2f; val cy = r.top + r.height / 2f
                val st = dia * 0.14f
                val box = RectF(cx - dia / 2 + st / 2, cy - dia / 2 + st / 2, cx + dia / 2 - st / 2, cy + dia / 2 - st / 2)
                p.cv.drawArc(box, 0f, 360f, false, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = st; color = Contrast.withAlpha(p.ink, 50) })
                if (has && pct > 0) p.cv.drawArc(box, -90f, 360f * pct / 100f, false, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = st; color = p.ink; strokeCap = Paint.Cap.ROUND })
                line(p.cv, if (has) p.t("$pct٪") else "—", cx - dia / 2, cx + dia / 2, cy - dia * 0.14f, dia * 0.27f, p.ink, true, true)
                if (r.height > 90 * p.dp) line(p.cv, if (has) "بودجه مصرف‌شده" else "بدون بودجه", r.left, r.right, r.bottom - 14 * p.dp, 9.5f * p.u, p.muted, false, true)
            }
            BlockType.WEEK_BARS -> weekBars(p)
            BlockType.WEEK_STRIP -> weekStrip(p)
            BlockType.GOAL -> goal(p)
            BlockType.STREAK -> {
                val s = d.snap.streak
                val icon = if (s.days == 0) "🌱" else if (s.loggedToday) "🔥" else "⏳"
                val value = if (s.days == 0) "$icon شروع کن" else p.t("$icon ${s.days} روز")
                val sub = when { s.days == 0 -> "یک تراکنش ثبت کن"; s.loggedToday -> "امروز ثبت شد"; else -> "زنجیره نشکند!" }
                tvs(p, "زنجیرهٔ ثبت", value, sub)
            }
            BlockType.NUDGE -> msg(p, "💡", p.t(d.nudge), null)
            BlockType.NOTE -> {
                val age = if (d.noteAgeDays > 0) " • " + p.t("${d.noteAgeDays} روز پیش") else ""
                msg(p, "📌 یادداشت$age", if (d.note.isBlank()) "برای نوشتن لمس کن ✍️" else d.note, null)
            }
            BlockType.DUES -> {
                val l = d.duesLines
                msg(p, "📅 سررسیدها", if (l.isEmpty()) "سررسید نزدیکی نیست ✓" else l.take(4).joinToString("\n") { "• " + it }, null)
            }
            BlockType.ACCOUNTS -> {
                if (d.accountsCount == 0) tvs(p, "موجودی حساب‌ها", "—", "هنوز مانده‌ای ثبت نشده")
                else tvs(p, "موجودی حساب‌ها", p.t(d.money(d.accountsTotal)), p.t("${d.accountsCount} حساب"))
            }
        }
    }

    /** Small title, big value, small sub-line. Falls back gracefully in short cells. */
    private fun tvs(p: P, title: String?, value: String, sub: String?) {
        val pad = 8 * p.dp; val l = p.r.left + pad; val rr = p.r.right - pad
        var y = p.r.top + pad * 0.9f
        val h = p.r.height
        if (title != null && h >= 56 * p.dp) y += line(p.cv, title, l, rr, y, 10.5f * p.u, p.muted, false) + 2 * p.dp
        val subH = if (sub != null && h > 76 * p.dp) 14 * p.dp else 0f
        val avail = (p.r.bottom - pad * 0.7f - subH) - y
        val vs = minOf(avail * 0.78f, 30f * p.u)
        val top = y + (avail - vs * 1.17f).coerceAtLeast(0f) / 2f
        line(p.cv, value, l, rr, top, vs, p.ink, true)
        if (subH > 0f) line(p.cv, sub!!, l, rr, p.r.bottom - pad * 0.7f - subH + 2 * p.dp, 10f * p.u, p.muted, false)
    }

    /** Header (emoji/label) + wrapped message that uses all remaining space. */
    private fun msg(p: P, head: String, body: String, sub: String?) {
        val pad = 8 * p.dp; val l = p.r.left + pad; val rr = p.r.right - pad
        var y = p.r.top + pad * 0.9f
        val hh = line(p.cv, head, l, rr, y, (if (head.length <= 3) 18f else 10.5f) * p.u, if (head.length <= 3) p.ink else p.muted, false)
        y += hh + 2 * p.dp
        var bottom = p.r.bottom - pad * 0.7f
        if (sub != null && p.r.height > 70 * p.dp) { bottom -= 13 * p.dp; line(p.cv, sub, l, rr, bottom + 2 * p.dp, 10f * p.u, p.muted, false) }
        multi(p.cv, body, l, y, rr, bottom, 13.5f * p.u, p.ink, true)
    }

    private fun goal(p: P) {
        val g = p.d.goal
        if (g == null) { tvs(p, "هدف پس‌انداز", "—", "یک هدف بساز"); return }
        val pct = GoalCalc.percent(g)
        val pad = 8 * p.dp; val l = p.r.left + pad; val rr = p.r.right - pad
        val h = p.r.height
        if (h < 62 * p.dp) { tvs(p, null, p.t("${g.title} $pct٪"), null); return }
        var y = p.r.top + pad * 0.9f
        y += line(p.cv, g.title, l, rr, y, 10.5f * p.u, p.muted, false) + 2 * p.dp
        y += line(p.cv, p.t("$pct٪"), l, rr, y, minOf(h * 0.26f, 26f * p.u), p.ink, true)
        val barH = 7 * p.dp
        val bar = RectF(l, y + 3 * p.dp, rr, y + 3 * p.dp + barH)
        pill(p.cv, bar, Contrast.withAlpha(p.ink, 50))
        if (pct > 0) pill(p.cv, RectF(rr - (rr - l) * pct / 100f, bar.top, rr, bar.bottom), p.ink)
        if (h > 86 * p.dp) line(p.cv, p.t(p.d.money(GoalCalc.remaining(g))) + " مانده", l, rr, bar.bottom + 4 * p.dp, 9.5f * p.u, p.muted, false)
    }

    private fun weekBars(p: P) {
        val wk = p.d.snap.week
        val pad = 8 * p.dp; val r = p.r
        var top = r.top + pad * 0.9f
        val short = r.height < 80 * p.dp
        if (!short) top += line(p.cv, "هزینهٔ ۷ روز اخیر", r.left + pad, r.right - pad, top, 10.5f * p.u, p.muted, false) + 3 * p.dp
        val labelH = if (short) 0f else 12 * p.dp
        val base = r.bottom - pad * 0.7f - labelH
        val chartH = (base - top).coerceAtLeast(6f)
        val max = (wk.expenseRial.maxOrNull() ?: 0L).coerceAtLeast(1L)
        val slot = (r.width - 2 * pad) / 7f
        val barP = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 7) {
            val col = 6 - i                       // oldest at the right edge, newest at the left edge (Persian reading order)
            val v = wk.expenseRial[i]
            val bh = if (v <= 0) 3 * p.dp else (chartH * v / max).coerceAtLeast(6 * p.dp)
            barP.color = if (i == 6) p.accent else Contrast.withAlpha(p.ink, 110)
            val x0 = r.left + pad + col * slot + slot * 0.2f; val x1 = r.left + pad + (col + 1) * slot - slot * 0.2f
            p.cv.drawRoundRect(RectF(x0, base - bh, x1, base), 4 * p.dp, 4 * p.dp, barP)
            if (!short) line(p.cv, Insights.weekdayName(wk.weekdays[i]).take(1), x0 - slot * 0.2f, x1 + slot * 0.2f, base + 1.5f * p.dp, 8.5f * p.u, p.muted, false, true)
        }
    }

    private fun weekStrip(p: P) {
        val wk = p.d.snap.week
        val pad = 8 * p.dp; val r = p.r
        val slot = (r.width - 2 * pad) / 7f
        val dia = minOf(slot * 0.82f, r.height * 0.5f)
        val cy = r.top + r.height * 0.58f
        val now = p.d.snap.now
        for (i in 0 until 7) {
            val col = 6 - i
            val cx = r.left + pad + col * slot + slot / 2f
            val back = 6 - i
            val jd = Jx.dayOf(now - back * 86_400_000L, p.d.snap.zone)
            val today = i == 6
            p.cv.drawCircle(cx, cy, dia / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (today) p.accent else Contrast.withAlpha(p.ink, 40) })
            val numInk = if (today) Contrast.textOn(p.accent) else p.ink
            line(p.cv, p.t("${jd.day}"), cx - dia / 2, cx + dia / 2, cy - dia * 0.2f, dia * 0.42f, numInk, today, true)
            line(p.cv, Insights.weekdayName(wk.weekdays[i]).take(1), cx - slot / 2, cx + slot / 2, cy - dia / 2f - 14 * p.dp, 9.5f * p.u, p.muted, false, true)
            if (wk.expenseRial[i] > 0) p.cv.drawCircle(cx, cy + dia / 2f + 5 * p.dp, 2.2f * p.dp, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = p.ink })
        }
    }
}
