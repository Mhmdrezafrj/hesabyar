package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.widget.Categories

/** Tiny dialog opened from the widget: pick a category, widget refreshes, no app screen is shown. */
class QuickCategoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("transaction_id")
        val tx = TransactionStore.all(this).firstOrNull { it.id == id }
        if (id == null || tx == null || tx.category.isNotBlank()) {
            // already categorised or gone: just refresh the widget
            PendingTransactionsWidget.updateAll(this); finish(); return
        }
        val cats = Categories.defaults.toTypedArray()
        val summary = AmountFormatter.format(tx.amount, tx.currencyType, DisplaySettings.get(this))
        AlertDialog.Builder(this)
            .setTitle("دسته‌بندی: " + (if (tx.isIncome) "+" else "−") + summary)
            .setItems(cats) { _, which ->
                TransactionStore.categorize(this, id, cats[which])
                PendingTransactionsWidget.updateAll(this)
                finish()
            }
            .setNegativeButton("انصراف") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }
}
