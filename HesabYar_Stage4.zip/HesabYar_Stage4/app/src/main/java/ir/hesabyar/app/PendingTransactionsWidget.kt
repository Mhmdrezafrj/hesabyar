package ir.hesabyar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.widget.JalaliCalendar
import ir.hesabyar.app.widget.PendingQueue
import ir.hesabyar.app.widget.WidgetConfig
import ir.hesabyar.app.widget.WidgetLayoutMath
import java.util.Calendar

/**
 * Home-screen widget. Reads the REAL transaction store, shows the newest uncategorised
 * transactions (all days) and updates itself after every change (no app open needed).
 */
class PendingTransactionsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, id, newOptions)
        updateOne(context, manager, id)
    }

    companion object {
        private val rowIds = intArrayOf(R.id.row_1, R.id.row_2, R.id.row_3, R.id.row_4, R.id.row_5, R.id.row_6, R.id.row_7)
        private val iconIds = intArrayOf(R.id.ic_1, R.id.ic_2, R.id.ic_3, R.id.ic_4, R.id.ic_5, R.id.ic_6, R.id.ic_7)
        private val titleIds = intArrayOf(R.id.title_1, R.id.title_2, R.id.title_3, R.id.title_4, R.id.title_5, R.id.title_6, R.id.title_7)
        private val metaIds = intArrayOf(R.id.meta_1, R.id.meta_2, R.id.meta_3, R.id.meta_4, R.id.meta_5, R.id.meta_6, R.id.meta_7)
        private val amountIds = intArrayOf(R.id.amount_1, R.id.amount_2, R.id.amount_3, R.id.amount_4, R.id.amount_5, R.id.amount_6, R.id.amount_7)
        private val catIds = intArrayOf(R.id.cat_1, R.id.cat_2, R.id.cat_3, R.id.cat_4, R.id.cat_5, R.id.cat_6, R.id.cat_7)
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, PendingTransactionsWidget::class.java)
            manager.getAppWidgetIds(component).forEach { updateOne(context, manager, it) }
        }

        private fun sp(base: Float, level: Int) = base * WidgetConfig.fontScale(level)

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val cfg = WidgetConfigStore.load(context)
            val all = TransactionStore.all(context)
            val pending = PendingQueue.pending(all)
            val balanceTx = if (cfg.showBalance) PendingQueue.latestBalance(all) else null
            val unit = DisplaySettings.get(context)

            val heightDp = manager.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
            val rowsAllowed = WidgetLayoutMath.rowsThatFit(heightDp, cfg.count, balanceTx != null)
            val visible = pending.take(rowsAllowed)

            val v = RemoteViews(context.packageName, R.layout.widget_pending)

            // Background style + opacity
            v.setImageViewResource(R.id.widget_bg, if (cfg.style == 1) R.drawable.widget_bg_purple else R.drawable.widget_bg_glass)
            v.setInt(R.id.widget_bg, "setImageAlpha", cfg.opacityPercent * 255 / 100)

            // Header
            v.setViewVisibility(R.id.widget_wallet, if (cfg.showWallet) View.VISIBLE else View.GONE)
            v.setViewVisibility(R.id.widget_date, if (cfg.showDate) View.VISIBLE else View.GONE)
            if (cfg.showDate) {
                val cal = Calendar.getInstance()
                val j = JalaliCalendar.fromGregorian(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
                v.setTextViewText(R.id.widget_date, AmountFormatter.toPersianDigits("امروز • ${j.day} ${JalaliCalendar.monthNames[j.month - 1]}"))
            }
            v.setTextViewTextSize(R.id.widget_title, TypedValue.COMPLEX_UNIT_SP, sp(17f, cfg.titleFont))

            // Balance (only from a real bank SMS balance)
            if (balanceTx != null && balanceTx.balance != null) {
                v.setViewVisibility(R.id.widget_balance_row, View.VISIBLE)
                val acct = if (balanceTx.accountId.isNotBlank()) " " + AmountFormatter.toPersianDigits(balanceTx.accountId) else ""
                v.setTextViewText(R.id.widget_balance_label, "مانده حساب$acct")
                v.setTextViewText(R.id.widget_balance_value, AmountFormatter.format(balanceTx.balance!!, balanceTx.currencyType, unit))
                v.setTextViewTextSize(R.id.widget_balance_value, TypedValue.COMPLEX_UNIT_SP, sp(19f, cfg.amountFont))
            } else {
                v.setViewVisibility(R.id.widget_balance_row, View.GONE)
            }

            // Pending counter (very small) / empty state
            val empty = pending.isEmpty()
            v.setViewVisibility(R.id.widget_empty, if (empty) View.VISIBLE else View.GONE)
            v.setViewVisibility(R.id.widget_rows, if (empty) View.GONE else View.VISIBLE)
            v.setViewVisibility(R.id.widget_count, if (empty) View.GONE else View.VISIBLE)
            if (!empty) {
                v.setTextViewText(R.id.widget_count, AmountFormatter.toPersianDigits("${pending.size} تراکنش نیازمند دسته‌بندی"))
            }

            // Rows
            for (i in rowIds.indices) {
                if (i >= visible.size) { v.setViewVisibility(rowIds[i], View.GONE); continue }
                val tx = visible[i]
                v.setViewVisibility(rowIds[i], View.VISIBLE)
                v.setImageViewResource(iconIds[i], if (tx.isIncome) R.drawable.ic_tx_in else R.drawable.ic_tx_out)
                v.setTextViewText(titleIds[i], tx.title)
                v.setTextViewText(metaIds[i], "${tx.bank} • ${tx.time}")
                v.setTextViewText(amountIds[i], AmountFormatter.formatSigned(tx.amount, tx.isIncome, tx.currencyType, unit))
                v.setTextColor(amountIds[i], if (tx.isIncome) 0xFF4ADE80.toInt() else 0xFFFB7185.toInt())
                v.setTextViewTextSize(titleIds[i], TypedValue.COMPLEX_UNIT_SP, sp(13f, cfg.titleFont))
                v.setTextViewTextSize(amountIds[i], TypedValue.COMPLEX_UNIT_SP, sp(13f, cfg.amountFont))
                v.setTextViewTextSize(metaIds[i], TypedValue.COMPLEX_UNIT_SP, sp(10f, cfg.metaFont))
                // Quick categorise: small dialog above the home screen, the app does not open.
                val quick = Intent(context, QuickCategoryActivity::class.java).apply {
                    action = "QUICK_CATEGORIZE"
                    putExtra("transaction_id", tx.id)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                val pi = PendingIntent.getActivity(context, tx.id.hashCode(), quick,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                v.setOnClickPendingIntent(catIds[i], pi)
                v.setOnClickPendingIntent(rowIds[i], pi)
            }

            // Buttons
            val add = Intent(context, MainActivity::class.java).apply {
                action = "ADD_TRANSACTION"; flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            v.setOnClickPendingIntent(R.id.widget_add, PendingIntent.getActivity(context, 9001, add,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            val settings = Intent(context, WidgetSettingsActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            v.setOnClickPendingIntent(R.id.widget_settings, PendingIntent.getActivity(context, 9002, settings,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            val details = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            v.setOnClickPendingIntent(R.id.widget_details, PendingIntent.getActivity(context, 9003, details,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

            manager.updateAppWidget(id, v)
        }
    }
}
