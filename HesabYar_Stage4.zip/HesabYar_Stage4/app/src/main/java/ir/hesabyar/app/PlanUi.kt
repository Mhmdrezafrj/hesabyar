package ir.hesabyar.app

import android.app.Activity
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.plan.*
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.report.Summary
import ir.hesabyar.app.widget.JalaliCalendar

/** Home-screen cards for spending control, dues, accounts and insights. All numbers come from the tested plan.* logic. */
object PlanUi {
    private fun fa(s: String) = AmountFormatter.toPersianDigits(s)

    fun bar(a: Activity, percent: Int, color: Int): View {
        val p = percent.coerceIn(0, 100)
        return LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = Ui.rounded(Ui.dp(a, 4).toFloat(), Ui.p.trackLine, null, 0)
            addView(View(a).apply { background = Ui.rounded(Ui.dp(a, 4).toFloat(), color, null, 0) },
                LinearLayout.LayoutParams(0, Ui.dp(a, 8), p.toFloat().coerceAtLeast(0.01f)))
            addView(View(a), LinearLayout.LayoutParams(0, Ui.dp(a, 8), (100 - p).toFloat().coerceAtLeast(0.01f)))
        }
    }

    /** "How much can I spend today?" + month-end projection. */
    fun spendingCard(a: Activity, s: Summary, now: Long, unit: Currency, onSetBudget: () -> Unit): View {
        fun money(r: Long) = AmountFormatter.format(r, Currency.RIAL, unit)
        val plan = BudgetPlanner.plan(Jx.dayOf(now), BudgetStore.all(a), s.monthExpenseByCategory, s.monthExpenseRial)
        val card = Ui.glass(a, 16)
        card.addView(Ui.text(a, "امروز چقدر خرج کنم؟", 15f, Ui.ink, true))
        if (!plan.hasBudget) {
            card.addView(Ui.text(a, "برای محاسبهٔ سقف روزانه، حداقل برای یک دسته بودجهٔ ماهانه تعیین کن.", 12f, Ui.muted).apply { setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 8)) })
            card.addView(Ui.soft(a, "تعیین بودجه") { onSetBudget() })
            return card
        }
        val over = plan.remainingRial <= 0
        card.addView(Ui.text(a, if (over) "بودجه‌های این ماه تمام شده" else money(plan.dailyAllowanceRial), 26f, if (over) Ui.red else Ui.green, true).apply { setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 2)) })
        card.addView(Ui.text(a, if (over) "${money(-plan.remainingRial)} بیشتر از بودجه خرج شده" else "برای هر روز، تا آخر ماه (${fa("${plan.daysLeft}")} روز مانده)", 12f, Ui.muted))
        val pct = if (plan.totalLimitRial > 0) (plan.spentInBudgetsRial * 100 / plan.totalLimitRial).toInt() else 0
        card.addView(bar(a, pct, if (pct >= 100) Ui.red else if (pct >= 80) Ui.amber else Ui.green), Ui.margins(a, 10, 4))
        card.addView(Ui.text(a, "${money(plan.spentInBudgetsRial)} از ${money(plan.totalLimitRial)} (${fa("$pct")}٪)", 11f, Ui.muted))
        card.addView(Ui.text(a,
            "با این روند، هزینهٔ آخر ماه حدود ${money(plan.projectedMonthExpenseRial)} می‌شود" +
                (if (plan.projectedOverBudget) " و از کل بودجه (${money(plan.totalLimitRial)}) بیشتر خواهد شد." else "."),
            12f, if (plan.projectedOverBudget) Ui.red else Ui.ink).apply { setPadding(0, Ui.dp(a, 8), 0, 0) })
        return card
    }

    /** Upcoming bills and debts (within 7 days, plus overdue). Null when there is nothing to show. */
    fun dueCard(a: Activity, now: Long, unit: Currency, onOpen: () -> Unit): View? {
        val data = PlanStore.load(a)
        val today = Jx.dayOf(now)
        val bills = BillCalc.upcoming(data.bills, today, 7)
        val todayKey = Jx.dateKey(today)
        val debts = DebtCalc.dueSoon(data.debts, todayKey, todayKey + 7)
        if (bills.isEmpty() && debts.isEmpty()) return null
        val card = Ui.glass(a, 16)
        card.addView(Ui.text(a, "سررسیدهای نزدیک", 15f, Ui.ink, true))
        bills.forEach { d ->
            val txt = when {
                d.daysUntil < 0 -> "${fa("${-d.daysUntil}")} روز عقب‌افتاده"
                d.daysUntil == 0 -> "امروز"
                else -> "${fa("${d.daysUntil}")} روز دیگر"
            }
            card.addView(Ui.text(a, "• ${d.bill.title}: ${AmountFormatter.format(d.bill.amountRial, Currency.RIAL, unit)} — $txt", 13f, if (d.overdue) Ui.red else Ui.ink).apply { setPadding(0, Ui.dp(a, 6), 0, 0) })
        }
        debts.forEach { d ->
            val late = DebtCalc.overdue(d, todayKey)
            card.addView(Ui.text(a, "• ${if (d.iOwe) "بدهی به" else "طلب از"} ${d.person}: ${AmountFormatter.format(d.amountRial, Currency.RIAL, unit)}${if (late) " — سررسید گذشته" else ""}", 13f, if (late) Ui.red else Ui.ink).apply { setPadding(0, Ui.dp(a, 6), 0, 0) })
        }
        card.addView(Ui.soft(a, "برنامه‌ریزی مالی") { onOpen() }, Ui.margins(a, 10, 0))
        return card
    }

    /** Latest known balance per bank account (read from SMS). Null when no SMS has reported a balance. */
    fun accountsCard(a: Activity, all: List<Transaction>, unit: Currency): View? {
        val b = AccountsOverview.balances(all)
        if (b.isEmpty()) return null
        val card = Ui.glass(a, 16)
        card.addView(Ui.text(a, "موجودی حساب‌ها", 15f, Ui.ink, true))
        b.forEach { x ->
            card.addView(LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, Ui.dp(a, 6), 0, 0)
                addView(Ui.text(a, "${x.bank.ifBlank { "حساب" }} ${fa(x.accountId)}", 13f, Ui.ink), LinearLayout.LayoutParams(0, -2, 1f))
                addView(Ui.text(a, AmountFormatter.format(x.balanceRial, Currency.RIAL, unit), 13f, Ui.ink, true))
            })
        }
        if (b.size > 1) card.addView(Ui.text(a, "جمع: ${AmountFormatter.format(AccountsOverview.total(b), Currency.RIAL, unit)}", 13f, Ui.green, true).apply { setPadding(0, Ui.dp(a, 8), 0, 0) })
        card.addView(Ui.text(a, "مانده از آخرین پیامک بانکی هر حساب است و ممکن است با مانده واقعی کمی فرق داشته باشد.", 10f, Ui.muted).apply { setPadding(0, Ui.dp(a, 6), 0, 0) })
        return card
    }

    /** A few plain-language observations. Null when there is not enough data. */
    fun insightsCard(a: Activity, all: List<Transaction>, now: Long, unit: Currency): View? {
        fun money(r: Long) = AmountFormatter.format(r, Currency.RIAL, unit)
        val d = Insights.compute(all, now)
        val lines = ArrayList<String>()
        d.topIncrease?.let { lines.add("هزینهٔ «${it.category}» ${fa("${it.percent}")}٪ بیشتر از ماه قبل شده است.") }
        d.topDecrease?.let { lines.add("هزینهٔ «${it.category}» ${fa("${-it.percent}")}٪ کمتر از ماه قبل شده است.") }
        d.busiestWeekday?.let { lines.add("بیشترین خرج تو در ۳ ماه اخیر در روزهای ${Insights.weekdayName(it)} بوده است.") }
        d.biggestExpense?.let { lines.add("بزرگ‌ترین هزینهٔ این ماه: ${it.title.ifBlank { "بدون عنوان" }} (${AmountFormatter.format(it.amount, it.currencyType, unit)}).") }
        if (d.avgDailyRial > 0) lines.add("میانگین هزینهٔ روزانهٔ این ماه: ${money(d.avgDailyRial)}.")
        if (lines.isEmpty()) return null
        val card = Ui.glass(a, 16)
        card.addView(Ui.text(a, "نگاهی به خرج‌هایت", 15f, Ui.ink, true))
        lines.forEach { card.addView(Ui.text(a, "• $it", 13f, Ui.ink).apply { setPadding(0, Ui.dp(a, 6), 0, 0) }) }
        return card
    }
}
