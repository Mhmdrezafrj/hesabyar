package ir.hesabyar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.plan.*
import ir.hesabyar.app.report.BudgetCalc
import ir.hesabyar.app.report.BudgetLevel
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.widget.PendingQueue
import java.util.TimeZone

/**
 * A family of home-screen widgets built to be noticed: one focal point each, colour that carries meaning,
 * text that changes (daily message, rotating note colour) and one-tap actions. Content logic lives in plan/WidgetContent.kt (tested).
 */
class WidgetSnapshot(c: Context) {
    val now = System.currentTimeMillis()
    val zone: TimeZone = TimeZone.getDefault()
    val all = TransactionStore.all(c)
    val summary = ReportCalculator(now).summary(all)
    val today = Jx.dayOf(now)
    val limits = BudgetStore.all(c)
    val plan = BudgetPlanner.plan(today, limits, summary.monthExpenseByCategory, summary.monthExpenseRial)
    val streak = Streak.compute(all.map { it.timestamp }, now, zone)
    val week = WeekMath.last7(all, now, zone)
    val dayIndex = Streak.dayIndex(now, zone)
}


abstract class AttentionWidget : AppWidgetProvider() {
    abstract fun build(c: Context): RemoteViews

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> try { manager.updateAppWidget(id, build(context)) } catch (_: Exception) { } }
    }

    companion object {
        private val all = listOf(BigNumberWidget::class.java, UrgentWidget::class.java, RingWidget::class.java, QuickAddWidget::class.java,
            NudgeWidget::class.java, GoalWidget::class.java, WeekWidget::class.java, StreakWidget::class.java, NoteWidget::class.java)

        fun updateAll(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                all.forEach { cls ->
                    val ids = m.getAppWidgetIds(ComponentName(c, cls))
                    if (ids.isNotEmpty()) {
                        val inst = cls.getDeclaredConstructor().newInstance()
                        inst.onUpdate(c, m, ids)
                    }
                }
            } catch (_: Exception) { }
        }

        fun fa(s: String) = AmountFormatter.toPersianDigits(s)
        fun money(c: Context, rial: Long) = AmountFormatter.format(rial, Currency.RIAL, DisplaySettings.get(c))

        fun openScreen(c: Context, code: Int, cls: Class<*>, configure: Intent.() -> Unit = {}): PendingIntent =
            PendingIntent.getActivity(c, code, Intent(c, cls).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; configure()
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        fun lightBg(l: Light) = when (l) {
            Light.GREEN -> R.drawable.bg_light_green; Light.AMBER -> R.drawable.bg_light_amber
            Light.RED -> R.drawable.bg_light_red; Light.NONE -> R.drawable.bg_night
        }
    }
}

/** 1) Traffic-light daily allowance: one huge number, colour = state. */
class BigNumberWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val s = WidgetSnapshot(c); val light = TrafficLight.of(s.plan)
        val v = RemoteViews(c.packageName, R.layout.widget_bignumber)
        v.setImageViewResource(R.id.w_bg, lightBg(light))
        v.setTextViewText(R.id.w_title, "امروز می‌توانی خرج کنی")
        when (light) {
            Light.NONE -> { v.setTextViewText(R.id.w_value, "بودجه بگذار"); v.setTextViewText(R.id.w_sub, "برای دیدن سقف روزانه") }
            Light.RED -> { v.setTextViewText(R.id.w_value, "بودجه تمام شد"); v.setTextViewText(R.id.w_sub, fa("${s.plan.daysLeft} روز تا آخر ماه")) }
            Light.AMBER -> { v.setTextViewText(R.id.w_value, money(c, s.plan.dailyAllowanceRial)); v.setTextViewText(R.id.w_sub, "با این روند از بودجه رد می‌شوی") }
            Light.GREEN -> { v.setTextViewText(R.id.w_value, money(c, s.plan.dailyAllowanceRial)); v.setTextViewText(R.id.w_sub, "روی مسیر خوبی هستی") }
        }
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9201, MainActivity::class.java))
        return v
    }
}

/** 2) The single most urgent thing, in red / amber / green. */
class UrgentWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val s = WidgetSnapshot(c); val plan = PlanStore.load(c)
        val over = BudgetCalc.statuses(s.summary.monthExpenseByCategory, s.limits).filter { it.level == BudgetLevel.OVER }.map { it.category }
        val u = UrgentPicker.pick(plan.bills, plan.debts, s.today, PendingQueue.pending(s.all).size, over, { fa(it) }, { money(c, it) })
        val v = RemoteViews(c.packageName, R.layout.widget_urgent)
        v.setImageViewResource(R.id.w_bg, when (u.level) { UrgentLevel.HIGH -> R.drawable.bg_light_red; UrgentLevel.MEDIUM -> R.drawable.bg_light_amber; UrgentLevel.NONE -> R.drawable.bg_light_green })
        v.setTextViewText(R.id.w_icon, when (u.level) { UrgentLevel.HIGH -> "🚨"; UrgentLevel.MEDIUM -> "⚠️"; UrgentLevel.NONE -> "✅" })
        v.setTextViewText(R.id.w_title, u.title); v.setTextViewText(R.id.w_sub, u.detail)
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9202, if (u.target == UrgentTarget.PLAN) PlanActivity::class.java else MainActivity::class.java))
        return v
    }
}

/** 3) Budget ring: the month's budget as a filling circle. */
class RingWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val s = WidgetSnapshot(c); val light = TrafficLight.of(s.plan); val pct = TrafficLight.percentUsed(s.plan)
        val v = RemoteViews(c.packageName, R.layout.widget_ring)
        v.setImageViewResource(R.id.w_bg, lightBg(light))
        v.setImageViewBitmap(R.id.w_img, WidgetBitmaps.ring(pct, if (light == Light.NONE) "—" else fa("$pct٪")))
        v.setTextViewText(R.id.w_title, if (light == Light.NONE) "بودجه تعیین نشده" else "از بودجهٔ این ماه مصرف شده")
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9203, ReportsActivity::class.java))
        return v
    }
}

/** 4) One-tap entry: removes the effort that makes people skip writing things down. */
class QuickAddWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.widget_quickadd)
        v.setImageViewResource(R.id.w_bg, R.drawable.bg_sun)
        v.setOnClickPendingIntent(R.id.w_btn_expense, openScreen(c, 9204, MainActivity::class.java) { action = "ADD_TRANSACTION"; putExtra("income", false) })
        v.setOnClickPendingIntent(R.id.w_btn_income, openScreen(c, 9205, MainActivity::class.java) { action = "ADD_TRANSACTION"; putExtra("income", true) })
        return v
    }
}

/** 5) A different message every day (personal facts first), so the eye does not learn to ignore it. */
class NudgeWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val s = WidgetSnapshot(c)
        val facts = NudgeFacts(s.streak.loggedToday, s.streak.days, PendingQueue.pending(s.all).size, s.week.expenseRial[5], s.plan.dailyAllowanceRial)
        val msg = Nudges.pick(Nudges.candidates(facts, { fa(it) }, { money(c, it) }), s.dayIndex)
        val v = RemoteViews(c.packageName, R.layout.widget_nudge)
        v.setImageViewResource(R.id.w_bg, R.drawable.bg_ocean)
        v.setTextViewText(R.id.w_title, "💡 یادآوری امروز")
        v.setTextViewText(R.id.w_value, msg)
        v.setTextViewText(R.id.w_sub, DashboardUi.todayText(s.now))
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9206, MainActivity::class.java))
        return v
    }
}

/** 6) The savings goal closest to completion (goal-gradient: progress near the finish line motivates most). */
class GoalWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val s = WidgetSnapshot(c)
        val goals = PlanStore.load(c).goals.filter { !GoalCalc.done(it) }
        val g = goals.maxByOrNull { GoalCalc.percent(it) }
        val v = RemoteViews(c.packageName, R.layout.widget_goal)
        v.setImageViewResource(R.id.w_bg, R.drawable.bg_mint)
        if (g == null) {
            v.setTextViewText(R.id.w_title, "هدف پس‌انداز"); v.setTextViewText(R.id.w_value, "—")
            v.setProgressBar(R.id.w_progress, 100, 0, false); v.setTextViewText(R.id.w_sub, "یک هدف بساز تا اینجا پیشرفتش را ببینی")
        } else {
            val need = GoalCalc.monthlyNeeded(g, Jx.monthKey(s.today))
            v.setTextViewText(R.id.w_title, g.title); v.setTextViewText(R.id.w_value, fa("${GoalCalc.percent(g)}٪"))
            v.setProgressBar(R.id.w_progress, 100, GoalCalc.percent(g), false)
            v.setTextViewText(R.id.w_sub, "${money(c, GoalCalc.remaining(g))} مانده" + (need?.let { " • ماهی ${money(c, it)}" } ?: ""))
        }
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9207, PlanActivity::class.java))
        return v
    }
}

/** 7) Last 7 days of spending as bars; today in yellow. */
class WeekWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val s = WidgetSnapshot(c)
        val v = RemoteViews(c.packageName, R.layout.widget_week)
        v.setImageViewResource(R.id.w_bg, R.drawable.bg_night)
        v.setTextViewText(R.id.w_title, "📊 هزینهٔ ۷ روز اخیر")
        v.setImageViewBitmap(R.id.w_img, WidgetBitmaps.week(s.week.expenseRial, s.week.weekdays))
        v.setTextViewText(R.id.w_sub, "جمع: ${money(c, s.week.expenseRial.sum())}")
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9208, ReportsActivity::class.java))
        return v
    }
}

/** 8) Streak of consecutive days with a recorded transaction (commitment + loss aversion). */
class StreakWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val st = WidgetSnapshot(c).streak
        val v = RemoteViews(c.packageName, R.layout.widget_streak)
        v.setImageViewResource(R.id.w_bg, R.drawable.bg_sun)
        v.setTextViewText(R.id.w_icon, if (st.days == 0) "🌱" else if (st.loggedToday) "🔥" else "⏳")
        v.setTextViewText(R.id.w_value, if (st.days == 0) "شروع کن" else fa("${st.days} روز پیاپی"))
        v.setTextViewText(R.id.w_sub, when {
            st.days == 0 -> "یک تراکنش ثبت کن تا زنجیره شروع شود"
            st.loggedToday -> "امروز ثبت شد؛ همین‌طور ادامه بده"
            else -> "امروز هنوز ثبت نکرده‌ای؛ زنجیره نشکند!"
        })
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9209, MainActivity::class.java) { action = "ADD_TRANSACTION" })
        return v
    }
}

/** 9) Sticky note: your own reminder; the paper colour changes daily so it stays visible. */
class NoteWidget : AttentionWidget() {
    override fun build(c: Context): RemoteViews {
        val s = WidgetSnapshot(c)
        val v = RemoteViews(c.packageName, R.layout.widget_note)
        v.setImageViewResource(R.id.w_bg, listOf(R.drawable.bg_note_yellow, R.drawable.bg_note_pink, R.drawable.bg_note_blue)[Math.floorMod(s.dayIndex, 3L).toInt()])
        val text = NoteStore.text(c)
        val age = if (text.isBlank() || NoteStore.savedAt(c) == 0L) 0 else ((s.now - NoteStore.savedAt(c)) / 86_400_000L).toInt()
        v.setTextViewText(R.id.w_title, "📌 یادداشت" + if (age > 0) " • ${fa("$age")} روز پیش نوشتی" else "")
        v.setTextViewText(R.id.w_value, if (text.isBlank()) "برای نوشتن یادداشت لمس کن ✍️" else text)
        v.setOnClickPendingIntent(R.id.w_root, openScreen(c, 9210, NoteActivity::class.java))
        return v
    }
}
