package ir.hesabyar.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.report.BudgetCalc
import ir.hesabyar.app.report.BudgetLevel
import ir.hesabyar.app.report.MonthlyTrend
import ir.hesabyar.app.report.RangePreset
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.report.ReportFilter
import ir.hesabyar.app.report.TypeFilter
import ir.hesabyar.app.widget.Categories
import ir.hesabyar.app.widget.JalaliCalendar
import java.util.Calendar

/** Financial reports computed from the real transaction store (see ReportCalculator for the rules). */
class ReportsActivity : Activity() {
    private val ink = Ui.ink
    private val green = Ui.green
    private val red = Ui.red
    private lateinit var summaryBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var categorySpinner: Spinner

    private val ranges = listOf("امروز" to RangePreset.TODAY, "۷ روز اخیر" to RangePreset.LAST_7_DAYS,
        "این ماه" to RangePreset.THIS_MONTH, "ماه قبل" to RangePreset.LAST_MONTH, "همه" to RangePreset.ALL)
    private val types = listOf("همه" to TypeFilter.ALL, "درآمد" to TypeFilter.INCOME, "هزینه" to TypeFilter.EXPENSE)
    private var rangeIndex = 2
    private var typeIndex = 0
    private var categoryIndex = 0
    private var categoryChoices: List<String?> = listOf(null)

    private fun fa(s: String) = AmountFormatter.toPersianDigits(s)
    private fun money(rial: Long) = AmountFormatter.format(rial, Currency.RIAL, DisplaySettings.get(this))
    private fun text(t: String, size: Float = 14f, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun card() = Ui.glass(this, 14)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)
        root.addView(Ui.title(this, "گزارش مالی"))
        root.addView(Ui.soft(this, "مدیریت دسته‌ها") { startActivity(Intent(this@ReportsActivity, CategoriesActivity::class.java)) }, Ui.margins(this, 0, 4))
        summaryBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(summaryBox)
        body.addView(text("فیلتر تراکنش‌ها", 16f, bold = true).apply { setPadding(0, 18, 0, 6) })
        body.addView(filterRow())
        body.addView(listBox)
        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun spinner(labels: List<String>, selected: Int, onPick: (Int) -> Unit) = Spinner(this).apply {
        adapter = ArrayAdapter(this@ReportsActivity, android.R.layout.simple_spinner_dropdown_item, labels)
        setSelection(selected)
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { if (pos != selectedStateFor(this@apply)) { onPick(pos) } }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }
    private fun selectedStateFor(s: Spinner): Int = when (s.tag) { "range" -> rangeIndex; "type" -> typeIndex; else -> categoryIndex }

    private fun filterRow(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        row.addView(spinner(ranges.map { it.first }, rangeIndex) { rangeIndex = it; refreshList() }.apply { tag = "range" }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(spinner(types.map { it.first }, typeIndex) { typeIndex = it; refreshList() }.apply { tag = "type" }, LinearLayout.LayoutParams(0, -2, 1f))
        categorySpinner = spinner(listOf("همه دسته‌ها"), 0) { categoryIndex = it; refreshList() }.apply { tag = "category" }
        row.addView(categorySpinner, LinearLayout.LayoutParams(0, -2, 1.3f))
        return row
    }

    private fun refresh() {
        // category filter choices: all + every category + uncategorised
        val cats = CategoryStore.all(this)
        categoryChoices = listOf<String?>(null) + cats + Categories.UNCATEGORIZED_LABEL
        val labels = listOf("همه دسته‌ها") + cats + Categories.UNCATEGORIZED_LABEL
        if (categoryIndex >= categoryChoices.size) categoryIndex = 0
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        categorySpinner.setSelection(categoryIndex)
        refreshSummary()
        refreshList()
    }

    private fun refreshSummary() {
        summaryBox.removeAllViews()
        val calc = ReportCalculator(System.currentTimeMillis())
        val s = calc.summary(TransactionStore.all(this))
        val cal = Calendar.getInstance()
        val j = JalaliCalendar.fromGregorian(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val monthName = JalaliCalendar.monthNames[j.month - 1]

        fun line(title: String, value: String, color: Int) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(text(title, 14f), LinearLayout.LayoutParams(0, -2, 1f)); addView(text(value, 15f, color, true))
        }
        val top = card()
        top.addView(line("هزینه امروز", money(s.todayExpenseRial), red))
        top.addView(line("هزینه $monthName", money(s.monthExpenseRial), red))
        top.addView(line("درآمد $monthName", money(s.monthIncomeRial), green))
        summaryBox.addView(top, Ui.margins(this, 10, 0))

        val cmp = card()
        cmp.addView(text("مقایسه با ماه قبل", 15f, bold = true))
        cmp.addView(text(compare("هزینه", s.monthExpenseRial, s.prevMonthExpenseRial, moreIsBad = true), 13f))
        cmp.addView(text(compare("درآمد", s.monthIncomeRial, s.prevMonthIncomeRial, moreIsBad = false), 13f))
        summaryBox.addView(cmp, Ui.margins(this, 10, 0))

        val cat = card()
        cat.addView(text("هزینه $monthName به تفکیک دسته", 15f, bold = true))
        if (s.monthExpenseByCategory.isEmpty()) cat.addView(text("هنوز هزینه‌ای در این ماه ثبت نشده است.", 13f, Color.GRAY))
        val max = s.monthExpenseByCategory.maxOfOrNull { it.totalRial } ?: 1L
        val sum = s.monthExpenseByCategory.sumOf { it.totalRial }.coerceAtLeast(1L)
        s.monthExpenseByCategory.forEach { c ->
            val pct = Math.round(c.totalRial * 100.0 / sum).toInt()
            cat.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, 8, 0, 0)
                addView(text(c.category, 13f), LinearLayout.LayoutParams(0, -2, 1f))
                addView(text("${money(c.totalRial)}  (${fa("$pct")}٪)", 13f, ink, true))
            })
            val w = (c.totalRial * 100 / max).toInt().coerceIn(2, 100)
            cat.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                addView(View(this@ReportsActivity).apply { background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ui.purple, Ui.blue)).apply { cornerRadius = 8f } }, LinearLayout.LayoutParams(0, Ui.dp(this@ReportsActivity, 8), w.toFloat()))
                addView(View(this@ReportsActivity), LinearLayout.LayoutParams(0, Ui.dp(this@ReportsActivity, 8), (100 - w).toFloat()))
            })
        }
        summaryBox.addView(cat, Ui.margins(this, 10, 0))

        // ---- budgets ----
        val budgets = BudgetStore.all(this)
        val bud = card()
        bud.addView(text("بودجه $monthName", 15f, bold = true))
        val statuses = BudgetCalc.statuses(s.monthExpenseByCategory, budgets)
        if (statuses.isEmpty()) bud.addView(text("هنوز بودجه‌ای تعیین نشده. برای هر دسته سقف ماهانه بگذار تا نزدیک شدن به سقف را ببینی.", 12f, Color.GRAY))
        statuses.forEach { st ->
            val color = when (st.level) { BudgetLevel.OK -> green; BudgetLevel.WARNING -> Color.rgb(230, 140, 20); BudgetLevel.OVER -> red }
            val flag = when (st.level) { BudgetLevel.OK -> ""; BudgetLevel.WARNING -> "  ⚠ نزدیک سقف"; BudgetLevel.OVER -> "  ⛔ از سقف گذشته" }
            bud.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, Ui.dp(this@ReportsActivity, 8), 0, 0)
                addView(text(st.category + flag, 13f, color, st.level != BudgetLevel.OK), LinearLayout.LayoutParams(0, -2, 1f))
                addView(text("${money(st.spentRial)} از ${money(st.limitRial)} (${fa("${st.percent}")}٪)", 12f))
            })
            val w = st.percent.coerceIn(2, 100)
            bud.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                addView(View(this@ReportsActivity).apply { setBackgroundColor(color) }, LinearLayout.LayoutParams(0, Ui.dp(this@ReportsActivity, 8), w.toFloat()))
                addView(View(this@ReportsActivity), LinearLayout.LayoutParams(0, Ui.dp(this@ReportsActivity, 8), (100 - w).toFloat()))
            })
        }
        bud.addView(Ui.soft(this, "تنظیم بودجه یک دسته") { pickBudgetCategory() }, Ui.margins(this, 10, 0))
        summaryBox.addView(bud, Ui.margins(this, 10, 0))

        // ---- 6-month trend ----
        val trend = MonthlyTrend.last(TransactionStore.all(this), 6, System.currentTimeMillis())
        val tcard = card()
        tcard.addView(text("روند ۶ ماه اخیر", 15f, bold = true))
        tcard.addView(text("بنفش: هزینه • سبز: درآمد", 11f, Color.GRAY))
        val tmax = trend.maxOf { maxOf(it.expenseRial, it.incomeRial) }.coerceAtLeast(1L)
        trend.forEach { m ->
            tcard.addView(text("${m.monthName} ${fa("${m.year}")}", 12f).apply { setPadding(0, Ui.dp(this@ReportsActivity, 8), 0, 0) })
            fun bar(value: Long, color: Int, label: String) = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = android.view.Gravity.CENTER_VERTICAL
                val w = if (value <= 0) 1 else (value * 100 / tmax).toInt().coerceIn(2, 100)
                addView(View(this@ReportsActivity).apply { setBackgroundColor(color) }, LinearLayout.LayoutParams(0, Ui.dp(this@ReportsActivity, 6), w.toFloat()))
                addView(View(this@ReportsActivity), LinearLayout.LayoutParams(0, Ui.dp(this@ReportsActivity, 6), (100 - w).toFloat()))
            }
            tcard.addView(bar(m.expenseRial, Ui.purple, ""))
            tcard.addView(bar(m.incomeRial, green, "").apply { setPadding(0, Ui.dp(this@ReportsActivity, 2), 0, 0) })
            tcard.addView(text("هزینه ${money(m.expenseRial)} • درآمد ${money(m.incomeRial)}", 11f, Color.GRAY))
        }
        summaryBox.addView(tcard, Ui.margins(this, 10, 0))
    }

    private fun pickBudgetCategory() {
        CategoryPicker.show(this, "بودجه برای کدام دسته؟") { cat ->
            val unit = DisplaySettings.get(this)
            val input = EditText(this).apply {
                hint = "سقف ماهانه به ${unit.labelFa} (۰ = حذف بودجه)"
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            android.app.AlertDialog.Builder(this).setTitle("بودجه «$cat»").setView(input)
                .setNegativeButton("لغو", null)
                .setPositiveButton("ذخیره") { _, _ ->
                    val n = ir.hesabyar.app.parser.TextNormalizer.normalize(input.text.toString()).replace(",", "").trim().toLongOrNull()
                    if (n == null || n < 0) Toast.makeText(this, "مبلغ معتبر وارد کن", Toast.LENGTH_SHORT).show()
                    else { BudgetStore.set(this, cat, ir.hesabyar.app.money.Money.toRial(n, unit)); refresh() }
                }.show()
        }
    }

    private fun compare(label: String, cur: Long, prev: Long, moreIsBad: Boolean): String {
        val p = ReportCalculator.percentChange(cur, prev) ?: return "$label: برای ماه قبل داده‌ای ثبت نشده است"
        return when {
            p > 0 -> "$label: ${fa("$p")}٪ بیشتر از ماه قبل"
            p < 0 -> "$label: ${fa("${-p}")}٪ کمتر از ماه قبل"
            else -> "$label: بدون تغییر نسبت به ماه قبل"
        }
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val calc = ReportCalculator(System.currentTimeMillis())
        val f = ReportFilter(ranges[rangeIndex].second, types[typeIndex].second, categoryChoices.getOrNull(categoryIndex))
        val rows = calc.filter(TransactionStore.all(this), f)
        val t = calc.totals(rows)
        listBox.addView(text("نگه‌داشتن روی تراکنش = حذف • ${fa("${rows.size}")} تراکنش • هزینه: ${money(t.expenseRial)} • درآمد: ${money(t.incomeRial)}", 12f, Color.GRAY).apply { setPadding(0, 8, 0, 8) })
        val unit = DisplaySettings.get(this)
        rows.take(200).forEach { tx ->
            val c = card()
            c.addView(text(tx.title, 15f, bold = true))
            c.addView(text("${tx.bank} • ${tx.time} • ${calc.categoryLabel(tx)}", 12f, Color.GRAY))
            c.addView(text(AmountFormatter.formatSigned(tx.amount, tx.isIncome, tx.currencyType, unit), 14f, if (tx.isIncome) green else red, true))
            c.setOnClickListener {
                CategoryPicker.show(this, "تغییر دسته: ${tx.title}") { picked ->
                    TransactionStore.categorize(this, tx.id, picked)
                    PendingTransactionsWidget.updateAll(this)
                    refresh()
                }
            }
            c.setOnLongClickListener {
                android.app.AlertDialog.Builder(this).setTitle("حذف تراکنش؟")
                    .setMessage("«${tx.title}» حذف می‌شود. اگر از پیامک ساخته شده باشد، دوباره خودکار ثبت نخواهد شد.")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("حذف") { _, _ ->
                        TransactionStore.delete(this, tx.id); PendingTransactionsWidget.updateAll(this); refresh()
                    }.show()
                true
            }
            listBox.addView(c, Ui.margins(this, 0, 8))
        }
        if (rows.size > 200) listBox.addView(text("۲۰۰ تراکنش اول نمایش داده شد؛ فیلتر را محدودتر کن.", 12f, Color.GRAY))
        if (rows.isEmpty()) listBox.addView(text("تراکنشی با این فیلتر پیدا نشد.", 13f, Color.GRAY))
    }
}
