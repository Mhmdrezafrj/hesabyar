package ir.hesabyar.app

import android.content.Context
import ir.hesabyar.app.plan.*
import java.util.UUID

/** Bills, savings goals and debts. Stored only on this phone (text form from PlanCodec). */
object PlanStore {
    private const val PREFS = "hesabyar_plan"
    private const val KEY = "data"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun newId() = UUID.randomUUID().toString().take(12)

    @Synchronized fun load(c: Context): PlanData = PlanCodec.decode(p(c).getString(KEY, "") ?: "")
    @Synchronized private fun save(c: Context, d: PlanData) { p(c).edit().putString(KEY, PlanCodec.encode(d)).apply() }
    fun encoded(c: Context): String = p(c).getString(KEY, "") ?: ""

    @Synchronized fun merge(c: Context, incoming: PlanData) { save(c, PlanCodec.mergeMissing(load(c), incoming)) }
    @Synchronized fun wipe(c: Context) { p(c).edit().clear().apply() }

    // ---- bills ----
    @Synchronized fun addBill(c: Context, title: String, amountRial: Long, day: Int) {
        val d = load(c); save(c, d.copy(bills = d.bills + Bill(newId(), title, amountRial, day.coerceIn(1, 31))))
    }
    @Synchronized fun updateBill(c: Context, b: Bill) { val d = load(c); save(c, d.copy(bills = d.bills.map { if (it.id == b.id) b else it })) }
    @Synchronized fun removeBill(c: Context, id: String) { val d = load(c); save(c, d.copy(bills = d.bills.filter { it.id != id })) }

    // ---- goals ----
    @Synchronized fun addGoal(c: Context, title: String, targetRial: Long, deadlineMonthKey: Int) {
        val d = load(c); save(c, d.copy(goals = d.goals + Goal(newId(), title, targetRial, 0L, deadlineMonthKey)))
    }
    @Synchronized fun updateGoal(c: Context, g: Goal) { val d = load(c); save(c, d.copy(goals = d.goals.map { if (it.id == g.id) g else it })) }
    @Synchronized fun removeGoal(c: Context, id: String) { val d = load(c); save(c, d.copy(goals = d.goals.filter { it.id != id })) }

    // ---- debts ----
    @Synchronized fun addDebt(c: Context, person: String, amountRial: Long, iOwe: Boolean, dueKey: Int) {
        val d = load(c); save(c, d.copy(debts = d.debts + Debt(newId(), person, amountRial, iOwe, dueKey)))
    }
    @Synchronized fun updateDebt(c: Context, x: Debt) { val d = load(c); save(c, d.copy(debts = d.debts.map { if (it.id == x.id) x else it })) }
    @Synchronized fun removeDebt(c: Context, id: String) { val d = load(c); save(c, d.copy(debts = d.debts.filter { it.id != id })) }
}
