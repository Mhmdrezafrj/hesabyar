package ir.hesabyar.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import ir.hesabyar.app.plan.Insights

/** Small drawings for RemoteViews (images are the only way to show rings and bars in a widget). */
object WidgetBitmaps {
    /** Ring showing [percent] (0..100) with the number in the middle. */
    fun ring(percent: Int, label: String, size: Int = 320): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val stroke = size * 0.13f
        val r = RectF(stroke, stroke, size - stroke, size - stroke)
        val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke; color = 0x55FFFFFF }
        c.drawArc(r, 0f, 360f, false, track)
        val p = percent.coerceIn(0, 100)
        val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke; color = 0xFFFFFFFF.toInt(); strokeCap = Paint.Cap.ROUND }
        if (p > 0) c.drawArc(r, -90f, 360f * p / 100f, false, arc)
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textSize = size * 0.24f; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        c.drawText(label, size / 2f, size / 2f + t.textSize * 0.35f, t)
        return bmp
    }

    /** Seven bars (oldest to newest); today's bar is highlighted. */
    fun week(values: List<Long>, weekdays: List<Int>, w: Int = 760, h: Int = 300): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val max = (values.maxOrNull() ?: 0L).coerceAtLeast(1L)
        val slot = w / 7f
        val labelH = h * 0.18f
        val chartH = h - labelH - 8f
        val bar = Paint(Paint.ANTI_ALIAS_FLAG)
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = labelH * 0.75f; textAlign = Paint.Align.CENTER; color = 0xFFC9D3FF.toInt() }
        for (i in 0 until 7) {
            val v = values.getOrElse(i) { 0L }
            val bh = if (v <= 0) 4f else (chartH * v / max).coerceAtLeast(10f)
            bar.color = if (i == 6) 0xFFFFC837.toInt() else 0xFF7C9CFF.toInt()
            val left = i * slot + slot * 0.18f; val right = (i + 1) * slot - slot * 0.18f
            c.drawRoundRect(RectF(left, chartH - bh, right, chartH), 10f, 10f, bar)
            c.drawText(Insights.weekdayName(weekdays.getOrElse(i) { 7 }).take(2), i * slot + slot / 2, h - 6f, txt)
        }
        return bmp
    }
}
