package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import ir.hesabyar.app.widget.CategoryOps
import ir.hesabyar.app.widget.Categories

/** Add / rename / delete categories. */
class CategoriesActivity : Activity() {
    private val ink = Color.rgb(45, 36, 79)
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 28, 20, 20)
            setBackgroundColor(Color.rgb(246, 242, 255)); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply { text = "مدیریت دسته‌ها"; textSize = 22f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(TextView(this).apply {
            text = "با تغییر نام، تراکنش‌های آن دسته هم به‌روز می‌شوند. با حذف، تراکنش‌ها به «سایر» می‌روند. دسته‌های «سایر» و «انتقال بین حساب‌ها» ثابت‌اند؛ انتقال بین حساب‌ها در گزارش‌ها دوباره‌شماری نمی‌شود."
            textSize = 12f; setTextColor(Color.GRAY); setPadding(0, 6, 0, 10)
        })
        root.addView(Button(this).apply { text = "＋ افزودن دسته"; setOnClickListener { askName("دسته جدید", "") { n ->
            CategoryStore.add(this@CategoriesActivity, n)?.let { Toast.makeText(this@CategoriesActivity, it, Toast.LENGTH_SHORT).show() }; render() } } })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    private fun render() {
        list.removeAllViews()
        CategoryStore.all(this).forEach { name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(14, 8, 14, 8); setBackgroundColor(Color.WHITE); layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            row.addView(TextView(this).apply { text = name; textSize = 15f; setTextColor(ink) }, LinearLayout.LayoutParams(0, -2, 1f))
            if (name in Categories.protectedNames) {
                row.addView(TextView(this).apply { text = "ثابت"; textSize = 12f; setTextColor(Color.GRAY) })
            } else {
                row.addView(Button(this).apply { text = "ویرایش"; setOnClickListener { askName("تغییر نام دسته", name) { n ->
                    CategoryStore.rename(this@CategoriesActivity, name, n)?.let { Toast.makeText(this@CategoriesActivity, it, Toast.LENGTH_SHORT).show() }; render() } } })
                row.addView(Button(this).apply { text = "حذف"; setOnClickListener {
                    AlertDialog.Builder(this@CategoriesActivity).setTitle("حذف «$name»؟")
                        .setMessage("تراکنش‌های این دسته به «سایر» منتقل می‌شوند.")
                        .setNegativeButton("انصراف", null)
                        .setPositiveButton("حذف") { _, _ -> CategoryStore.delete(this@CategoriesActivity, name); render() }.show() } })
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        }
    }

    private fun askName(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply { setText(initial); hint = "نام دسته" }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setNegativeButton("لغو", null)
            .setPositiveButton("تأیید") { _, _ -> onOk(CategoryOps.clean(input.text.toString())) }.show()
    }
}
