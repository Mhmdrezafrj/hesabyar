package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.EditText
import android.widget.Toast
import ir.hesabyar.app.widget.CategoryOps

/** One shared "choose category" sheet (app, history, reports and widget) with "+ new category". */
object CategoryPicker {
    private val pastel = intArrayOf(
        Color.rgb(237, 231, 255), Color.rgb(224, 236, 255), Color.rgb(255, 230, 242),
        Color.rgb(222, 247, 236), Color.rgb(255, 243, 220)
    )

    private fun emojiFor(name: String): String = when {
        name.startsWith("خوراک") -> "🍽️"
        name.startsWith("حمل") -> "🚗"
        name.startsWith("خرید") -> "🛍️"
        name.startsWith("مسکن") -> "🏠"
        name.startsWith("قبوض") -> "💡"
        name.startsWith("درمان") -> "🩺"
        name.startsWith("تفریح") -> "🎬"
        name.startsWith("آموزش") -> "📚"
        name == "درآمد" -> "💰"
        name.startsWith("انتقال") -> "🔁"
        name == "سایر" -> "📦"
        else -> "🏷️"
    }

    fun show(activity: Activity, title: String, onCancel: () -> Unit = {}, onPicked: (String) -> Unit) {
        val cats = CategoryStore.all(activity)
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        fun dp(v: Int) = Ui.dp(activity, v)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(14))
            background = Ui.rounded(dp(28).toFloat(), Color.rgb(250, 247, 255), Color.argb(255, 226, 216, 255), dp(1))
        }
        root.addView(Ui.text(activity, title, 17f, Ui.ink, true))
        root.addView(Ui.text(activity, "یک دسته انتخاب کن", 12f, Ui.muted).apply { setPadding(0, dp(4), 0, dp(12)) })

        val grid = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val entries = cats.map { it to false } + ("دسته جدید" to true)
        var colorIndex = 0
        entries.chunked(2).forEach { pair ->
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            pair.forEachIndexed { i, entry ->
                val name = entry.first
                val isNew = entry.second
                val tint = if (isNew) Color.argb(0, 0, 0, 0) else pastel[colorIndex++ % pastel.size]
                val chip = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(12), 0, dp(10), 0)
                    background = if (isNew) Ui.rounded(dp(18).toFloat(), Color.WHITE, Ui.purple, dp(1))
                                 else Ui.rounded(dp(18).toFloat(), tint, Color.WHITE, dp(1))
                    isClickable = true
                    addView(Ui.text(activity, if (isNew) "＋" else emojiFor(name), 18f).apply { setPadding(0, 0, dp(8), 0) })
                    addView(Ui.text(activity, name, 13f, if (isNew) Ui.purple else Ui.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
                    setOnClickListener {
                        dialog.dismiss()
                        if (isNew) askNew(activity, onCancel, onPicked) else onPicked(name)
                    }
                }
                row.addView(chip, LinearLayout.LayoutParams(0, dp(52), 1f).apply {
                    if (i == 1) marginStart = dp(8)
                    bottomMargin = dp(8)
                })
            }
            if (pair.size == 1) row.addView(View(activity), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = dp(8) })
            grid.addView(row)
        }

        val dm = activity.resources.displayMetrics
        val wanted = ((entries.size + 1) / 2) * dp(60)
        val scroll = ScrollView(activity).apply { addView(grid) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, minOf(wanted, (dm.heightPixels * 0.55).toInt())))
        root.addView(Ui.soft(activity, "انصراف") { dialog.cancel() }, Ui.margins(activity, 6, 0))

        dialog.setContentView(root)
        dialog.setOnCancelListener { onCancel() }
        dialog.show()
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((dm.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun askNew(activity: Activity, onCancel: () -> Unit, onPicked: (String) -> Unit) {
        val input = EditText(activity).apply { hint = "نام دسته جدید" }
        AlertDialog.Builder(activity).setTitle("دسته جدید").setView(input)
            .setPositiveButton("افزودن") { _, _ ->
                val name = CategoryOps.clean(input.text.toString())
                val error = CategoryStore.add(activity, name)
                if (error != null) { Toast.makeText(activity, error, Toast.LENGTH_SHORT).show(); onCancel() }
                else onPicked(name)
            }
            .setNegativeButton("لغو") { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .show()
    }
}
