package ir.hesabyar.app

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import ir.hesabyar.app.backup.BackupCodec
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** All settings and tools in one grouped screen (moved out of the home page). */
class SettingsActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var rootView: LinearLayout
    private val reqExport = 3101
    private val reqImport = 3102
    private val reqCsv = 3104
    private val notifRequestCode = 2103
    private val smsRequestCode = 2102
    private val smsPermissions = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)
        rootView = root
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)
        build()
    }

    // ---------- layout helpers ----------
    private fun section(title: String) {
        content.addView(Ui.text(this, title, 13f, Ui.muted, true).apply { setPadding(Ui.dp(context, 6), Ui.dp(context, 14), 0, Ui.dp(context, 6)) })
    }

    /** One row: title + explanation on the right, [trailing] view on the left. */
    private fun row(title: String, sub: String, trailing: View?, onClick: () -> Unit) {
        val card = Ui.glass(this, 14)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui.text(this, title, 15f, Ui.ink, true))
        if (sub.isNotEmpty()) texts.addView(Ui.text(this, sub, 12f, Ui.muted).apply { setPadding(0, Ui.dp(context, 2), 0, 0) })
        card.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) card.addView(trailing, LinearLayout.LayoutParams(-2, -2).apply { marginStart = Ui.dp(this@SettingsActivity, 10) })
        card.isClickable = true; card.isFocusable = true
        card.setOnClickListener { onClick() }
        content.addView(card, Ui.margins(this, 0, 8))
    }

    private fun toggle(title: String, sub: String, on: Boolean, onChange: () -> Unit) {
        val sw = Switch(this).apply { isChecked = on; isClickable = false; isFocusable = false }
        row(title, sub, sw, onChange)
    }

    private fun value(t: String): View = Ui.chip(this, t)
    private fun arrow(): View = Ui.text(this, "‹", 22f, Ui.muted, true)

    private fun build() {
        content.removeAllViews()
        content.addView(Ui.title(this, "⚙ تنظیمات", "همه چیز فقط روی همین گوشی می‌ماند"))

        section("پیامک بانکی")
        row("دسترسی پیامک", if (smsPermissions.all { hasPermission(it) }) "داده شده ✓" else "برای ثبت خودکار تراکنش لازم است", value(if (smsPermissions.all { hasPermission(it) }) "فعال" else "درخواست"), { explainAndRequestSmsPermissions() })
        toggle("دریافت و تشخیص خودکار", "پیامک‌های بانکی خودکار وارد می‌شوند", SmsSettings.autoEnabled(this)) {
            SmsSettings.setAutoEnabled(this, !SmsSettings.autoEnabled(this)); build(); runCatchUp()
        }
        row("وضعیت دریافت خودکار", "آخرین دریافت، خطاها و تنظیم باتری", arrow(), { showSmsStatus() })
        row("وارد کردن پیامک‌های قبلی", "۹۰ روز اخیر را بررسی می‌کند", arrow(), { importHistory() })

        section("ظاهر")
        row("حالت نمایش", "روشن، تیره یا مطابق سیستم", value(ThemeSettings.label(ThemeSettings.get(this))), {
            ThemeSettings.set(this, ThemeSettings.next(ThemeSettings.get(this)))
            recreate()
        })
        row("واحد نمایش مبلغ", "فقط نمایش؛ مقدار ذخیره‌شده تغییر نمی‌کند", value(DisplaySettings.get(this).labelFa), {
            DisplaySettings.toggle(this); PendingTransactionsWidget.updateAll(this); build()
        })
        row("🎨 طراحی ظاهر ویجت‌ها", "تم، رنگ، فونت و بلوک‌ها", arrow(), { startActivity(Intent(this, WidgetDesignActivity::class.java)) })

        section("امنیت و هشدار")
        toggle("قفل برنامه", "با قفل صفحهٔ خود گوشی", AppLock.enabled(this)) { toggleLock() }
        toggle("هشدار بودجه، قبض و هزینهٔ غیرمعمول", "اعلان روزانه؛ بدون متن پیامک", AlertSettings.enabled(this)) { toggleAlerts() }

        section("داده‌ها")
        row("خروجی CSV برای اکسل", "همهٔ تراکنش‌ها در یک فایل جدول", arrow(), { confirmCsv() })
        row("پشتیبان‌گیری", "فایل متنی روی حافظهٔ خودت", arrow(), { confirmExport() })
        row("بازگردانی از فایل پشتیبان", "فقط موارد جدید اضافه می‌شود", arrow(), { pickBackupFile() })
        row("حریم خصوصی و حذف داده‌ها", "برنامه مجوز اینترنت ندارد", arrow(), { showPrivacyDialog() })

        section("دربارهٔ برنامه")
        row("راهنمای سریع", "این برنامه چطور کار می‌کند", arrow(), { startActivity(Intent(this, WelcomeActivity::class.java).putExtra("replay", true)) })
        content.addView(Ui.text(this, "حساب‌یار نسخهٔ ${versionName()}", 12f, Ui.muted).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(context, 14), 0, Ui.dp(context, 20)) })
    }

    private fun versionName(): String = try {
        AmountFormatter.toPersianDigits(packageManager.getPackageInfo(packageName, 0).versionName ?: "")
    } catch (_: Exception) { "" }

    // ---------- SMS ----------
    private fun hasPermission(permission: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun runCatchUp() { Thread { SmsCatchUp.run(this) }.start() }

    private fun explainAndRequestSmsPermissions() {
        val missing = smsPermissions.filterNot { hasPermission(it) }
        if (missing.isEmpty()) {
            Ui.dialog(this).setTitle("دسترسی پیامک فعال است")
                .setMessage("دریافت پیامک‌های جدید فعال است. برای واردکردن پیامک‌های قبلی نیز می‌توانی از گزینهٔ مربوط استفاده کنی.")
                .setPositiveButton("باشه", null).show()
            return
        }
        Ui.dialog(this)
            .setTitle("اجازه دسترسی به پیامک‌ها")
            .setMessage("حساب‌یار برای شناسایی پیامک‌های بانکی به دریافت پیامک‌های جدید نیاز دارد. برای واردکردن پیامک‌های ۹۰ روز اخیر، دسترسی خواندن پیامک‌ها هم لازم است. فقط پیامک‌هایی که شبیه تراکنش مالی هستند روی همین گوشی ذخیره می‌شوند و شماره کارت در آن‌ها پوشانده می‌شود. برنامه مجوز اینترنت ندارد و هیچ پیامکی ارسال نمی‌شود. ممکن است اندروید یا روش نصب APK دسترسی را محدود کند.")
            .setNegativeButton("فعلاً نه", null)
            .setPositiveButton("ادامه و درخواست مجوز") { _, _ -> requestPermissions(missing.toTypedArray(), smsRequestCode) }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == notifRequestCode) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) Notifier.check(this)
            else Toast.makeText(this, "اجازهٔ اعلان داده نشد؛ هشدارها نمایش داده نمی‌شوند.", Toast.LENGTH_LONG).show()
            build(); return
        }
        if (requestCode == smsRequestCode) {
            val granted = permissions.zip(grantResults.toList()).filter { it.second == PackageManager.PERMISSION_GRANTED }.map { it.first }
            val message = buildString {
                append(if (granted.isEmpty()) "مجوزی داده نشد." else "مجوزهای تأییدشده: ${granted.joinToString()}.")
                if (!hasPermission(Manifest.permission.RECEIVE_SMS)) append(" دریافت پیامک جدید فعال نیست.")
                if (!hasPermission(Manifest.permission.READ_SMS)) append(" واردکردن پیامک‌های قبلی فعال نیست.")
                append(" اگر اندروید دسترسی را مسدود کرده، وضعیت مجوزها را در تنظیمات برنامه بررسی کن.")
            }
            runCatchUp(); build()
            Ui.dialog(this).setTitle("وضعیت دسترسی").setMessage(message).setPositiveButton("باشه", null).show()
        }
    }

    private fun showSmsStatus() {
        fun ago(t: Long): String {
            if (t <= 0L) return "هنوز ثبت نشده"
            val m = (System.currentTimeMillis() - t) / 60000
            return AmountFormatter.toPersianDigits(if (m < 1) "همین الان" else if (m < 60) "$m دقیقه پیش" else if (m < 1440) "${m / 60} ساعت پیش" else "${m / 1440} روز پیش")
        }
        val err = SmsSettings.lastLiveError(this)
        val msg = "دریافت خودکار: " + (if (SmsSettings.autoEnabled(this)) "روشن" else "خاموش") +
            "\nاجازهٔ خواندن پیامک: " + (if (SmsCatchUp.hasReadPermission(this)) "داده شده" else "داده نشده") +
            "\nآخرین دریافت لحظه‌ای پیامک: " + ago(SmsSettings.lastLive(this)) +
            "\nآخرین بررسی پس‌زمینه: " + ago(SmsSettings.lastBackground(this)) +
            (if (err.isNotEmpty()) "\nآخرین خطا: $err" else "") +
            "\n\nاگر پیامک‌ها دیر وارد می‌شوند، برای حساب‌یار «بدون محدودیت باتری» را انتخاب کن (دکمهٔ زیر)."
        Ui.dialog(this).setTitle("وضعیت دریافت خودکار").setMessage(msg)
            .setNegativeButton("بستن", null)
            .setNeutralButton("بررسی همین الان") { _, _ -> runCatchUp(); Toast.makeText(this, "در حال بررسی…", Toast.LENGTH_SHORT).show() }
            .setPositiveButton("تنظیم باتری") { _, _ ->
                try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {
                    startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName")))
                }
            }.show()
    }

    private fun importHistory() {
        if (!hasPermission(Manifest.permission.READ_SMS)) { explainAndRequestSmsPermissions(); return }
        Ui.dialog(this).setTitle("واردکردن پیامک‌های قبلی")
            .setMessage("تا ۱۰۰۰ پیامک دریافتی از ۹۰ روز اخیر بررسی می‌شود. فقط پیامک‌های مشکوک به تراکنش مالی ذخیره می‌شوند. متن سایر پیامک‌ها ذخیره نخواهد شد. ادامه می‌دهی؟")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("شروع") { _, _ ->
                try {
                    val result = SmsHistoryImporter.importRecent(this)
                    PendingTransactionsWidget.updateAll(this)
                    Ui.dialog(this).setTitle("پایان بررسی")
                        .setMessage("بررسی‌شده: ${result.scanned}\nذخیره‌شده: ${result.saved}\nتکراری یا غیرمالی: ${result.duplicatesOrSkipped}")
                        .setPositiveButton("مشاهده صندوق") { _, _ -> startActivity(Intent(this, SmsInboxActivity::class.java)) }.show()
                } catch (e: SecurityException) {
                    Toast.makeText(this, "دسترسی خواندن پیامک داده نشده است.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "خطا در واردکردن پیامک‌ها: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    // ---------- lock ----------
    private fun toggleLock() {
        if (AppLock.enabled(this)) { AppLock.setEnabled(this, false) }
        else {
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            if (!km.isDeviceSecure) {
                Toast.makeText(this, "اول در تنظیمات گوشی، قفل صفحه (پین، الگو یا اثر انگشت) را فعال کن.", Toast.LENGTH_LONG).show()
            } else { AppLock.setEnabled(this, true); AppLock.touch(this) }
        }
        build()
    }

    // ---------- alerts ----------
    private fun toggleAlerts() {
        if (AlertSettings.enabled(this)) {
            AlertSettings.setEnabled(this, false); Notifier.scheduleDaily(this)
        } else {
            AlertSettings.setEnabled(this, true); Notifier.scheduleDaily(this)
            if (!Notifier.canNotify(this)) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notifRequestCode)
            else Notifier.check(this)
        }
        build()
    }

    // ---------- CSV / backup / restore ----------
    private fun confirmCsv() {
        Ui.dialog(this).setTitle("خروجی CSV")
            .setMessage("همهٔ تراکنش‌ها در یک فایل جدولی ساخته می‌شود که با اکسل باز می‌شود. مبلغ‌ها به ریال هستند (هزینه منفی). فایل رمزگذاری‌شده نیست؛ آن را فقط جای امن نگه‌دار.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ادامه") { _, _ ->
                val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, "hesabyar-$day.csv")
                }, reqCsv)
            }.show()
    }

    private fun writeCsv(uri: android.net.Uri) {
        try {
            val text = ir.hesabyar.app.plan.CsvExport.build(TransactionStore.all(this))
            contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: throw java.io.IOException("no stream")
            Toast.makeText(this, "فایل CSV ذخیره شد.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ذخیرهٔ فایل ناموفق بود.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmExport() {
        Ui.dialog(this).setTitle("پشتیبان‌گیری")
            .setMessage("یک فایل متنی شامل تراکنش‌ها، دسته‌ها، بودجه‌ها و برنامه‌ریزی (قبض، هدف، بدهی) ساخته می‌شود. فایل رمزگذاری‌شده نیست؛ هر کس آن را داشته باشد می‌تواند اطلاعات مالی‌ات را ببیند. آن را فقط جای امن نگه‌دار و برای کسی نفرست.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ادامه") { _, _ ->
                val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, "hesabyar-backup-$day.txt")
                }, reqExport)
            }.show()
    }

    private fun pickBackupFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, reqImport)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            reqCsv -> writeCsv(uri)
            reqExport -> writeBackup(uri)
            reqImport -> restoreBackup(uri)
        }
    }

    private fun writeBackup(uri: android.net.Uri) {
        try {
            val text = BackupCodec.encode(TransactionStore.all(this), CategoryStore.all(this), BudgetStore.all(this),
                mapOf("plan" to PlanStore.encoded(this)))
            contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: throw java.io.IOException("no stream")
            Toast.makeText(this, "پشتیبان ذخیره شد.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ذخیرهٔ پشتیبان ناموفق بود.", Toast.LENGTH_LONG).show()
        }
    }

    private fun restoreBackup(uri: android.net.Uri) {
        val text = try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null || bytes.size > 20_000_000) null else bytes.toString(Charsets.UTF_8)
        } catch (e: Exception) { null }
        if (text == null) { Toast.makeText(this, "فایل خوانده نشد یا خیلی بزرگ است.", Toast.LENGTH_LONG).show(); return }
        val result = BackupCodec.decode(text)
        val data = result.data
        if (data == null) { Toast.makeText(this, result.error ?: "فایل نامعتبر است", Toast.LENGTH_LONG).show(); return }
        val added = TransactionStore.importMissing(this, data.transactions)
        data.categories.forEach { CategoryStore.add(this, it) }
        val budgets = BudgetStore.all(this)
        data.budgets.forEach { (cat, limit) -> if (cat !in budgets) BudgetStore.set(this, cat, limit) }
        data.extras["plan"]?.let { PlanStore.merge(this, ir.hesabyar.app.plan.PlanCodec.decode(it)) }
        PendingTransactionsWidget.updateAll(this)
        Toast.makeText(this, "بازگردانی انجام شد: ${AmountFormatter.toPersianDigits("$added")} تراکنش جدید اضافه شد.", Toast.LENGTH_LONG).show()
    }

    // ---------- privacy ----------
    private fun showPrivacyDialog() {
        Ui.dialog(this).setTitle("حریم خصوصی")
            .setMessage("• همه اطلاعات فقط روی همین گوشی ذخیره می‌شود. برنامه مجوز اینترنت ندارد و هیچ اطلاعاتی ارسال نمی‌کند.\n" +
                "• پشتیبان‌گیری ابری برنامه خاموش است.\n" +
                "• شماره کارت و شبا پیش از ذخیره‌شدن متن پیامک، پوشانده می‌شود (فقط ۴ رقم آخر می‌ماند).\n" +
                "• اعلانی با متن پیامک نمایش داده نمی‌شود و متن پیامک در گزارش خطا ثبت نمی‌شود.\n" +
                "• دسترسی پیامک فقط برای تشخیص پیامک‌های بانکی است؛ هر زمان خواستی «دریافت و تشخیص خودکار» را خاموش کن یا مجوز را در تنظیمات اندروید بگیر.\n" +
                "• حذف یک تراکنش: در «گزارش مالی»، روی تراکنش نگه‌دار.")
            .setNegativeButton("بستن", null)
            .setPositiveButton("حذف همه داده‌ها…") { _, _ -> confirmWipe() }
            .show()
    }

    private fun confirmWipe() {
        Ui.dialog(this).setTitle("حذف همه داده‌ها؟")
            .setMessage("همه تراکنش‌ها، دسته‌ها و صندوق پیامک‌ها برای همیشه از این گوشی پاک می‌شود و قابل بازیابی نیست. پیامک‌های قدیمی دوباره خودکار وارد نمی‌شوند؛ فقط پیامک‌های جدید از این لحظه بررسی می‌شوند.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("حذف کن") { _, _ ->
                DataWiper.wipeAll(this); PendingTransactionsWidget.updateAll(this)
                Toast.makeText(this, "همه داده‌ها حذف شد", Toast.LENGTH_LONG).show()
            }.show()
    }
}
