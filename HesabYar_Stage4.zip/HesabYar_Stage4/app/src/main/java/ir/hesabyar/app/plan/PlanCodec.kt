package ir.hesabyar.app.plan

import ir.hesabyar.app.backup.BackupCodec

data class PlanData(val bills: List<Bill> = emptyList(), val goals: List<Goal> = emptyList(), val debts: List<Debt> = emptyList(), val badLines: Int = 0)

/** Text form of bills / goals / debts (tab separated lines). Used for phone storage and inside backups. Pure and tested. */
object PlanCodec {
    fun encode(d: PlanData): String {
        val sb = StringBuilder()
        fun line(vararg f: String) = sb.append(f.joinToString("\t") { BackupCodec.esc(it) }).append('\n')
        d.bills.forEach { line("BILL", it.id, it.title, it.amountRial.toString(), it.dayOfMonth.toString(), it.lastPaidMonthKey.toString()) }
        d.goals.forEach { line("GOAL", it.id, it.title, it.targetRial.toString(), it.savedRial.toString(), it.deadlineMonthKey.toString()) }
        d.debts.forEach { line("DEBT", it.id, it.person, it.amountRial.toString(), if (it.iOwe) "1" else "0", it.dueKey.toString(), if (it.settled) "1" else "0") }
        return sb.toString()
    }

    /** Malformed lines are skipped and counted in [PlanData.badLines]; nothing ever throws. */
    fun decode(text: String): PlanData {
        val bills = ArrayList<Bill>(); val goals = ArrayList<Goal>(); val debts = ArrayList<Debt>(); var bad = 0
        for (raw in text.replace("\r\n", "\n").split('\n')) {
            if (raw.isEmpty()) continue
            val f = raw.split('\t').map { BackupCodec.unesc(it) }
            if (f.any { it == null }) { bad++; continue }
            val p = f.map { it!! }
            try {
                when {
                    p[0] == "BILL" && p.size == 6 && p[1].isNotBlank() ->
                        bills.add(Bill(p[1], p[2], p[3].toLong(), p[4].toInt().also { require(it in 1..31) }, p[5].toInt()))
                    p[0] == "GOAL" && p.size == 6 && p[1].isNotBlank() ->
                        goals.add(Goal(p[1], p[2], p[3].toLong(), p[4].toLong(), p[5].toInt()))
                    p[0] == "DEBT" && p.size == 7 && p[1].isNotBlank() ->
                        debts.add(Debt(p[1], p[2], p[3].toLong(), p[4] == "1", p[5].toInt(), p[6] == "1"))
                    else -> bad++
                }
            } catch (e: Exception) { bad++ }
        }
        return PlanData(bills, goals, debts, bad)
    }

    /** Merge for restore: items whose id already exists are kept as they are. */
    fun mergeMissing(current: PlanData, incoming: PlanData): PlanData = PlanData(
        current.bills + incoming.bills.filter { n -> current.bills.none { it.id == n.id } },
        current.goals + incoming.goals.filter { n -> current.goals.none { it.id == n.id } },
        current.debts + incoming.debts.filter { n -> current.debts.none { it.id == n.id } }
    )
}
