package ir.hesabyar.app

import android.content.Context

/** Small persistent flags for automatic SMS handling. */
object SmsSettings {
    private const val PREFS = "hesabyar_settings"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Automatic reading/recognition of bank SMS. On by default; the user can switch it off. */
    fun autoEnabled(c: Context) = p(c).getBoolean("auto_sms", true)
    fun setAutoEnabled(c: Context, v: Boolean) { p(c).edit().putBoolean("auto_sms", v).apply() }

    fun lastScan(c: Context) = p(c).getLong("last_scan", 0L)
    fun setLastScan(c: Context, v: Long) { p(c).edit().putLong("last_scan", v).apply() }

    fun permissionAsked(c: Context) = p(c).getBoolean("perm_asked", false)
    fun setPermissionAsked(c: Context) { p(c).edit().putBoolean("perm_asked", true).apply() }

    fun reprocessedVersion(c: Context) = p(c).getInt("reprocessed_version", 0)
    fun setReprocessedVersion(c: Context, v: Int) { p(c).edit().putInt("reprocessed_version", v).apply() }

    // ---- diagnostics: when did automatic reading last work? ----
    fun lastLive(c: Context) = p(c).getLong("diag_live", 0L)
    fun markLive(c: Context) { p(c).edit().putLong("diag_live", System.currentTimeMillis()).apply() }
    fun lastLiveError(c: Context): String = p(c).getString("diag_live_err", "") ?: ""
    fun setLiveError(c: Context, e: String) { p(c).edit().putString("diag_live_err", e.take(120)).apply() }
    fun lastBackground(c: Context) = p(c).getLong("diag_bg", 0L)
    fun markBackground(c: Context) { p(c).edit().putLong("diag_bg", System.currentTimeMillis()).apply() }
}
