package ir.hesabyar.app

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

/** First-run introduction (also reachable later from Settings → quick guide). */
class WelcomeActivity : Activity() {
    companion object {
        private const val PREFS = "hesabyar_settings"
        fun done(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("welcome_done", false)
        fun markDone(c: Context) { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("welcome_done", true).apply() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val replay = intent.getBooleanExtra("replay", false)
        val root = Ui.page(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(Ui.text(this, "💜", 44f).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(context, 16), 0, 0) })
        content.addView(Ui.text(this, "به حساب‌یار خوش آمدی", 26f, Ui.ink, true).apply { gravity = Gravity.CENTER })
        content.addView(Ui.text(this, "دفتر مالی ساده و خصوصی، فقط روی گوشی خودت", 13f, Ui.muted).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(context, 4), 0, Ui.dp(context, 14)) })

        fun feature(emoji: String, title: String, body: String) {
            val card = Ui.glass(this, 14)
            card.orientation = LinearLayout.HORIZONTAL; card.gravity = Gravity.CENTER_VERTICAL
            card.addView(Ui.text(this, emoji, 28f).apply { setPadding(0, 0, Ui.dp(context, 12), 0) })
            val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            t.addView(Ui.text(this, title, 15f, Ui.ink, true))
            t.addView(Ui.text(this, body, 12f, Ui.muted).apply { setPadding(0, Ui.dp(context, 2), 0, 0) })
            card.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            content.addView(card, Ui.margins(this, 0, 8))
        }
        feature("✉️", "ثبت خودکار از پیامک بانک", "پیامک‌های بانکی تشخیص داده می‌شوند و فقط کافی است دسته را انتخاب کنی.")
        feature("🧩", "ویجت روی صفحهٔ اصلی", "بودجهٔ امروز، موارد فوری و ثبت سریع همیشه جلوی چشمت؛ ظاهرش را خودت طراحی کن.")
        feature("🎯", "بودجه، قبض، هدف و بدهی", "هشدار قبل از رسیدن به سقف بودجه و یادآوری سررسیدها.")
        feature("🔒", "کاملاً خصوصی", "برنامه مجوز اینترنت ندارد؛ هیچ اطلاعاتی از گوشی بیرون نمی‌رود.")
        feature("🌗", "روشن و تیره", "از تنظیمات می‌توانی ظاهر برنامه را انتخاب کنی.")

        content.addView(Ui.primary(this, if (replay) "بستن" else "شروع کنیم") {
            markDone(this); finish()
        }, Ui.margins(this, 10, 20))
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)
    }

    override fun onBackPressed() { markDone(this); super.onBackPressed() }
}
