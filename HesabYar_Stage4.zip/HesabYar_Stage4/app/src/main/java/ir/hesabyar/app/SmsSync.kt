package ir.hesabyar.app

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.provider.Telephony

/**
 * Background safety net for automatic SMS reading:
 *  - a job that fires when the phone's SMS database changes (even if the app is closed);
 *  - a periodic job (about every 15 minutes, survives restarts).
 * Both import missed bank SMS and refresh the widgets. No SMS content leaves the phone.
 */
object SmsSync {
    private const val CONTENT_JOB = 7101
    private const val PERIODIC_JOB = 7102

    fun schedule(context: Context) {
        val app = context.applicationContext
        val js = app.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (!SmsSettings.autoEnabled(app) || !SmsCatchUp.hasReadPermission(app)) {
            js.cancel(CONTENT_JOB); js.cancel(PERIODIC_JOB); return
        }
        val comp = ComponentName(app, SmsSyncJobService::class.java)
        // Content-trigger jobs are one-shot: schedule again after every run (replaces the previous one).
        js.schedule(JobInfo.Builder(CONTENT_JOB, comp)
            .addTriggerContentUri(JobInfo.TriggerContentUri(Telephony.Sms.CONTENT_URI, JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS))
            .setTriggerContentUpdateDelay(800).setTriggerContentMaxDelay(8_000).build())
        if (js.getPendingJob(PERIODIC_JOB) == null) {
            js.schedule(JobInfo.Builder(PERIODIC_JOB, comp).setPeriodic(15L * 60 * 1000).setPersisted(true).build())
        }
    }
}

class SmsSyncJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val app = applicationContext
        Thread {
            try {
                SmsCatchUp.run(app)           // imports anything missed and refreshes widgets
                SmsSettings.markBackground(app)
                Notifier.check(app)
            } catch (_: Exception) {
            } finally {
                try { SmsSync.schedule(app) } catch (_: Exception) {}
                jobFinished(params, false)
            }
        }.start()
        return true
    }
    override fun onStopJob(params: JobParameters): Boolean = true
}
