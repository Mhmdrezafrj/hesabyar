package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import ir.hesabyar.app.ui.Palette
import ir.hesabyar.app.ui.Palettes

/** User choice of look: follow system / light / dark. */
object ThemeSettings {
    private const val PREFS = "hesabyar_settings"
    private const val KEY = "theme_mode"
    fun get(c: Context): Int = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, Palettes.SYSTEM)
    fun set(c: Context, mode: Int) { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, mode).apply() }
    fun label(mode: Int) = when (mode) { Palettes.LIGHT -> "روشن"; Palettes.DARK -> "تیره"; else -> "مطابق سیستم" }
    fun next(mode: Int) = when (mode) { Palettes.SYSTEM -> Palettes.LIGHT; Palettes.LIGHT -> Palettes.DARK; else -> Palettes.SYSTEM }
    fun systemDark(c: Context) = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    fun resolve(c: Context): Palette = Palettes.resolve(get(c), systemDark(c))
}

/** Shared look of the app screens. Colours come from the current [Palette] (light or dark). */
object Ui {
    /** Current palette; refreshed by [refresh] (called by [page]). */
    var p: Palette = Palettes.light
        private set

    val ink get() = p.ink
    val muted get() = p.muted
    val green get() = p.green
    val red get() = p.red
    val amber get() = p.amber
    val purple get() = p.accent
    val blue get() = p.accent2

    fun refresh(c: Context) { p = ThemeSettings.resolve(c) }

    /** Alert dialog in the current look (rounded, app font, dark/light). */
    fun dialog(c: Context): AlertDialog.Builder {
        refresh(c)
        return AlertDialog.Builder(c, if (p.dark) R.style.HyDialogDark else R.style.HyDialogLight)
    }

    private fun systemBars(a: Activity) {
        val w = a.window
        @Suppress("DEPRECATION")
        run { w.statusBarColor = p.bgTop; w.navigationBarColor = p.bgBottom }
        if (Build.VERSION.SDK_INT >= 30) {
            val flags = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            w.insetsController?.setSystemBarsAppearance(if (p.dark) 0 else flags, flags)
        } else {
            @Suppress("DEPRECATION")
            run {
                var v = w.decorView.systemUiVisibility
                v = if (p.dark) v and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else v or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                w.decorView.systemUiVisibility = v
            }
        }
    }

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(radiusPx: Float, color: Int, strokeColor: Int? = null, strokePx: Int = 0) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE; cornerRadius = radiusPx; setColor(color)
        if (strokeColor != null) setStroke(strokePx, strokeColor)
    }

    /** Screen background gradient of the current palette. */
    fun pastelGradient() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(p.bgTop, p.bgMid, p.bgBottom))

    /** Page root: vertical, RTL, gradient background, system-bar insets handled. */
    fun page(a: Activity): LinearLayout = LinearLayout(a).apply {
        refresh(a); systemBars(a)
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(a, 16), dp(a, 20), dp(a, 16), dp(a, 12))
        background = pastelGradient()
    }

    /** Translucent white "glass" card. */
    fun glass(c: Context, pad: Int = 14): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(c, pad), dp(c, pad - 2), dp(c, pad), dp(c, pad - 2))
        background = rounded(dp(c, 20).toFloat(), p.card, p.cardStroke, dp(c, 1))
        elevation = if (p.dark) 0f else dp(c, 2).toFloat()
    }

    fun margins(c: Context, top: Int = 0, bottom: Int = 10) =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, top); bottomMargin = dp(c, bottom) }

    fun text(c: Context, t: String, size: Float = 14f, color: Int = p.ink, bold: Boolean = false) = TextView(c).apply {
        text = t; textSize = size; setTextColor(color)
        typeface = Fonts.app(c, bold)
    }

    fun title(c: Context, t: String, sub: String? = null): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        addView(text(c, t, 26f, ink, true))
        if (sub != null) addView(text(c, sub, 13f, muted).apply { setPadding(0, dp(c, 4), 0, dp(c, 10)) })
    }

    private fun styleButton(b: Button, bg: GradientDrawable, textColor: Int, bold: Boolean = false) {
        val c = b.context
        b.background = bg; b.setTextColor(textColor); b.isAllCaps = false
        b.typeface = Fonts.app(c, bold)
        b.stateListAnimator = null; b.elevation = 0f
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10))
        b.minHeight = dp(c, 44); b.minimumHeight = dp(c, 44)
    }

    /** Main action: purple -> blue gradient pill. */
    fun primary(c: Context, label: String, onClick: () -> Unit) = Button(c).apply {
        text = label; setTypeface(null, Typeface.BOLD)
        styleButton(this, GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(purple, blue)).apply { cornerRadius = dp(c, 24).toFloat() }, p.onAccent, true)
        setOnClickListener { onClick() }
    }

    /** Secondary action: soft translucent pill. */
    fun soft(c: Context, label: String, onClick: () -> Unit) = Button(c).apply {
        text = label
        styleButton(this, rounded(dp(c, 24).toFloat(), p.soft, p.softStroke, dp(c, 1)), ink)
        setOnClickListener { onClick() }
    }

    /** Square-ish home tile with emoji + caption. */
    fun tile(c: Context, emoji: String, label: String, tint: Int, onClick: () -> Unit): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(c, 8), dp(c, 14), dp(c, 8), dp(c, 12))
        background = rounded(dp(c, 22).toFloat(), tint, p.cardStroke, dp(c, 1))
        elevation = if (p.dark) 0f else dp(c, 2).toFloat()
        addView(text(c, emoji, 28f).apply { gravity = Gravity.CENTER })
        addView(text(c, label, 13f, ink, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(c, 6), 0, 0) })
        isClickable = true; isFocusable = true
        setOnClickListener { onClick() }
    }

    /** Small rounded "chip" label (e.g. date badge). */
    fun chip(c: Context, t: String, color: Int = p.accent): TextView = TextView(c).apply {
        text = t; textSize = 12f; setTextColor(color); setTypeface(null, Typeface.BOLD)
        setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4))
        background = rounded(dp(c, 14).toFloat(), Color.argb(40, Color.red(color), Color.green(color), Color.blue(color)))
    }

    fun dot(c: Context, color: Int): View = View(c).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
        layoutParams = LinearLayout.LayoutParams(dp(c, 10), dp(c, 10)).apply { marginStart = dp(c, 8) }
    }

    /** Friendly empty-state card: emoji, title and a hint on what to do. */
    fun empty(c: Context, emoji: String, title: String, hint: String): LinearLayout = glass(c, 20).apply {
        gravity = Gravity.CENTER
        addView(text(c, emoji, 40f).apply { gravity = Gravity.CENTER })
        addView(text(c, title, 16f, p.ink, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(c, 8), 0, dp(c, 4)) })
        addView(text(c, hint, 12f, p.muted).apply { gravity = Gravity.CENTER })
    }
}
