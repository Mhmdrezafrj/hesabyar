package ir.hesabyar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.plan.BudgetPlanner
import ir.hesabyar.app.plan.Jx
import ir.hesabyar.app.report.ReportCalculator

/** Small home-screen widget: how much can be spent per day for the rest of the month (from the user's budgets). */
class BudgetWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { safeUpdate(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            try {
                val m = AppWidgetManager.getInstance(context)
                m.getAppWidgetIds(ComponentName(context, BudgetWidget::class.java)).forEach { safeUpdate(context, m, it) }
            } catch (_: Exception) { }
        }

        private fun safeUpdate(context: Context, m: AppWidgetManager, id: Int) {
            try {
                val now = System.currentTimeMillis()
                val summary = ReportCalculator(now).summary(TransactionStore.all(context))
                val plan = BudgetPlanner.plan(Jx.dayOf(now), BudgetStore.all(context), summary.monthExpenseByCategory, summary.monthExpenseRial)
                val unit = DisplaySettings.get(context)
                val v = RemoteViews(context.packageName, R.layout.widget_budget)
                if (!plan.hasBudget) {
                    v.setTextViewText(R.id.bw_value, "بودجه تنظیم نشده")
                    v.setTextViewText(R.id.bw_sub, "در گزارش، برای یک دسته بودجه بگذار")
                } else if (plan.remainingRial <= 0) {
                    v.setTextViewText(R.id.bw_value, "بودجه تمام شد")
                    v.setTextViewText(R.id.bw_sub, AmountFormatter.toPersianDigits("${plan.daysLeft} روز تا آخر ماه"))
                } else {
                    v.setTextViewText(R.id.bw_value, AmountFormatter.format(plan.dailyAllowanceRial, Currency.RIAL, unit))
                    v.setTextViewText(R.id.bw_sub, AmountFormatter.toPersianDigits("برای هر روز • ${plan.daysLeft} روز مانده"))
                }
                val open = PendingIntent.getActivity(context, 9100, Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                v.setOnClickPendingIntent(R.id.bw_root, open)
                m.updateAppWidget(id, v)
            } catch (_: Exception) { }
        }
    }
}
