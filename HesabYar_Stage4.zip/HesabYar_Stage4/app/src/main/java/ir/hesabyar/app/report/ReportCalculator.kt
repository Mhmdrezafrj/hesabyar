package ir.hesabyar.app.report

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.money.Money
import ir.hesabyar.app.widget.Categories
import ir.hesabyar.app.widget.JalaliCalendar
import java.util.Calendar
import java.util.TimeZone

enum class RangePreset { TODAY, LAST_7_DAYS, THIS_MONTH, LAST_MONTH, ALL }
enum class TypeFilter { ALL, INCOME, EXPENSE }

data class ReportFilter(
    val range: RangePreset = RangePreset.THIS_MONTH,
    val type: TypeFilter = TypeFilter.ALL,
    /** null = all categories; [Categories.UNCATEGORIZED_LABEL] = only uncategorised */
    val category: String? = null
)

data class CategoryTotal(val category: String, val totalRial: Long)

data class Totals(val expenseRial: Long, val incomeRial: Long)

data class Summary(
    val todayExpenseRial: Long,
    val monthExpenseRial: Long,
    val monthIncomeRial: Long,
    val prevMonthExpenseRial: Long,
    val prevMonthIncomeRial: Long,
    val monthExpenseByCategory: List<CategoryTotal>
)

/**
 * All report maths, pure and unit-tested.
 *  - Months/days are Jalali. Dates come from Transaction.timestamp (SMS receive time / manual entry time).
 *    Old rows without a timestamp (0) can only appear in the "ALL" range, never in dated sums.
 *  - Transfers between the user's own accounts (category = Categories.TRANSFER) are never counted.
 *  - Amounts are normalised to Rial for adding; the display layer converts to the chosen unit.
 */
class ReportCalculator(private val now: Long, private val zone: TimeZone = TimeZone.getDefault()) {

    private fun dayOf(ts: Long): JalaliCalendar.Date {
        val c = Calendar.getInstance(zone); c.timeInMillis = ts
        return JalaliCalendar.fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }
    private fun monthKey(d: JalaliCalendar.Date) = d.year * 12 + (d.month - 1)

    private val today = dayOf(now)
    private val thisMonth = monthKey(today)

    private fun counted(t: Transaction) = t.category != Categories.TRANSFER
    private fun rial(t: Transaction) = Money.toRial(t.amount, t.currencyType)
    fun categoryLabel(t: Transaction) = if (t.category.isBlank()) Categories.UNCATEGORIZED_LABEL else t.category

    fun totals(list: List<Transaction>): Totals {
        var e = 0L; var i = 0L
        list.filter { counted(it) }.forEach { if (it.isIncome) i += rial(it) else e += rial(it) }
        return Totals(e, i)
    }

    private fun dated(all: List<Transaction>) = all.filter { it.timestamp > 0 }

    private fun inMonth(all: List<Transaction>, key: Int) = dated(all).filter { monthKey(dayOf(it.timestamp)) == key }

    fun summary(all: List<Transaction>): Summary {
        val todayList = dated(all).filter { dayOf(it.timestamp) == today }
        val month = inMonth(all, thisMonth)
        val prev = inMonth(all, thisMonth - 1)
        val byCat = month.filter { counted(it) && !it.isIncome }
            .groupBy { categoryLabel(it) }
            .map { (k, v) -> CategoryTotal(k, v.sumOf { rial(it) }) }
            .sortedByDescending { it.totalRial }
        return Summary(
            todayExpenseRial = totals(todayList).expenseRial,
            monthExpenseRial = totals(month).expenseRial,
            monthIncomeRial = totals(month).incomeRial,
            prevMonthExpenseRial = totals(prev).expenseRial,
            prevMonthIncomeRial = totals(prev).incomeRial,
            monthExpenseByCategory = byCat
        )
    }

    /** Transactions matching the filter, newest first. Transfers stay in the list (they are only excluded from totals). */
    fun filter(all: List<Transaction>, f: ReportFilter): List<Transaction> {
        val byRange = when (f.range) {
            RangePreset.ALL -> all
            RangePreset.TODAY -> dated(all).filter { dayOf(it.timestamp) == today }
            RangePreset.LAST_7_DAYS -> dated(all).filter { it.timestamp >= now - 7L * 86_400_000L }
            RangePreset.THIS_MONTH -> inMonth(all, thisMonth)
            RangePreset.LAST_MONTH -> inMonth(all, thisMonth - 1)
        }
        return byRange
            .filter { when (f.type) { TypeFilter.ALL -> true; TypeFilter.INCOME -> it.isIncome; TypeFilter.EXPENSE -> !it.isIncome } }
            .filter { f.category == null || categoryLabel(it) == f.category }
            .sortedByDescending { it.timestamp }
    }

    companion object {
        /** Percent change from [previous] to [current]; null when there is no previous value to compare with. */
        fun percentChange(current: Long, previous: Long): Int? =
            if (previous <= 0L) null else (((current - previous) * 100.0) / previous).let { Math.round(it).toInt() }
    }
}
