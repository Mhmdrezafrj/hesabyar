package ir.hesabyar.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.widget.RemoteViews
import ir.hesabyar.app.design.*
import ir.hesabyar.app.plan.UrgentTarget

/** Per-widget design (by appWidgetId) plus one default design, stored only on this phone. */
object DesignStore {
    private const val PREFS = "hesabyar_design"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun default(c: Context): DesignConfig = p(c).getString("default", null)?.let { DesignCodec.decode(it) } ?: Design.sanitize(Design.fromTheme(Themes.all[0]))
    fun saveDefault(c: Context, cfg: DesignConfig) { p(c).edit().putString("default", DesignCodec.encode(cfg)).apply() }
    fun get(c: Context, id: Int): DesignConfig = p(c).getString("w$id", null)?.let { DesignCodec.decode(it) } ?: default(c)
    fun save(c: Context, id: Int, cfg: DesignConfig) { p(c).edit().putString("w$id", DesignCodec.encode(cfg)).apply() }
    fun remove(c: Context, id: Int) { p(c).edit().remove("w$id").apply() }
}

/** The three composite widgets (small / wide / large). All content and look come from ComboRenderer + DesignConfig. */
abstract class ComboWidget(private val size: WidgetSize) : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it, size) }
    }
    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, id, newOptions)
        update(context, manager, id, size)
    }
    override fun onDeleted(context: Context, ids: IntArray) { ids.forEach { DesignStore.remove(context, it) } }

    companion object {
        private val kinds = listOf<Pair<Class<*>, WidgetSize>>(
            ComboSmallWidget::class.java to WidgetSize.SMALL, ComboWideWidget::class.java to WidgetSize.WIDE, ComboLargeWidget::class.java to WidgetSize.LARGE)
        const val MAX_PIXELS = 1_500_000

        fun existing(c: Context): List<Pair<Int, WidgetSize>> {
            val m = AppWidgetManager.getInstance(c)
            return kinds.flatMap { (cls, s) -> m.getAppWidgetIds(ComponentName(c, cls)).map { it to s } }
        }

        fun updateAll(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                existing(c).forEach { (id, s) -> try { update(c, m, id, s) } catch (e: Throwable) { try { CrashLog.record(c, e) } catch (_: Throwable) { } } }
            } catch (_: Throwable) { }
        }

        fun sizeOf(c: Context, id: Int): WidgetSize? {
            val name = AppWidgetManager.getInstance(c).getAppWidgetInfo(id)?.provider?.className ?: return null
            return when { name.endsWith("ComboSmallWidget") -> WidgetSize.SMALL; name.endsWith("ComboWideWidget") -> WidgetSize.WIDE; name.endsWith("ComboLargeWidget") -> WidgetSize.LARGE; else -> null }
        }

        private fun screen(c: Context, code: Int, cls: Class<*>, extra: Intent.() -> Unit = {}): PendingIntent =
            PendingIntent.getActivity(c, code, Intent(c, cls).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; extra() },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        fun update(c: Context, m: AppWidgetManager, id: Int, size: WidgetSize) {
            try {
                val o = m.getAppWidgetOptions(id)
                val portrait = c.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
                var wDp = o.getInt(if (portrait) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0)
                var hDp = o.getInt(if (portrait) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0)
                if (wDp <= 0) wDp = when (size) { WidgetSize.SMALL -> 150; else -> 310 }
                if (hDp <= 0) hDp = when (size) { WidgetSize.LARGE -> 310; else -> 150 }
                val density = c.resources.displayMetrics.density
                var scale = 1f
                if (wDp * density * hDp * density > MAX_PIXELS) scale = Math.sqrt(MAX_PIXELS / (wDp * density * hDp * density).toDouble()).toFloat()
                val wPx = (wDp * density * scale).toInt().coerceAtLeast(40); val hPx = (hDp * density * scale).toInt().coerceAtLeast(40)

                val data = ComboData(c)
                val cfg = Design.sanitize(DesignStore.get(c, id))
                val v = RemoteViews(c.packageName, R.layout.widget_combo)
                v.setImageViewBitmap(R.id.w_img, ComboRenderer.render(cfg, size, wPx, hPx, density * scale, data))

                val cells = Grid.cells(size, Design.effectiveExtras(cfg, data.snap.dayIndex, Grid.extraCount(size)), cfg.mirror)
                cells.forEach { cell ->
                    Grid.covered(cell).forEach { (col, row) ->
                        val code = id * 64 + row * 4 + col
                        val pi = when (cell.block) {
                            BlockType.ALLOWANCE, BlockType.NUDGE, BlockType.ACCOUNTS -> screen(c, code, MainActivity::class.java)
                            BlockType.URGENT -> screen(c, code, if (data.urgent.target == UrgentTarget.PLAN) PlanActivity::class.java else MainActivity::class.java)
                            BlockType.QUICK_ADD -> screen(c, code, MainActivity::class.java) { action = "ADD_TRANSACTION"; putExtra("income", col < 2) }
                            BlockType.STREAK, BlockType.WEEK_STRIP -> screen(c, code, MainActivity::class.java) { action = "ADD_TRANSACTION" }
                            BlockType.RING, BlockType.WEEK_BARS -> screen(c, code, ReportsActivity::class.java)
                            BlockType.GOAL, BlockType.DUES -> screen(c, code, PlanActivity::class.java)
                            BlockType.NOTE -> screen(c, code, NoteActivity::class.java)
                        }
                        v.setOnClickPendingIntent(OverlayIds.at(col, row), pi)
                    }
                }
                m.updateAppWidget(id, v)
            } catch (_: Exception) { /* keep the previous picture rather than crash the launcher */ }
        }
    }
}

class ComboSmallWidget : ComboWidget(WidgetSize.SMALL)
class ComboWideWidget : ComboWidget(WidgetSize.WIDE)
class ComboLargeWidget : ComboWidget(WidgetSize.LARGE)
