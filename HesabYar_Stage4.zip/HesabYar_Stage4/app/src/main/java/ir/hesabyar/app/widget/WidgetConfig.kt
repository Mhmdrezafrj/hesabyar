package ir.hesabyar.app.widget

/** User customisation of the home-screen widget. Always pass through [sanitized] after loading. */
data class WidgetConfig(
    val count: Int = 3,              // 3, 5 or 7 rows
    val titleFont: Int = 1,          // 0 small, 1 medium, 2 large
    val amountFont: Int = 1,
    val metaFont: Int = 1,           // time / description
    val opacityPercent: Int = 85,    // background opacity 30..100
    val style: Int = 0,              // 0 dark glass, 1 purple-blue
    val showWallet: Boolean = true,
    val showDate: Boolean = true,
    val showBalance: Boolean = true
) {
    fun sanitized() = copy(
        count = if (count in COUNTS) count else 3,
        titleFont = titleFont.coerceIn(0, 2),
        amountFont = amountFont.coerceIn(0, 2),
        metaFont = metaFont.coerceIn(0, 2),
        opacityPercent = opacityPercent.coerceIn(30, 100),
        style = style.coerceIn(0, 1)
    )

    companion object {
        val COUNTS = listOf(3, 5, 7)
        fun fontScale(level: Int): Float = when (level) { 0 -> 0.86f; 2 -> 1.18f; else -> 1f }
    }
}

object WidgetLayoutMath {
    private const val ROW_DP = 46
    private const val BASE_DP = 96          // title row + footer + padding
    private const val BALANCE_DP = 34

    /** How many rows fit in [heightDp] (0 = unknown -> use the wanted count). Always at least 1. */
    fun rowsThatFit(heightDp: Int, wanted: Int, showBalance: Boolean): Int {
        if (heightDp <= 0) return wanted
        val free = heightDp - BASE_DP - (if (showBalance) BALANCE_DP else 0)
        return (free / ROW_DP).coerceIn(1, wanted)
    }
}

/** Quick-categorise list shared by the app and the widget dialog. */
object Categories {
    val defaults = listOf("خوراک", "خرید", "حمل‌ونقل", "مسکن", "درآمد کاری", "قبوض", "سلامت", "سایر")
}
