package ir.hesabyar.app

import android.content.Context
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.plan.*
import ir.hesabyar.app.report.BudgetCalc
import ir.hesabyar.app.report.BudgetLevel
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.widget.PendingQueue
import java.util.TimeZone

/** Everything the composite widgets can show, computed once per refresh from the local data. */
class WidgetSnapshot(c: Context) {
    val now = System.currentTimeMillis()
    val zone: TimeZone = TimeZone.getDefault()
    val all = TransactionStore.all(c)
    val summary = ReportCalculator(now).summary(all)
    val today = Jx.dayOf(now)
    val limits = BudgetStore.all(c)
    val plan = BudgetPlanner.plan(today, limits, summary.monthExpenseByCategory, summary.monthExpenseRial)
    val streak = Streak.compute(all.map { it.timestamp }, now, zone)
    val week = WeekMath.last7(all, now, zone)
    val dayIndex = Streak.dayIndex(now, zone)
}

class ComboData(val ctx: Context) {
    val snap = WidgetSnapshot(ctx)
    private val unit = DisplaySettings.get(ctx)
    val light = TrafficLight.of(snap.plan)
    val pendingCount = PendingQueue.pending(snap.all).size
    private val planData = PlanStore.load(ctx)

    fun money(rial: Long) = AmountFormatter.format(rial, Currency.RIAL, unit)
    fun fa(s: String) = AmountFormatter.toPersianDigits(s)

    val urgent: Urgent = run {
        val over = BudgetCalc.statuses(snap.summary.monthExpenseByCategory, snap.limits).filter { it.level == BudgetLevel.OVER }.map { it.category }
        UrgentPicker.pick(planData.bills, planData.debts, snap.today, pendingCount, over, { fa(it) }, { money(it) })
    }

    val goal: Goal? = planData.goals.filter { !GoalCalc.done(it) }.maxByOrNull { GoalCalc.percent(it) }
    val goalNeedPerMonth: Long? = goal?.let { GoalCalc.monthlyNeeded(it, Jx.monthKey(snap.today)) }

    val duesLines: List<String> = run {
        val todayKey = Jx.dateKey(snap.today)
        val l = ArrayList<String>()
        BillCalc.upcoming(planData.bills, snap.today, 10).forEach { d ->
            l.add("${d.bill.title} • " + when { d.overdue -> "عقب‌افتاده"; d.daysUntil == 0 -> "امروز"; else -> fa("${d.daysUntil} روز") })
        }
        DebtCalc.dueSoon(planData.debts, todayKey, todayKey + 7).forEach { d ->
            l.add((if (d.iOwe) "بدهی به " else "طلب از ") + d.person)
        }
        l
    }

    private val balances = AccountsOverview.balances(snap.all)
    val accountsTotal = AccountsOverview.total(balances)
    val accountsCount = balances.size

    val note: String = NoteStore.text(ctx)
    val noteAgeDays: Int = if (note.isBlank() || NoteStore.savedAt(ctx) == 0L) 0 else ((snap.now - NoteStore.savedAt(ctx)) / 86_400_000L).toInt()

    val nudge: String = run {
        val facts = NudgeFacts(snap.streak.loggedToday, snap.streak.days, pendingCount, snap.week.expenseRial[5], snap.plan.dailyAllowanceRial)
        Nudges.pick(Nudges.candidates(facts, { fa(it) }, { money(it) }), snap.dayIndex)
    }
}
