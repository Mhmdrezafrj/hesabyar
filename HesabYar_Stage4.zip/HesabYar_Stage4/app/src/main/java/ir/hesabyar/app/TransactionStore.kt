package ir.hesabyar.app

import android.content.Context
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.widget.PendingQueue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object TransactionStore {
    private const val PREFS = "hesabyar_local"
    private const val KEY = "transactions"

    fun all(context: Context): MutableList<Transaction> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw == null) return mutableListOf()
        val result = mutableListOf<Transaction>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(Transaction(
                id = o.getString("id"),
                title = o.getString("title"),
                bank = o.getString("bank"),
                amount = o.getLong("amount"),
                time = o.getString("time"),
                isIncome = o.getBoolean("income"),
                category = o.optString("category", ""),
                // Old rows have no currency: they were entered in Toman. Same number, no conversion.
                currency = Currency.fromCode(o.optString("currency", "")).code,
                source = o.optString("source", "MANUAL"),
                sourceRef = o.optString("sourceRef", ""),
                balance = if (o.has("balance") && !o.isNull("balance")) o.getLong("balance") else null,
                accountId = o.optString("accountId", ""),
                timestamp = o.optLong("ts", 0L)
            ))
        }
        // One-time clean-up: the three fake demo rows shipped in older versions are removed.
        val demoIds = setOf("sample-1", "sample-2", "sample-3")
        if (result.any { it.id in demoIds }) {
            val cleaned = result.filterNot { it.id in demoIds }.toMutableList()
            save(context, cleaned)
            return cleaned
        }
        return result
    }

    /** Uncategorised transactions, newest first. */
    fun pending(context: Context) = PendingQueue.pending(all(context))

    fun save(context: Context, transactions: List<Transaction>) {
        val array = JSONArray()
        transactions.forEach { t ->
            array.put(JSONObject().apply {
                put("id", t.id); put("title", t.title); put("bank", t.bank)
                put("amount", t.amount); put("time", t.time)
                put("income", t.isIncome); put("category", t.category)
                put("currency", t.currency); put("source", t.source)
                put("sourceRef", t.sourceRef); put("accountId", t.accountId)
                put("ts", t.timestamp)
                t.balance?.let { put("balance", it) }
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    /** Manual entry. [amount] is stored exactly as typed, in [currency]; no conversion. */
    @Synchronized
    fun add(context: Context, title: String, amount: Long, income: Boolean, currency: Currency = Currency.TOMAN) {
        val items = all(context)
        items.add(0, Transaction(
            id = UUID.randomUUID().toString(),
            title = title.ifBlank { "تراکنش دستی" },
            bank = "ثبت دستی",
            amount = amount,
            time = "همین الان",
            isIncome = income,
            currency = currency.code,
            source = "MANUAL",
            timestamp = System.currentTimeMillis()
        ))
        save(context, items)
    }

    /** Adds a transaction parsed from an SMS unless one with the same [Transaction.sourceRef] exists. */
    @Synchronized
    fun addFromSms(context: Context, tx: Transaction): Boolean {
        val items = all(context)
        if (tx.sourceRef.isNotBlank() && items.any { it.sourceRef == tx.sourceRef }) return false
        items.add(0, tx)
        save(context, items)
        return true
    }

    /** Renames a category on every transaction that uses it (used when a category is renamed/deleted). */
    @Synchronized
    fun renameCategory(context: Context, old: String, new: String) {
        val items = all(context)
        if (items.none { it.category == old }) return
        save(context, items.map { if (it.category == old) it.copy(category = new) else it })
    }

    @Synchronized
    fun categorize(context: Context, id: String, category: String) {
        val items = all(context).map {
            if (it.id == id) it.copy(category = category) else it
        }
        save(context, items)
    }
}
