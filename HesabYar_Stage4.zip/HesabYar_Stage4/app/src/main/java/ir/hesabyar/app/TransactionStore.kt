package ir.hesabyar.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import ir.hesabyar.app.money.Currency
import org.json.JSONArray
import java.util.UUID

/**
 * Transactions live in a local SQLite database (hesabyar_tx.db): every add / categorise / edit / delete
 * touches ONE row, instead of rewriting the whole list as before. Nothing leaves the phone.
 * On first launch of this version the old JSON list is imported once (then kept as a backup string
 * until "delete all data").
 */
private class TxDb(context: Context) : SQLiteOpenHelper(context, "hesabyar_tx.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tx (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, bank TEXT NOT NULL, amount INTEGER NOT NULL,
            time TEXT NOT NULL, income INTEGER NOT NULL, category TEXT NOT NULL DEFAULT '',
            currency TEXT NOT NULL, source TEXT NOT NULL, source_ref TEXT NOT NULL DEFAULT '',
            balance INTEGER, account_id TEXT NOT NULL DEFAULT '', ts INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("CREATE INDEX idx_tx_ts ON tx(ts DESC)")
        db.execSQL("CREATE INDEX idx_tx_ref ON tx(source_ref)")
        db.execSQL("CREATE TABLE deleted_refs (ref TEXT PRIMARY KEY)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

object TransactionStore {
    private const val PREFS = "hesabyar_local"
    private const val KEY = "transactions"
    private const val DB_NAME = "hesabyar_tx.db"
    private const val ORDER = "ts DESC, rowid DESC"
    private val COLS = arrayOf("id", "title", "bank", "amount", "time", "income", "category",
        "currency", "source", "source_ref", "balance", "account_id", "ts")

    private var helper: TxDb? = null

    @Synchronized
    private fun db(context: Context): SQLiteDatabase {
        val app = context.applicationContext
        val h = helper ?: TxDb(app).also { helper = it }
        val database = h.writableDatabase
        migrateLegacy(app, database)
        return database
    }

    // ---------- one-time import of the old JSON storage ----------
    private var migrationChecked = false

    private fun migrateLegacy(context: Context, db: SQLiteDatabase) {
        if (migrationChecked) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("tx_migrated_v1", false)) {
            val raw = prefs.getString(KEY, null)
            if (raw != null) {
                try {
                    val demoIds = setOf("sample-1", "sample-2", "sample-3")   // fake demo rows of very old versions
                    val items = parseLegacy(raw).filterNot { it.id in demoIds }
                    db.beginTransaction()
                    try {
                        items.forEach { put(db, it) }
                        legacyDeletedRefs(prefs.getString("deleted_refs", null)).forEach { ref ->
                            db.execSQL("INSERT OR IGNORE INTO deleted_refs(ref) VALUES ('" + ref.replace("'", "''") + "')")
                        }
                        db.setTransactionSuccessful()
                    } finally { db.endTransaction() }
                    prefs.edit().putString("transactions_pre_sqlite_backup", raw).apply()
                } catch (e: Exception) {
                    // Damaged old data must never crash the app and is never destroyed: keep the raw text.
                    prefs.edit().putString("transactions_corrupt_backup", raw).apply()
                }
            }
            prefs.edit().putBoolean("tx_migrated_v1", true).commit()
        }
        migrationChecked = true
    }

    private fun parseLegacy(raw: String): List<Transaction> {
        val result = mutableListOf<Transaction>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(Transaction(
                id = o.getString("id"), title = o.getString("title"), bank = o.getString("bank"),
                amount = o.getLong("amount"), time = o.getString("time"), isIncome = o.getBoolean("income"),
                category = o.optString("category", ""),
                // Old rows have no currency: they were entered in Toman. Same number, no conversion.
                currency = Currency.fromCode(o.optString("currency", "")).code,
                source = o.optString("source", "MANUAL"), sourceRef = o.optString("sourceRef", ""),
                balance = if (o.has("balance") && !o.isNull("balance")) o.getLong("balance") else null,
                accountId = o.optString("accountId", ""), timestamp = o.optLong("ts", 0L)
            ))
        }
        return result
    }

    private fun legacyDeletedRefs(raw: String?): List<String> {
        if (raw == null) return emptyList()
        return try { val a = JSONArray(raw); (0 until a.length()).map { a.getString(it) } } catch (e: Exception) { emptyList() }
    }

    // ---------- row mapping ----------
    private fun put(db: SQLiteDatabase, t: Transaction) {
        val v = ContentValues()
        v.put("id", t.id); v.put("title", t.title); v.put("bank", t.bank); v.put("amount", t.amount)
        v.put("time", t.time); v.put("income", if (t.isIncome) 1 else 0); v.put("category", t.category)
        v.put("currency", t.currency); v.put("source", t.source); v.put("source_ref", t.sourceRef)
        if (t.balance != null) v.put("balance", t.balance) else v.putNull("balance")
        v.put("account_id", t.accountId); v.put("ts", t.timestamp)
        db.insertWithOnConflict("tx", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun read(c: Cursor) = Transaction(
        id = c.getString(0), title = c.getString(1), bank = c.getString(2), amount = c.getLong(3),
        time = c.getString(4), isIncome = c.getInt(5) == 1, category = c.getString(6),
        currency = c.getString(7), source = c.getString(8), sourceRef = c.getString(9),
        balance = if (c.isNull(10)) null else c.getLong(10), accountId = c.getString(11), timestamp = c.getLong(12)
    )

    private fun query(context: Context, where: String?, args: Array<String>? = null): MutableList<Transaction> {
        val out = mutableListOf<Transaction>()
        db(context).query("tx", COLS, where, args, null, null, ORDER).use { c ->
            while (c.moveToNext()) out.add(read(c))
        }
        return out
    }

    // ---------- public API (same as before) ----------
    /** Every transaction, newest first. */
    @Synchronized
    fun all(context: Context): MutableList<Transaction> = query(context, null)

    /** Uncategorised transactions, newest first. */
    @Synchronized
    fun pending(context: Context): List<Transaction> = query(context, "TRIM(category) = ''")

    /** Replaces the whole list (kept for completeness; normal operations touch a single row). */
    @Synchronized
    fun save(context: Context, transactions: List<Transaction>) {
        val d = db(context)
        d.beginTransaction()
        try {
            d.delete("tx", null, null)
            transactions.forEach { put(d, it) }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }

    /** Manual entry. [amount] is stored exactly as typed, in [currency]; no conversion. */
    @Synchronized
    fun add(context: Context, title: String, amount: Long, income: Boolean, currency: Currency = Currency.TOMAN) {
        put(db(context), Transaction(
            id = UUID.randomUUID().toString(),
            title = title.ifBlank { "تراکنش دستی" },
            bank = "ثبت دستی", amount = amount, time = "همین الان", isIncome = income,
            currency = currency.code, source = "MANUAL", timestamp = System.currentTimeMillis()
        ))
    }

    /** Adds a transaction parsed from an SMS unless one with the same [Transaction.sourceRef] exists or was deleted by the user. */
    @Synchronized
    fun addFromSms(context: Context, tx: Transaction): Boolean {
        val d = db(context)
        if (tx.sourceRef.isNotBlank()) {
            if (exists(d, "SELECT 1 FROM tx WHERE source_ref = ? LIMIT 1", tx.sourceRef)) return false
            if (exists(d, "SELECT 1 FROM deleted_refs WHERE ref = ? LIMIT 1", tx.sourceRef)) return false
        }
        put(d, tx)
        return true
    }

    private fun exists(d: SQLiteDatabase, sql: String, arg: String): Boolean =
        d.rawQuery(sql, arrayOf(arg)).use { it.moveToFirst() }

    /** Renames a category on every transaction that uses it (used when a category is renamed/deleted). */
    @Synchronized
    fun renameCategory(context: Context, old: String, new: String) {
        val v = ContentValues(); v.put("category", new)
        db(context).update("tx", v, "category = ?", arrayOf(old))
    }

    /**
     * Deletes one transaction. For SMS transactions its duplicate key is remembered so the same SMS is NOT
     * re-created by the next automatic scan.
     */
    @Synchronized
    fun delete(context: Context, id: String) {
        val d = db(context)
        val ref = d.rawQuery("SELECT source_ref FROM tx WHERE id = ?", arrayOf(id)).use { c ->
            if (c.moveToFirst()) c.getString(0) else return
        }
        d.beginTransaction()
        try {
            if (ref.isNotBlank()) {
                val v = ContentValues(); v.put("ref", ref)
                d.insertWithOnConflict("deleted_refs", null, v, SQLiteDatabase.CONFLICT_IGNORE)
            }
            d.delete("tx", "id = ?", arrayOf(id))
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }

    @Synchronized
    fun categorize(context: Context, id: String, category: String) {
        val v = ContentValues(); v.put("category", category)
        db(context).update("tx", v, "id = ?", arrayOf(id))
    }

    /** Saves user edits of one transaction (title, amount, type, category). Keeps its SMS duplicate key. */
    @Synchronized
    fun update(context: Context, tx: Transaction) { put(db(context), tx) }

    /** Restores from a backup: adds only transactions whose id / SMS duplicate key is not already present. Returns how many were added. */
    @Synchronized
    fun importMissing(context: Context, items: List<Transaction>): Int {
        val d = db(context)
        var added = 0
        d.beginTransaction()
        try {
            for (t in items) {
                if (exists(d, "SELECT 1 FROM tx WHERE id = ? LIMIT 1", t.id)) continue
                if (t.sourceRef.isNotBlank() && exists(d, "SELECT 1 FROM tx WHERE source_ref = ? LIMIT 1", t.sourceRef)) continue
                put(d, t); added++
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        return added
    }

    /** Closes and deletes the database ("delete all data"). */
    @Synchronized
    fun wipe(context: Context) {
        helper?.close(); helper = null
        migrationChecked = false
        context.applicationContext.deleteDatabase(DB_NAME)
    }
}
