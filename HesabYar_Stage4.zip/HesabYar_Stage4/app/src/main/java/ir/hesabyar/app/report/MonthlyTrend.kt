package ir.hesabyar.app.report

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.widget.JalaliCalendar
import java.util.Calendar
import java.util.TimeZone

data class MonthBar(val year: Int, val month: Int, val expenseRial: Long, val incomeRial: Long) {
    val monthName: String get() = JalaliCalendar.monthNames[month - 1]
}

/** Expense/income per Jalali month for the last [count] months (oldest first, empty months = 0). Transfers excluded. */
object MonthlyTrend {
    fun last(all: List<Transaction>, count: Int, now: Long, zone: TimeZone = TimeZone.getDefault()): List<MonthBar> {
        fun keyOf(ts: Long): Int {
            val c = Calendar.getInstance(zone); c.timeInMillis = ts
            val j = JalaliCalendar.fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
            return j.year * 12 + (j.month - 1)
        }
        val current = keyOf(now)
        val byMonth = all.filter { it.timestamp > 0 }.groupBy { keyOf(it.timestamp) }
        return (count - 1 downTo 0).map { back ->
            val key = current - back
            val t = TotalsMath.totals(byMonth[key].orEmpty())
            MonthBar(key / 12, key % 12 + 1, t.expenseRial, t.incomeRial)
        }
    }
}
