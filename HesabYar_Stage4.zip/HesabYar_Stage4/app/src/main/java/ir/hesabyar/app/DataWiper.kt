package ir.hesabyar.app

import android.content.Context

/** Deletes the user's financial data from this phone. Nothing was ever sent elsewhere, so this is complete. */
object DataWiper {
    fun wipeAll(context: Context) {
        val app = context.applicationContext
        app.deleteDatabase("hesabyar_sms.db")
        TransactionStore.wipe(app)
        listOf("hesabyar_local", "hesabyar_categories", "hesabyar_budgets").forEach {
            app.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
        }
        // Do not silently re-import the old SMS right after wiping: start scanning from now on.
        SmsSettings.setLastScan(app, System.currentTimeMillis())
        SmsSettings.setReprocessedVersion(app, SmsCatchUp.PARSER_VERSION)
        PendingTransactionsWidget.updateAll(app)
    }
}
