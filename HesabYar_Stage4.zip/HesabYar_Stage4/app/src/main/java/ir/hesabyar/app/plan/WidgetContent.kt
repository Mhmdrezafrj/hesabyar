package ir.hesabyar.app.plan

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.money.Money
import ir.hesabyar.app.widget.Categories
import java.util.Calendar
import java.util.TimeZone

/** Pure content logic for the attention-oriented home-screen widgets (tested). */

// ---- logging streak ----
data class StreakInfo(val days: Int, val loggedToday: Boolean)

object Streak {
    fun dayIndex(ts: Long, zone: TimeZone): Long = (ts + zone.getOffset(ts)) / 86_400_000L

    /** Consecutive days with at least one transaction. The streak stays "alive" through yesterday even if today is still empty. */
    fun compute(timestamps: List<Long>, now: Long, zone: TimeZone = TimeZone.getDefault()): StreakInfo {
        val days = timestamps.filter { it > 0 && it <= now + 86_400_000L }.map { dayIndex(it, zone) }.toSet()
        val today = dayIndex(now, zone)
        val loggedToday = today in days
        var d = if (loggedToday) today else today - 1
        var n = 0
        while (d in days) { n++; d-- }
        return StreakInfo(n, loggedToday)
    }
}

// ---- last 7 days ----
data class WeekBars(val expenseRial: List<Long>, val weekdays: List<Int>)  // oldest -> today; weekdays = Calendar.DAY_OF_WEEK

object WeekMath {
    fun last7(all: List<Transaction>, now: Long, zone: TimeZone = TimeZone.getDefault()): WeekBars {
        val today = Streak.dayIndex(now, zone)
        val sums = LongArray(7)
        all.filter { !it.isIncome && it.timestamp > 0 && it.category != Categories.TRANSFER }.forEach {
            val back = (today - Streak.dayIndex(it.timestamp, zone)).toInt()
            if (back in 0..6) sums[6 - back] += Money.toRial(it.amount, it.currencyType)
        }
        val dows = (6 downTo 0).map { back ->
            val c = Calendar.getInstance(zone); c.timeInMillis = now - back * 86_400_000L; c.get(Calendar.DAY_OF_WEEK)
        }
        return WeekBars(sums.toList(), dows)
    }
}

// ---- traffic light for the daily allowance ----
enum class Light { NONE, GREEN, AMBER, RED }

object TrafficLight {
    fun of(p: SpendingPlan): Light = when {
        !p.hasBudget -> Light.NONE
        p.remainingRial <= 0 -> Light.RED
        p.projectedOverBudget -> Light.AMBER
        else -> Light.GREEN
    }
    fun percentUsed(p: SpendingPlan): Int = if (p.totalLimitRial <= 0) 0 else (p.spentInBudgetsRial * 100 / p.totalLimitRial).toInt().coerceIn(0, 100)
}

// ---- the one thing that needs attention now ----
enum class UrgentLevel { NONE, MEDIUM, HIGH }
enum class UrgentTarget { PLAN, MAIN }
data class Urgent(val level: UrgentLevel, val title: String, val detail: String, val target: UrgentTarget)

object UrgentPicker {
    fun pick(
        bills: List<Bill>, debts: List<Debt>, today: ir.hesabyar.app.widget.JalaliCalendar.Date,
        pendingCount: Int, overBudgetCategories: List<String>,
        fa: (String) -> String, money: (Long) -> String
    ): Urgent {
        val todayKey = Jx.dateKey(today)
        val dues = BillCalc.all(bills, today)
        dues.filter { it.overdue }.minByOrNull { it.daysUntil }?.let {
            return Urgent(UrgentLevel.HIGH, "«${it.bill.title}» عقب افتاده", "${fa("${-it.daysUntil}")} روز از سررسید گذشته • ${money(it.bill.amountRial)}", UrgentTarget.PLAN)
        }
        debts.filter { DebtCalc.overdue(it, todayKey) }.sortedWith(compareBy({ !it.iOwe }, { it.dueKey })).firstOrNull()?.let {
            return Urgent(UrgentLevel.HIGH, if (it.iOwe) "بدهی به ${it.person} سررسید گذشته" else "طلب از ${it.person} سررسید گذشته", money(it.amountRial), UrgentTarget.PLAN)
        }
        dues.filter { it.daysUntil in 0..2 }.minByOrNull { it.daysUntil }?.let {
            return Urgent(UrgentLevel.HIGH, "«${it.bill.title}» " + if (it.daysUntil == 0) "امروز سررسید است" else "${fa("${it.daysUntil}")} روز دیگر", money(it.bill.amountRial), UrgentTarget.PLAN)
        }
        DebtCalc.dueSoon(debts, todayKey, todayKey + 2).firstOrNull()?.let {
            return Urgent(UrgentLevel.MEDIUM, if (it.iOwe) "بدهی به ${it.person} نزدیک است" else "طلب از ${it.person} نزدیک است", money(it.amountRial), UrgentTarget.PLAN)
        }
        if (overBudgetCategories.isNotEmpty())
            return Urgent(UrgentLevel.MEDIUM, "بودجه «${overBudgetCategories.first()}» تمام شده", if (overBudgetCategories.size > 1) "و ${fa("${overBudgetCategories.size - 1}")} دستهٔ دیگر" else "این ماه دیگر خرجی برایش نگذار", UrgentTarget.MAIN)
        if (pendingCount > 0)
            return Urgent(UrgentLevel.MEDIUM, "${fa("$pendingCount")} تراکنش منتظر دسته‌بندی", "حدود ۱۰ ثانیه وقت می‌خواهد", UrgentTarget.MAIN)
        return Urgent(UrgentLevel.NONE, "همه‌چیز مرتب است ✓", "کار فوری‌ای نداری", UrgentTarget.MAIN)
    }
}

// ---- rotating message (new text every day so the eye does not tune it out) ----
data class NudgeFacts(
    val loggedToday: Boolean, val streakDays: Int, val pendingCount: Int,
    val yesterdayExpenseRial: Long, val allowanceRial: Long
)

object Nudges {
    private val generic = listOf(
        "پیش از خرید، ۱۰ ثانیه صبر کن: واقعاً لازمش داری؟",
        "پولی که ثبت نشود، دیده نمی‌شود؛ ثبت کردن ۵ ثانیه است.",
        "یک مبلغ کوچک پس‌انداز امروز، فردا را راحت‌تر می‌کند.",
        "قبض‌ها را قبل از سررسید بپرداز؛ ذهنت آرام‌تر می‌شود.",
        "خرج‌های کوچک روزانه، آخر ماه عدد بزرگی می‌شوند."
    )

    fun candidates(f: NudgeFacts, fa: (String) -> String, money: (Long) -> String): List<String> {
        val l = ArrayList<String>()
        if (!f.loggedToday) l.add("امروز هنوز چیزی ثبت نکرده‌ای؛ خرج یا درآمدی داشتی؟")
        if (f.pendingCount > 0) l.add("${fa("${f.pendingCount}")} تراکنش منتظر دسته‌بندی است؛ همین حالا تمامش کن.")
        if (f.yesterdayExpenseRial > 0) l.add("دیروز ${money(f.yesterdayExpenseRial)} خرج کردی.")
        if (f.allowanceRial > 0) l.add("امروز می‌توانی تا ${money(f.allowanceRial)} خرج کنی.")
        if (f.streakDays >= 2) l.add("🔥 ${fa("${f.streakDays}")} روز پشت‌سرهم ثبت کرده‌ای؛ زنجیره را نشکن!")
        l.addAll(generic)
        return l
    }

    /** Same message all day, a different one the next day. */
    fun pick(candidates: List<String>, dayIndex: Long): String =
        if (candidates.isEmpty()) "" else candidates[Math.floorMod(dayIndex, candidates.size.toLong()).toInt()]
}
