package ir.hesabyar.app

import android.content.Context

/** "Ask for the phone's screen lock (PIN / pattern / fingerprint) when opening the app". Off by default. */
object AppLock {
    private fun p(c: Context) = c.getSharedPreferences("hesabyar_settings", Context.MODE_PRIVATE)
    fun enabled(c: Context) = p(c).getBoolean("app_lock", false)
    fun setEnabled(c: Context, v: Boolean) { p(c).edit().putBoolean("app_lock", v).apply() }
    fun lastUnlock(c: Context) = p(c).getLong("last_unlock", 0L)
    fun touch(c: Context) { p(c).edit().putLong("last_unlock", System.currentTimeMillis()).apply() }
}
