package ir.hesabyar.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.backup.BackupCodec
import ir.hesabyar.app.parser.TextNormalizer
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.widget.PendingQueue
import ir.hesabyar.app.privacy.LockPolicy
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val ink get() = Ui.ink
    private lateinit var list: LinearLayout
    private lateinit var heroBox: LinearLayout
    private lateinit var chartsBox: LinearLayout
    private lateinit var pendingTitle: TextView
    private lateinit var rootView: LinearLayout
    private var unlocking = false
    private var themeKey = ""
    private fun currentThemeKey() = "${ThemeSettings.get(this)}|${ThemeSettings.systemDark(this)}"
    private val reqUnlock = 3103
    private val notifRequestCode = 2103
    private val smsPermissions = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
    private val smsRequestCode = 2102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)
        themeKey = currentThemeKey()

        // ---- page content: header, summary card, pending list, charts, settings ----
        heroBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pendingTitle = Ui.text(this, "منتظر دسته‌بندی", 16f, ink, true).apply { setPadding(0, Ui.dp(context, 16), 0, Ui.dp(context, 6)) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chartsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(header())
        content.addView(heroBox)
        content.addView(pendingTitle)
        content.addView(list)
        content.addView(chartsBox)
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- bottom bar ----
        root.addView(DashboardUi.navBar(this, listOf(
            DashboardUi.NavItem("🗓️", "تاریخچه") { startActivity(Intent(this, HistoryActivity::class.java)) },
            DashboardUi.NavItem("📊", "گزارش") { startActivity(Intent(this, ReportsActivity::class.java)) },
            DashboardUi.NavItem("🎯", "برنامه") { startActivity(Intent(this, PlanActivity::class.java)) },
            DashboardUi.NavItem("➕", "افزودن") { showAddDialog() },
            DashboardUi.NavItem("✉️", "پیامک‌ها") { startActivity(Intent(this, SmsInboxActivity::class.java)) }
        )), Ui.margins(this, 8, 0))
        rootView = root
        SystemInsets.apply(root)
        setContentView(root)

        handleWidgetIntent(intent)
        render()
        if (!WelcomeActivity.done(this)) startActivity(Intent(this, WelcomeActivity::class.java))
    }

    /** Title row: app name + date on the right, gear button (settings) on the left. */
    private fun header(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        row.addView(Ui.title(this, "حساب‌یار", DashboardUi.todayText(System.currentTimeMillis())), LinearLayout.LayoutParams(0, -2, 1f))
        val gear = Ui.text(this, "⚙", 22f, Ui.ink).apply {
            gravity = Gravity.CENTER
            background = Ui.rounded(Ui.dp(context, 22).toFloat(), Ui.p.soft, Ui.p.softStroke, Ui.dp(context, 1))
            contentDescription = "تنظیمات"
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        row.addView(gear, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))
        return row
    }

    /** Automatic catch-up of SMS that arrived while the app was closed. */
    private fun runCatchUp() {
        Thread {
            try { SmsCatchUp.run(this) } catch (e: Throwable) { try { CrashLog.record(this, e) } catch (_: Throwable) { } }
            runOnUiThread { if (!isFinishing && ::list.isInitialized) render() }
        }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); handleWidgetIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (themeKey != currentThemeKey()) { recreate(); return }
        if (::list.isInitialized) render()
        if (WelcomeActivity.done(this) && !SmsSettings.permissionAsked(this) && smsPermissions.any { !hasPermission(it) }) {
            SmsSettings.setPermissionAsked(this)
            explainAndRequestSmsPermissions()
        }
        runCatchUp()
        checkLock()
        safe { Notifier.scheduleDaily(this) }
        safe { SmsSync.schedule(this) }
    }

    // ---------- app lock (phone's own screen lock) ----------
    private fun deviceLockIntent(): Intent? {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        return if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("حساب‌یار", "برای ورود، هویتت را تأیید کن") else null
    }

    private fun checkLock() {
        if (isFinishing || unlocking || !::rootView.isInitialized) return
        if (!LockPolicy.needsUnlock(AppLock.enabled(this), System.currentTimeMillis(), AppLock.lastUnlock(this))) {
            rootView.visibility = View.VISIBLE; return
        }
        val intent = deviceLockIntent()
        if (intent == null) { rootView.visibility = View.VISIBLE; return }   // phone has no screen lock: cannot enforce
        rootView.visibility = View.INVISIBLE
        unlocking = true
        startActivityForResult(intent, reqUnlock)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            reqUnlock -> {
                unlocking = false
                if (resultCode == RESULT_OK) { AppLock.touch(this); rootView.visibility = View.VISIBLE; render() } else finish()
            }
        }
    }

    private fun handleWidgetIntent(intent: Intent?) {
        if (intent?.action == "ADD_TRANSACTION") showAddDialog(intent.getBooleanExtra("income", false))
        if (intent?.action == "CATEGORIZE_TRANSACTION") intent.getStringExtra("transaction_id")?.let { showCategoryDialog(it) }
    }

    private fun hasPermission(permission: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun explainAndRequestSmsPermissions() {
        val missing = smsPermissions.filterNot { hasPermission(it) }
        if (missing.isEmpty()) {
            Ui.dialog(this).setTitle("دسترسی پیامک فعال است")
                .setMessage("دریافت پیامک‌های جدید فعال است. برای واردکردن پیامک‌های قبلی نیز می‌توانی از دکمه مربوط استفاده کنی.")
                .setPositiveButton("باشه", null).show()
            return
        }
        Ui.dialog(this)
            .setTitle("اجازه دسترسی به پیامک‌ها")
            .setMessage("حساب‌یار برای شناسایی پیامک‌های بانکی به دریافت پیامک‌های جدید نیاز دارد. برای واردکردن پیامک‌های ۹۰ روز اخیر، دسترسی خواندن پیامک‌ها هم لازم است. فقط پیامک‌هایی که شبیه تراکنش مالی هستند روی همین گوشی ذخیره می‌شوند و شماره کارت در آن‌ها پوشانده می‌شود. برنامه مجوز اینترنت ندارد و هیچ پیامکی ارسال نمی‌شود. هر زمان بخواهی می‌توانی همه داده‌ها را حذف کنی. ممکن است اندروید یا روش نصب APK دسترسی را محدود کند.")
            .setNegativeButton("فعلاً نه", null)
            .setPositiveButton("ادامه و درخواست مجوز") { _, _ -> requestPermissions(missing.toTypedArray(), smsRequestCode) }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == notifRequestCode) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) Notifier.check(this)
            else Toast.makeText(this, "اجازهٔ اعلان داده نشد؛ هشدارها نمایش داده نمی‌شوند.", Toast.LENGTH_LONG).show()
            return
        }
        if (requestCode == smsRequestCode) {
            val granted = permissions.zip(grantResults.toList()).filter { it.second == PackageManager.PERMISSION_GRANTED }.map { it.first }
            val message = buildString {
                append(if (granted.isEmpty()) "مجوزی داده نشد." else "مجوزهای تأییدشده: ${granted.joinToString()}.")
                if (!hasPermission(Manifest.permission.RECEIVE_SMS)) append(" دریافت پیامک جدید فعال نیست.")
                if (!hasPermission(Manifest.permission.READ_SMS)) append(" واردکردن پیامک‌های قبلی فعال نیست.")
                append(" اگر اندروید دسترسی را مسدود کرده، وضعیت مجوزها را در تنظیمات برنامه بررسی کن.")
            }
            runCatchUp()
            Ui.dialog(this).setTitle("وضعیت دسترسی").setMessage(message).setPositiveButton("باشه", null).show()
        }
    }

    /** Runs [block]; on any failure, remembers the error text so the crash screen can show it next time. */
    private fun safe(block: () -> Unit) {
        try { block() } catch (e: Throwable) {
            try { CrashLog.record(this, e) } catch (_: Throwable) { }
        }
    }

    private fun render() {
        val unit = DisplaySettings.get(this)
        val now = System.currentTimeMillis()
        val all = TransactionStore.all(this)
        val summary = ReportCalculator(now).summary(all)

        heroBox.removeAllViews()
        if (smsPermissions.any { !hasPermission(it) }) {
            heroBox.addView(DashboardUi.permissionBanner(this) { explainAndRequestSmsPermissions() }, Ui.margins(this, 0, 10))
        }
        safe { heroBox.addView(DashboardUi.hero(this, all, summary, unit, now), Ui.margins(this, 0, 4)) }

        list.removeAllViews()
        val items = PendingQueue.pending(all)
        pendingTitle.text = if (items.isEmpty()) "منتظر دسته‌بندی" else "منتظر دسته‌بندی (${AmountFormatter.toPersianDigits("${items.size}")})"
        if (items.isEmpty()) list.addView(Ui.glass(this, 18).apply {
            addView(Ui.text(context, "همه تراکنش‌ها دسته‌بندی شده‌اند ✓", 15f, ink).apply { gravity = Gravity.CENTER })
        }, Ui.margins(this, 0, 8))
        items.forEach { tx ->
            val card = Ui.glass(this, 14)
            card.addView(Ui.text(this, tx.title, 16f, ink, true))
            card.addView(Ui.text(this, "${tx.bank}  •  ${tx.time}", 12f, Ui.muted))
            card.addView(Ui.text(this, AmountFormatter.formatSigned(tx.amount, tx.isIncome, tx.currencyType, unit), 15f,
                if (tx.isIncome) Ui.green else Ui.red, true).apply { setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8)) })
            ir.hesabyar.app.plan.CategorySuggester.suggest(tx, all)?.let { sug ->
                card.addView(Ui.soft(this, "پیشنهاد: «${sug.category}» (از ${AmountFormatter.toPersianDigits("${sug.matches}")} مورد مشابه قبلی) — تأیید") {
                    TransactionStore.categorize(this, tx.id, sug.category); PendingTransactionsWidget.updateAll(this); render()
                }, Ui.margins(this, 0, 6))
            }
            card.addView(Ui.primary(this, "انتخاب دسته‌بندی") { showCategoryDialog(tx.id) })
            list.addView(card, Ui.margins(this, 0, 10))
        }

        chartsBox.removeAllViews()
        // Each card is built on its own: a problem in one card must never stop the whole screen from opening.
        safe { chartsBox.addView(PlanUi.spendingCard(this, summary, now, unit) { startActivity(Intent(this, ReportsActivity::class.java)) }, Ui.margins(this, 6, 10)) }
        safe { PlanUi.dueCard(this, now, unit) { startActivity(Intent(this, PlanActivity::class.java)) }?.let { chartsBox.addView(it, Ui.margins(this, 0, 10)) } }
        safe { PlanUi.accountsCard(this, all, unit)?.let { chartsBox.addView(it, Ui.margins(this, 0, 10)) } }
        safe { chartsBox.addView(DashboardUi.donutCard(this, summary), Ui.margins(this, 0, 10)) }
        safe { chartsBox.addView(DashboardUi.trendCard(this, all, now), Ui.margins(this, 0, 10)) }
        safe { PlanUi.insightsCard(this, all, now, unit)?.let { chartsBox.addView(it, Ui.margins(this, 0, 6)) } }
    }

    private fun showCategoryDialog(id: String) {
        CategoryPicker.show(this, "دسته‌بندی تراکنش") { picked ->
            TransactionStore.categorize(this, id, picked); PendingTransactionsWidget.updateAll(this); render()
        }
    }

    private fun showAddDialog(defaultIncome: Boolean = false) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22,8,22,0) }
        val titleInput = EditText(this).apply { hint = "عنوان تراکنش" }
        val unit = DisplaySettings.get(this)
        val amountInput = EditText(this).apply { hint = "مبلغ به ${unit.labelFa}"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("هزینه", "درآمد")) }
        type.setSelection(if (defaultIncome) 1 else 0)
        panel.addView(titleInput); panel.addView(amountInput); panel.addView(type)
        Ui.dialog(this).setTitle("ثبت دستی تراکنش").setView(panel).setPositiveButton("ثبت") { _, _ ->
            val amount = TextNormalizer.normalize(amountInput.text.toString()).replace(",", "").trim().toLongOrNull()
            // Stored exactly as typed, together with the unit the user was typing in.
            if (amount != null && amount > 0) { TransactionStore.add(this, titleInput.text.toString(), amount, type.selectedItemPosition == 1, unit); PendingTransactionsWidget.updateAll(this); render() }
            else Toast.makeText(this, "مبلغ معتبر وارد کن", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("لغو", null).show()
    }
}
