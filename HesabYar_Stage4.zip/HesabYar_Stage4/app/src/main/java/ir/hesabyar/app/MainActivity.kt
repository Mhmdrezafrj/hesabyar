package ir.hesabyar.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.parser.TextNormalizer
import ir.hesabyar.app.widget.Categories

class MainActivity : Activity() {
    private val ink = Color.rgb(45, 36, 79)
    private lateinit var list: LinearLayout
    private lateinit var unitButton: Button
    private lateinit var autoButton: Button
    private val smsPermissions = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
    private val smsRequestCode = 2102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 20)
            setBackgroundColor(Color.rgb(246, 242, 255))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "حساب‌یار"; textSize = 26f; setTextColor(ink)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "تراکنش‌های دسته‌بندی‌نشده و پیامک‌های بانکی"
            textSize = 14f; setTextColor(Color.rgb(105, 96, 130)); setPadding(0, 6, 0, 12)
        })
        val permissionButton = Button(this).apply {
            text = "فعال‌سازی دریافت پیامک بانکی"
            setOnClickListener { explainAndRequestSmsPermissions() }
        }
        root.addView(permissionButton)
        val inboxButton = Button(this).apply {
            text = "صندوق پیامک‌ها"
            setOnClickListener { startActivity(Intent(this@MainActivity, SmsInboxActivity::class.java)) }
        }
        root.addView(inboxButton)
        val importButton = Button(this).apply {
            text = "وارد کردن پیامک‌های قبلی (۹۰ روز اخیر)"
            setOnClickListener { importHistory() }
        }
        root.addView(importButton)
        unitButton = Button(this).apply {
            setOnClickListener {
                DisplaySettings.toggle(this@MainActivity)
                updateUnitButton(); PendingTransactionsWidget.updateAll(this@MainActivity); render()
            }
        }
        root.addView(unitButton)
        updateUnitButton()
        autoButton = Button(this).apply {
            setOnClickListener {
                SmsSettings.setAutoEnabled(this@MainActivity, !SmsSettings.autoEnabled(this@MainActivity))
                updateAutoButton(); runCatchUp()
            }
        }
        root.addView(autoButton)
        updateAutoButton()
        root.addView(Button(this).apply {
            text = "+ افزودن دستی تراکنش"
            setOnClickListener { showAddDialog() }
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        handleWidgetIntent(intent)
        render()
        // First launch: explain and ask for SMS access automatically (once).
        if (!SmsSettings.permissionAsked(this) && smsPermissions.any { !hasPermission(it) }) {
            SmsSettings.setPermissionAsked(this)
            explainAndRequestSmsPermissions()
        }
    }

    private fun updateAutoButton() {
        autoButton.text = "دریافت و تشخیص خودکار پیامک بانکی: " + if (SmsSettings.autoEnabled(this)) "روشن" else "خاموش"
    }

    /** Automatic catch-up of SMS that arrived while the app was closed. */
    private fun runCatchUp() {
        Thread {
            SmsCatchUp.run(this)
            runOnUiThread { if (!isFinishing && ::list.isInitialized) render() }
        }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); handleWidgetIntent(intent)
    }

    override fun onResume() { super.onResume(); if (::list.isInitialized) render(); runCatchUp() }

    private fun handleWidgetIntent(intent: Intent?) {
        if (intent?.action == "ADD_TRANSACTION") showAddDialog()
        if (intent?.action == "CATEGORIZE_TRANSACTION") intent.getStringExtra("transaction_id")?.let { showCategoryDialog(it) }
    }

    private fun updateUnitButton() {
        val unit = DisplaySettings.get(this)
        val other = if (unit == ir.hesabyar.app.money.Currency.TOMAN) ir.hesabyar.app.money.Currency.RIAL else ir.hesabyar.app.money.Currency.TOMAN
        unitButton.text = "واحد نمایش مبلغ: ${unit.labelFa} (تغییر به ${other.labelFa})"
    }

    private fun hasPermission(permission: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun explainAndRequestSmsPermissions() {
        val missing = smsPermissions.filterNot { hasPermission(it) }
        if (missing.isEmpty()) {
            AlertDialog.Builder(this).setTitle("دسترسی پیامک فعال است")
                .setMessage("دریافت پیامک‌های جدید فعال است. برای واردکردن پیامک‌های قبلی نیز می‌توانی از دکمه مربوط استفاده کنی.")
                .setPositiveButton("باشه", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("اجازه دسترسی به پیامک‌ها")
            .setMessage("حساب‌یار برای شناسایی پیامک‌های بانکی به دریافت پیامک‌های جدید نیاز دارد. برای واردکردن پیامک‌های ۹۰ روز اخیر، دسترسی خواندن پیامک‌ها هم لازم است. فقط پیامک‌هایی که با قواعد اولیه مالی تطبیق داشته باشند، در صندوق محلی ذخیره می‌شوند. هیچ پیامکی به اینترنت یا سرور ارسال نمی‌شود. ممکن است اندروید یا روش نصب APK دسترسی را محدود کند.")
            .setNegativeButton("فعلاً نه", null)
            .setPositiveButton("ادامه و درخواست مجوز") { _, _ -> requestPermissions(missing.toTypedArray(), smsRequestCode) }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == smsRequestCode) {
            val granted = permissions.zip(grantResults.toList()).filter { it.second == PackageManager.PERMISSION_GRANTED }.map { it.first }
            val message = buildString {
                append(if (granted.isEmpty()) "مجوزی داده نشد." else "مجوزهای تأییدشده: ${granted.joinToString()}.")
                if (!hasPermission(Manifest.permission.RECEIVE_SMS)) append(" دریافت پیامک جدید فعال نیست.")
                if (!hasPermission(Manifest.permission.READ_SMS)) append(" واردکردن پیامک‌های قبلی فعال نیست.")
                append(" اگر اندروید دسترسی را مسدود کرده، وضعیت مجوزها را در تنظیمات برنامه بررسی کن.")
            }
            runCatchUp()
            AlertDialog.Builder(this).setTitle("وضعیت دسترسی").setMessage(message).setPositiveButton("باشه", null).show()
        }
    }

    private fun importHistory() {
        if (!hasPermission(Manifest.permission.READ_SMS)) {
            explainAndRequestSmsPermissions(); return
        }
        AlertDialog.Builder(this).setTitle("واردکردن پیامک‌های قبلی")
            .setMessage("تا ۱۰۰۰ پیامک دریافتی از ۹۰ روز اخیر بررسی می‌شود. فقط پیامک‌های مشکوک به تراکنش مالی ذخیره می‌شوند. متن سایر پیامک‌ها ذخیره نخواهد شد. ادامه می‌دهی؟")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("شروع") { _, _ ->
                try {
                    val result = SmsHistoryImporter.importRecent(this)
                    render()
                    AlertDialog.Builder(this).setTitle("پایان بررسی")
                        .setMessage("بررسی‌شده: ${result.scanned}\nذخیره‌شده: ${result.saved}\nتکراری یا غیرمالی: ${result.duplicatesOrSkipped}")
                        .setPositiveButton("مشاهده صندوق") { _, _ -> startActivity(Intent(this, SmsInboxActivity::class.java)) }.show()
                } catch (e: SecurityException) {
                    Toast.makeText(this, "دسترسی خواندن پیامک داده نشده است.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "خطا در واردکردن پیامک‌ها: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun render() {
        list.removeAllViews()
        val items = TransactionStore.pending(this)
        if (items.isEmpty()) list.addView(TextView(this).apply {
            text = "همه تراکنش‌ها دسته‌بندی شده‌اند ✓"; textSize = 16f; setTextColor(ink)
            gravity = Gravity.CENTER; setPadding(12, 40, 12, 40)
        })
        items.forEach { tx ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); setBackgroundColor(Color.WHITE); layoutDirection = View.LAYOUT_DIRECTION_RTL }
            card.addView(TextView(this).apply { text = tx.title; textSize = 16f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply { text = "${tx.bank}  •  ${tx.time}"; textSize = 12f; setTextColor(Color.GRAY) })
            card.addView(TextView(this).apply { text = AmountFormatter.formatSigned(tx.amount, tx.isIncome, tx.currencyType, DisplaySettings.get(this@MainActivity)); textSize = 15f; setTextColor(if (tx.isIncome) Color.rgb(0,145,88) else Color.rgb(215,55,78)); setPadding(0,8,0,8) })
            card.addView(Button(this).apply { text = "انتخاب دسته‌بندی"; setOnClickListener { showCategoryDialog(tx.id) } })
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        }
    }

    private fun showCategoryDialog(id: String) {
        val categories = Categories.defaults.toTypedArray()
        AlertDialog.Builder(this).setTitle("دسته‌بندی تراکنش").setItems(categories) { _, which ->
            TransactionStore.categorize(this, id, categories[which]); PendingTransactionsWidget.updateAll(this); render()
        }.setNegativeButton("انصراف", null).show()
    }

    private fun showAddDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22,8,22,0) }
        val titleInput = EditText(this).apply { hint = "عنوان تراکنش" }
        val unit = DisplaySettings.get(this)
        val amountInput = EditText(this).apply { hint = "مبلغ به ${unit.labelFa}"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("هزینه", "درآمد")) }
        panel.addView(titleInput); panel.addView(amountInput); panel.addView(type)
        AlertDialog.Builder(this).setTitle("ثبت دستی تراکنش").setView(panel).setPositiveButton("ثبت") { _, _ ->
            val amount = TextNormalizer.normalize(amountInput.text.toString()).replace(",", "").trim().toLongOrNull()
            // Stored exactly as typed, together with the unit the user was typing in.
            if (amount != null && amount > 0) { TransactionStore.add(this, titleInput.text.toString(), amount, type.selectedItemPosition == 1, unit); PendingTransactionsWidget.updateAll(this); render() }
            else Toast.makeText(this, "مبلغ معتبر وارد کن", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("لغو", null).show()
    }
}
