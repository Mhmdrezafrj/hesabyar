package ir.hesabyar.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.backup.BackupCodec
import ir.hesabyar.app.parser.TextNormalizer
import ir.hesabyar.app.report.ReportCalculator
import ir.hesabyar.app.widget.PendingQueue
import ir.hesabyar.app.privacy.LockPolicy
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val ink = Ui.ink
    private lateinit var list: LinearLayout
    private lateinit var heroBox: LinearLayout
    private lateinit var chartsBox: LinearLayout
    private lateinit var pendingTitle: TextView
    private lateinit var unitButton: Button
    private lateinit var autoButton: Button
    private lateinit var lockButton: Button
    private lateinit var rootView: LinearLayout
    private var unlocking = false
    private val reqExport = 3101
    private val reqImport = 3102
    private val reqUnlock = 3103
    private val smsPermissions = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
    private val smsRequestCode = 2102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)

        // ---- settings (collapsed by default; same buttons as before) ----
        val settingsRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        settingsRow.addView(Ui.primary(this, "فعال‌سازی دریافت پیامک بانکی") { explainAndRequestSmsPermissions() }, Ui.margins(this, 0, 6))
        settingsRow.addView(Ui.soft(this, "وارد کردن پیامک‌های قبلی (۹۰ روز اخیر)") { importHistory() }, Ui.margins(this, 0, 6))
        unitButton = Ui.soft(this, "") {
            DisplaySettings.toggle(this@MainActivity)
            updateUnitButton(); PendingTransactionsWidget.updateAll(this@MainActivity); render()
        }
        settingsRow.addView(unitButton, Ui.margins(this, 0, 6))
        updateUnitButton()
        autoButton = Ui.soft(this, "") {
            SmsSettings.setAutoEnabled(this@MainActivity, !SmsSettings.autoEnabled(this@MainActivity))
            updateAutoButton(); runCatchUp()
        }
        settingsRow.addView(autoButton, Ui.margins(this, 0, 6))
        updateAutoButton()
        lockButton = Ui.soft(this, "") { toggleLock() }
        settingsRow.addView(lockButton, Ui.margins(this, 0, 6))
        updateLockButton()
        settingsRow.addView(Ui.soft(this, "پشتیبان‌گیری از داده‌ها") { confirmExport() }, Ui.margins(this, 0, 6))
        settingsRow.addView(Ui.soft(this, "بازگردانی از فایل پشتیبان") { pickBackupFile() }, Ui.margins(this, 0, 6))
        settingsRow.addView(Ui.soft(this, "حریم خصوصی و حذف داده‌ها") { showPrivacyDialog() }, Ui.margins(this, 0, 6))
        val settingsToggle = Ui.soft(this, "⚙  تنظیمات و ابزارها  ▼") {}
        settingsToggle.setOnClickListener {
            val open = settingsRow.visibility != View.VISIBLE
            settingsRow.visibility = if (open) View.VISIBLE else View.GONE
            settingsToggle.text = if (open) "⚙  تنظیمات و ابزارها  ▲" else "⚙  تنظیمات و ابزارها  ▼"
        }

        // ---- page content: header, summary card, pending list, charts, settings ----
        heroBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pendingTitle = Ui.text(this, "منتظر دسته‌بندی", 16f, ink, true).apply { setPadding(0, Ui.dp(context, 16), 0, Ui.dp(context, 6)) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chartsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(Ui.title(this, "حساب‌یار", DashboardUi.todayText(System.currentTimeMillis())))
        content.addView(heroBox)
        content.addView(pendingTitle)
        content.addView(list)
        content.addView(chartsBox)
        content.addView(settingsToggle, Ui.margins(this, 8, 8))
        content.addView(settingsRow)
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- bottom bar ----
        root.addView(DashboardUi.navBar(this, listOf(
            DashboardUi.NavItem("🗓️", "تاریخچه") { startActivity(Intent(this, HistoryActivity::class.java)) },
            DashboardUi.NavItem("📊", "گزارش") { startActivity(Intent(this, ReportsActivity::class.java)) },
            DashboardUi.NavItem("➕", "افزودن") { showAddDialog() },
            DashboardUi.NavItem("✉️", "پیامک‌ها") { startActivity(Intent(this, SmsInboxActivity::class.java)) }
        )), Ui.margins(this, 8, 0))
        rootView = root
        SystemInsets.apply(root)
        setContentView(root)

        handleWidgetIntent(intent)
        render()
        // First launch: explain and ask for SMS access automatically (once).
        if (!SmsSettings.permissionAsked(this) && smsPermissions.any { !hasPermission(it) }) {
            SmsSettings.setPermissionAsked(this)
            explainAndRequestSmsPermissions()
        }
    }

    private fun showPrivacyDialog() {
        AlertDialog.Builder(this).setTitle("حریم خصوصی")
            .setMessage("• همه اطلاعات فقط روی همین گوشی ذخیره می‌شود. برنامه مجوز اینترنت ندارد و هیچ اطلاعاتی ارسال نمی‌کند.\n" +
                "• پشتیبان‌گیری ابری برنامه خاموش است.\n" +
                "• شماره کارت و شبا پیش از ذخیره‌شدن متن پیامک، پوشانده می‌شود (فقط ۴ رقم آخر می‌ماند).\n" +
                "• اعلانی با متن پیامک نمایش داده نمی‌شود و متن پیامک در گزارش خطا ثبت نمی‌شود.\n" +
                "• دسترسی پیامک فقط برای تشخیص پیامک‌های بانکی است؛ هر زمان خواستی از «دریافت و تشخیص خودکار» خاموشش کن یا مجوز را در تنظیمات اندروید بگیر.\n" +
                "• حذف یک تراکنش: در «گزارش مالی»، روی تراکنش نگه‌دار.")
            .setNegativeButton("بستن", null)
            .setPositiveButton("حذف همه داده‌ها…") { _, _ -> confirmWipe() }
            .show()
    }

    private fun confirmWipe() {
        AlertDialog.Builder(this).setTitle("حذف همه داده‌ها؟")
            .setMessage("همه تراکنش‌ها، دسته‌ها و صندوق پیامک‌ها برای همیشه از این گوشی پاک می‌شود و قابل بازیابی نیست. پیامک‌های قدیمی دوباره خودکار وارد نمی‌شوند؛ فقط پیامک‌های جدید از این لحظه بررسی می‌شوند.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("حذف کن") { _, _ ->
                DataWiper.wipeAll(this); render()
                Toast.makeText(this, "همه داده‌ها حذف شد", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun updateAutoButton() {
        autoButton.text = "دریافت و تشخیص خودکار پیامک بانکی: " + if (SmsSettings.autoEnabled(this)) "روشن" else "خاموش"
    }

    /** Automatic catch-up of SMS that arrived while the app was closed. */
    private fun runCatchUp() {
        Thread {
            SmsCatchUp.run(this)
            runOnUiThread { if (!isFinishing && ::list.isInitialized) render() }
        }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); handleWidgetIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) render()
        runCatchUp()
        checkLock()
    }

    // ---------- app lock (phone's own screen lock) ----------
    private fun deviceLockIntent(): Intent? {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        return if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("حساب‌یار", "برای ورود، هویتت را تأیید کن") else null
    }

    private fun checkLock() {
        if (isFinishing || unlocking || !::rootView.isInitialized) return
        if (!LockPolicy.needsUnlock(AppLock.enabled(this), System.currentTimeMillis(), AppLock.lastUnlock(this))) {
            rootView.visibility = View.VISIBLE; return
        }
        val intent = deviceLockIntent()
        if (intent == null) { rootView.visibility = View.VISIBLE; return }   // phone has no screen lock: cannot enforce
        rootView.visibility = View.INVISIBLE
        unlocking = true
        startActivityForResult(intent, reqUnlock)
    }

    private fun toggleLock() {
        if (AppLock.enabled(this)) { AppLock.setEnabled(this, false) }
        else if (deviceLockIntent() == null) {
            Toast.makeText(this, "اول در تنظیمات گوشی، قفل صفحه (پین، الگو یا اثر انگشت) را فعال کن.", Toast.LENGTH_LONG).show()
        } else { AppLock.setEnabled(this, true); AppLock.touch(this) }
        updateLockButton()
    }

    private fun updateLockButton() {
        lockButton.text = if (AppLock.enabled(this)) "قفل برنامه: روشن (برای خاموش‌کردن لمس کن)" else "قفل برنامه با قفل صفحه گوشی: خاموش"
    }

    // ---------- backup / restore (local file chosen by the user) ----------
    private fun confirmExport() {
        AlertDialog.Builder(this).setTitle("پشتیبان‌گیری")
            .setMessage("یک فایل متنی شامل تراکنش‌ها، دسته‌ها و بودجه‌ها ساخته می‌شود. فایل رمزگذاری‌شده نیست؛ هر کس آن را داشته باشد می‌تواند اطلاعات مالی‌ات را ببیند. آن را فقط جای امن نگه‌دار و برای کسی نفرست.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ادامه") { _, _ ->
                val day = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, "hesabyar-backup-$day.txt")
                }, reqExport)
            }.show()
    }

    private fun pickBackupFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, reqImport)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            reqUnlock -> {
                unlocking = false
                if (resultCode == RESULT_OK) { AppLock.touch(this); rootView.visibility = View.VISIBLE; render() } else finish()
            }
            reqExport -> if (resultCode == RESULT_OK) data?.data?.let { uri -> writeBackup(uri) }
            reqImport -> if (resultCode == RESULT_OK) data?.data?.let { uri -> restoreBackup(uri) }
        }
    }

    private fun writeBackup(uri: android.net.Uri) {
        try {
            val text = BackupCodec.encode(TransactionStore.all(this), CategoryStore.all(this), BudgetStore.all(this))
            contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: throw java.io.IOException("no stream")
            Toast.makeText(this, "پشتیبان ذخیره شد.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ذخیرهٔ پشتیبان ناموفق بود.", Toast.LENGTH_LONG).show()
        }
    }

    private fun restoreBackup(uri: android.net.Uri) {
        val text = try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes == null || bytes.size > 20_000_000) null else bytes.toString(Charsets.UTF_8)
        } catch (e: Exception) { null }
        if (text == null) { Toast.makeText(this, "فایل خوانده نشد یا خیلی بزرگ است.", Toast.LENGTH_LONG).show(); return }
        val result = BackupCodec.decode(text)
        val data = result.data
        if (data == null) { Toast.makeText(this, result.error ?: "فایل نامعتبر است", Toast.LENGTH_LONG).show(); return }
        val added = TransactionStore.importMissing(this, data.transactions)
        data.categories.forEach { CategoryStore.add(this, it) }          // already existing ones are simply refused
        val budgets = BudgetStore.all(this)
        data.budgets.forEach { (cat, limit) -> if (cat !in budgets) BudgetStore.set(this, cat, limit) }
        PendingTransactionsWidget.updateAll(this); render()
        Toast.makeText(this, "بازگردانی انجام شد: ${AmountFormatter.toPersianDigits("$added")} تراکنش جدید اضافه شد.", Toast.LENGTH_LONG).show()
    }

    private fun handleWidgetIntent(intent: Intent?) {
        if (intent?.action == "ADD_TRANSACTION") showAddDialog()
        if (intent?.action == "CATEGORIZE_TRANSACTION") intent.getStringExtra("transaction_id")?.let { showCategoryDialog(it) }
    }

    private fun updateUnitButton() {
        val unit = DisplaySettings.get(this)
        val other = if (unit == ir.hesabyar.app.money.Currency.TOMAN) ir.hesabyar.app.money.Currency.RIAL else ir.hesabyar.app.money.Currency.TOMAN
        unitButton.text = "واحد نمایش مبلغ: ${unit.labelFa} (تغییر به ${other.labelFa})"
    }

    private fun hasPermission(permission: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun explainAndRequestSmsPermissions() {
        val missing = smsPermissions.filterNot { hasPermission(it) }
        if (missing.isEmpty()) {
            AlertDialog.Builder(this).setTitle("دسترسی پیامک فعال است")
                .setMessage("دریافت پیامک‌های جدید فعال است. برای واردکردن پیامک‌های قبلی نیز می‌توانی از دکمه مربوط استفاده کنی.")
                .setPositiveButton("باشه", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("اجازه دسترسی به پیامک‌ها")
            .setMessage("حساب‌یار برای شناسایی پیامک‌های بانکی به دریافت پیامک‌های جدید نیاز دارد. برای واردکردن پیامک‌های ۹۰ روز اخیر، دسترسی خواندن پیامک‌ها هم لازم است. فقط پیامک‌هایی که شبیه تراکنش مالی هستند روی همین گوشی ذخیره می‌شوند و شماره کارت در آن‌ها پوشانده می‌شود. برنامه مجوز اینترنت ندارد و هیچ پیامکی ارسال نمی‌شود. هر زمان بخواهی می‌توانی همه داده‌ها را حذف کنی. ممکن است اندروید یا روش نصب APK دسترسی را محدود کند.")
            .setNegativeButton("فعلاً نه", null)
            .setPositiveButton("ادامه و درخواست مجوز") { _, _ -> requestPermissions(missing.toTypedArray(), smsRequestCode) }
            .show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == smsRequestCode) {
            val granted = permissions.zip(grantResults.toList()).filter { it.second == PackageManager.PERMISSION_GRANTED }.map { it.first }
            val message = buildString {
                append(if (granted.isEmpty()) "مجوزی داده نشد." else "مجوزهای تأییدشده: ${granted.joinToString()}.")
                if (!hasPermission(Manifest.permission.RECEIVE_SMS)) append(" دریافت پیامک جدید فعال نیست.")
                if (!hasPermission(Manifest.permission.READ_SMS)) append(" واردکردن پیامک‌های قبلی فعال نیست.")
                append(" اگر اندروید دسترسی را مسدود کرده، وضعیت مجوزها را در تنظیمات برنامه بررسی کن.")
            }
            runCatchUp()
            AlertDialog.Builder(this).setTitle("وضعیت دسترسی").setMessage(message).setPositiveButton("باشه", null).show()
        }
    }

    private fun importHistory() {
        if (!hasPermission(Manifest.permission.READ_SMS)) {
            explainAndRequestSmsPermissions(); return
        }
        AlertDialog.Builder(this).setTitle("واردکردن پیامک‌های قبلی")
            .setMessage("تا ۱۰۰۰ پیامک دریافتی از ۹۰ روز اخیر بررسی می‌شود. فقط پیامک‌های مشکوک به تراکنش مالی ذخیره می‌شوند. متن سایر پیامک‌ها ذخیره نخواهد شد. ادامه می‌دهی؟")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("شروع") { _, _ ->
                try {
                    val result = SmsHistoryImporter.importRecent(this)
                    render()
                    AlertDialog.Builder(this).setTitle("پایان بررسی")
                        .setMessage("بررسی‌شده: ${result.scanned}\nذخیره‌شده: ${result.saved}\nتکراری یا غیرمالی: ${result.duplicatesOrSkipped}")
                        .setPositiveButton("مشاهده صندوق") { _, _ -> startActivity(Intent(this, SmsInboxActivity::class.java)) }.show()
                } catch (e: SecurityException) {
                    Toast.makeText(this, "دسترسی خواندن پیامک داده نشده است.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "خطا در واردکردن پیامک‌ها: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun render() {
        val unit = DisplaySettings.get(this)
        val now = System.currentTimeMillis()
        val all = TransactionStore.all(this)
        val summary = ReportCalculator(now).summary(all)

        heroBox.removeAllViews()
        if (smsPermissions.any { !hasPermission(it) }) {
            heroBox.addView(DashboardUi.permissionBanner(this) { explainAndRequestSmsPermissions() }, Ui.margins(this, 0, 10))
        }
        heroBox.addView(DashboardUi.hero(this, all, summary, unit, now), Ui.margins(this, 0, 4))

        list.removeAllViews()
        val items = PendingQueue.pending(all)
        pendingTitle.text = if (items.isEmpty()) "منتظر دسته‌بندی" else "منتظر دسته‌بندی (${AmountFormatter.toPersianDigits("${items.size}")})"
        if (items.isEmpty()) list.addView(Ui.glass(this, 18).apply {
            addView(Ui.text(context, "همه تراکنش‌ها دسته‌بندی شده‌اند ✓", 15f, ink).apply { gravity = Gravity.CENTER })
        }, Ui.margins(this, 0, 8))
        items.forEach { tx ->
            val card = Ui.glass(this, 14)
            card.addView(Ui.text(this, tx.title, 16f, ink, true))
            card.addView(Ui.text(this, "${tx.bank}  •  ${tx.time}", 12f, Ui.muted))
            card.addView(Ui.text(this, AmountFormatter.formatSigned(tx.amount, tx.isIncome, tx.currencyType, unit), 15f,
                if (tx.isIncome) Ui.green else Ui.red, true).apply { setPadding(0, Ui.dp(context, 8), 0, Ui.dp(context, 8)) })
            card.addView(Ui.primary(this, "انتخاب دسته‌بندی") { showCategoryDialog(tx.id) })
            list.addView(card, Ui.margins(this, 0, 10))
        }

        chartsBox.removeAllViews()
        chartsBox.addView(DashboardUi.donutCard(this, summary), Ui.margins(this, 6, 10))
        chartsBox.addView(DashboardUi.trendCard(this, all, now), Ui.margins(this, 0, 6))
    }

    private fun showCategoryDialog(id: String) {
        CategoryPicker.show(this, "دسته‌بندی تراکنش") { picked ->
            TransactionStore.categorize(this, id, picked); PendingTransactionsWidget.updateAll(this); render()
        }
    }

    private fun showAddDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22,8,22,0) }
        val titleInput = EditText(this).apply { hint = "عنوان تراکنش" }
        val unit = DisplaySettings.get(this)
        val amountInput = EditText(this).apply { hint = "مبلغ به ${unit.labelFa}"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("هزینه", "درآمد")) }
        panel.addView(titleInput); panel.addView(amountInput); panel.addView(type)
        AlertDialog.Builder(this).setTitle("ثبت دستی تراکنش").setView(panel).setPositiveButton("ثبت") { _, _ ->
            val amount = TextNormalizer.normalize(amountInput.text.toString()).replace(",", "").trim().toLongOrNull()
            // Stored exactly as typed, together with the unit the user was typing in.
            if (amount != null && amount > 0) { TransactionStore.add(this, titleInput.text.toString(), amount, type.selectedItemPosition == 1, unit); PendingTransactionsWidget.updateAll(this); render() }
            else Toast.makeText(this, "مبلغ معتبر وارد کن", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("لغو", null).show()
    }
}
