package ir.hesabyar.app

/** Ids of the 4 x 6 invisible tap cells in widget_combo.xml: index = row * 4 + col. */
object OverlayIds {
    val ids = intArrayOf(
    R.id.ov_c0_r0, R.id.ov_c1_r0, R.id.ov_c2_r0, R.id.ov_c3_r0,
    R.id.ov_c0_r1, R.id.ov_c1_r1, R.id.ov_c2_r1, R.id.ov_c3_r1,
    R.id.ov_c0_r2, R.id.ov_c1_r2, R.id.ov_c2_r2, R.id.ov_c3_r2,
    R.id.ov_c0_r3, R.id.ov_c1_r3, R.id.ov_c2_r3, R.id.ov_c3_r3,
    R.id.ov_c0_r4, R.id.ov_c1_r4, R.id.ov_c2_r4, R.id.ov_c3_r4,
    R.id.ov_c0_r5, R.id.ov_c1_r5, R.id.ov_c2_r5, R.id.ov_c3_r5
    )
    fun at(col: Int, row: Int) = ids[row * 4 + col]
}
