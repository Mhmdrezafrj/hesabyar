package ir.hesabyar.app

import android.content.Context

/** Notification switch and the list of alerts already shown (so nothing is repeated). Off by default. */
object AlertSettings {
    private const val PREFS = "hesabyar_settings"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean("alerts_on", false)
    fun setEnabled(c: Context, v: Boolean) { p(c).edit().putBoolean("alerts_on", v).apply() }

    fun sent(c: Context): Set<String> = (p(c).getString("alerts_sent", "") ?: "").split('\n').filter { it.isNotEmpty() }.toSet()
    fun saveSent(c: Context, s: Set<String>) { p(c).edit().putString("alerts_sent", s.joinToString("\n")).apply() }
}
