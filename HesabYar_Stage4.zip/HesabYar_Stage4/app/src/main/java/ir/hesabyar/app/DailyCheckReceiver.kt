package ir.hesabyar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Fired about once a day (inexact alarm) to check budgets, bills and debts. */
class DailyCheckReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val app = context.applicationContext
        Thread {
            try { Notifier.check(app); BudgetWidget.updateAll(app) } catch (_: Exception) {} finally { pending.finish() }
        }.start()
    }
}
