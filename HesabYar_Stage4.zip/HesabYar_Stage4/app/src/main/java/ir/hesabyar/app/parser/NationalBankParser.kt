package ir.hesabyar.app.parser

import ir.hesabyar.app.money.Currency

/**
 * Parser for Bank Melli Iran (بانک ملی ایران) — initial version.
 *
 * Verified against real samples (انتقال withdrawal + deposit, and two "برداشت" withdrawals):
 *
 *   بانك ملي ايران
 *   انتقال:2,011,000-
 *   حساب:60007
 *   مانده:2,433,816
 *   0818-18:03
 *
 * Rules:
 *  - Line 1 must be exactly the bank name (after normalisation).
 *  - "انتقال:" / "انتقالی:" / "برداشت:" / "واریز:" line carries the transaction amount; '-' = withdrawal,
 *    '+' = deposit. For "برداشت" the sign must be '-', for "واریز" it must be '+' (else manual review).
 *    The amount is taken ONLY from this line.
 *    "برداشت:" was verified on two more real samples (v0.10.1); "واریز:" is the symmetric form, NOT yet seen in a real SMS.
 *  - "مانده:" line is the balance after the transaction; never used as the amount.
 *  - "حساب:" is only an account identifier.
 *  - Last line "MMDD-HH:mm" is the date/time (no year in the SMS).
 *  - All amounts are in RIAL and are not converted.
 *  - Anything missing, ambiguous or unrecognised => NeedsReview (never silently registered).
 *
 * Other Bank Melli SMS layouts have NOT been verified; they will land in manual review.
 */
class NationalBankParser : BankParser {

    override val bankId = "MELLI"
    override val bankName = "بانک ملی ایران"

    override fun canHandle(lines: List<String>): Boolean =
        lines.isNotEmpty() && lines[0].replace(" ", "") == HEADER_NO_SPACES

    override fun parse(lines: List<String>): ParseResult {
        val reasons = mutableListOf<ReviewReason>()

        var transferSeen = false
        var balanceSeen = false
        var accountSeen = false
        var timeSeen = false

        var type: TransactionType? = null
        var amount: Long? = null
        var balance: Long? = null
        var account: String? = null
        var timeText: String? = null
        var month = 0; var day = 0; var hour = 0; var minute = 0

        for (line in lines.drop(1)) {
            val transfer = TRANSFER_LINE.matchEntire(line)
            val balanceLine = BALANCE_LINE.matchEntire(line)
            val accountLine = ACCOUNT_LINE.matchEntire(line)
            val time = TIME_LINE.matchEntire(line)
            when {
                transfer != null -> {
                    if (transferSeen) { reasons += ReviewReason.DUPLICATE_FIELD; continue }
                    transferSeen = true
                    // The label may name the direction itself ("برداشت" / "واریز"); then the sign MUST agree with it.
                    val expected = when (transfer.groupValues[1]) {
                        "برداشت" -> TransactionType.WITHDRAWAL
                        "واریز" -> TransactionType.DEPOSIT
                        else -> null
                    }
                    val a = parseAmount(transfer.groupValues[2])
                    when (a.error) {
                        null -> {}
                        AmountError.CONFLICTING_SIGN -> reasons += ReviewReason.CONFLICTING_SIGN
                        else -> reasons += ReviewReason.INVALID_AMOUNT
                    }
                    if (a.error == null) {
                        if (a.value == null || a.value == 0L) {
                            reasons += ReviewReason.INVALID_AMOUNT
                        } else {
                            amount = a.value
                            val signType = when (a.sign) {
                                '-' -> TransactionType.WITHDRAWAL
                                '+' -> TransactionType.DEPOSIT
                                else -> { reasons += ReviewReason.MISSING_SIGN; null }
                            }
                            if (signType != null) {
                                if (expected != null && expected != signType) reasons += ReviewReason.CONFLICTING_SIGN
                                else type = signType
                            }
                        }
                    }
                }
                balanceLine != null -> {
                    if (balanceSeen) { reasons += ReviewReason.DUPLICATE_FIELD; continue }
                    balanceSeen = true
                    val b = parseAmount(balanceLine.groupValues[1])
                    if (b.error != null || b.value == null) {
                        reasons += ReviewReason.INVALID_BALANCE
                    } else {
                        balance = if (b.sign == '-') -b.value else b.value
                    }
                }
                accountLine != null -> {
                    if (accountSeen) { reasons += ReviewReason.DUPLICATE_FIELD; continue }
                    accountSeen = true
                    val v = accountLine.groupValues[1].trim()
                    if (ACCOUNT_VALUE.matches(v)) account = v else reasons += ReviewReason.INVALID_ACCOUNT
                }
                time != null -> {
                    if (timeSeen) { reasons += ReviewReason.DUPLICATE_FIELD; continue }
                    timeSeen = true
                    timeText = line
                    month = time.groupValues[1].toInt(); day = time.groupValues[2].toInt()
                    hour = time.groupValues[3].toInt(); minute = time.groupValues[4].toInt()
                    if (month !in 1..12 || day !in 1..31 || hour !in 0..23 || minute !in 0..59) {
                        reasons += ReviewReason.INVALID_TIME
                    }
                }
                else -> reasons += ReviewReason.UNRECOGNIZED_LINE
            }
        }

        val partial = PartialTransaction(type, amount, balance, account, timeText)

        // Header matched but nothing transaction-like follows (e.g. OTP / info message).
        if (!transferSeen && !balanceSeen && !accountSeen && !timeSeen) {
            return ParseResult.NotTransaction(bankId)
        }

        if (!transferSeen) reasons += ReviewReason.MISSING_TRANSFER_LINE
        if (!balanceSeen) reasons += ReviewReason.MISSING_BALANCE
        if (!accountSeen) reasons += ReviewReason.MISSING_ACCOUNT
        if (!timeSeen) reasons += ReviewReason.MISSING_TIME

        if (reasons.isNotEmpty() || type == null || amount == null || balance == null || account == null || timeText == null) {
            return ParseResult.NeedsReview(bankId, reasons.distinct(), partial)
        }

        return ParseResult.Success(
            ParsedTransaction(
                bankId = bankId, bankName = bankName, type = type, amount = amount,
                currency = Currency.RIAL, balance = balance, accountId = account,
                month = month, day = day, hour = hour, minute = minute
            )
        )
    }

    private enum class AmountError { CONFLICTING_SIGN, INVALID }

    private data class AmountParse(val value: Long?, val sign: Char?, val error: AmountError?)

    /** Parses text like "2,011,000-", "+1,000,000", "- 500" into magnitude + sign. */
    private fun parseAmount(raw: String): AmountParse {
        var s = raw.trim()
        var lead: Char? = null
        var trail: Char? = null
        if (s.isNotEmpty() && (s.first() == '-' || s.first() == '+')) { lead = s.first(); s = s.drop(1).trim() }
        if (s.isNotEmpty() && (s.last() == '-' || s.last() == '+')) { trail = s.last(); s = s.dropLast(1).trim() }
        if (lead != null && trail != null) return AmountParse(null, null, AmountError.CONFLICTING_SIGN)
        if (!AMOUNT_DIGITS.matches(s)) return AmountParse(null, null, AmountError.INVALID)
        val value = s.replace(",", "").replace(".", "").toLongOrNull()
            ?: return AmountParse(null, null, AmountError.INVALID)
        return AmountParse(value, lead ?: trail, null)
    }

    private companion object {
        const val HEADER_NO_SPACES = "بانکملیایران"
        val TRANSFER_LINE = Regex("^(انتقال(?:ی)?|برداشت|واریز)\\s*:\\s*(.*)$")
        val BALANCE_LINE = Regex("^مانده\\s*:\\s*(.*)$")
        val ACCOUNT_LINE = Regex("^حساب\\s*:\\s*(.*)$")
        val TIME_LINE = Regex("^(\\d{2})/?(\\d{2})-(\\d{1,2}):(\\d{2})$")
        // Either plain digits or digits grouped by 3 with ',' or '.' (e.g. 2,011,000 / 2.011.000).
        val AMOUNT_DIGITS = Regex("^(?:\\d{1,3}(?:[,.]\\d{3})+|\\d{1,15})$")
        val ACCOUNT_VALUE = Regex("^[0-9*xX#]{1,30}$")
    }
}
