package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.money.Money
import ir.hesabyar.app.plan.*

/** Fixed costs and planning: bills/installments, savings goals, debts. All stored locally. */
class PlanActivity : Activity() {
    private lateinit var box: LinearLayout
    private val unit get() = DisplaySettings.get(this)
    private fun fa(s: String) = AmountFormatter.toPersianDigits(s)
    private fun money(rial: Long) = AmountFormatter.format(rial, Currency.RIAL, unit)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.page(this)
        root.addView(Ui.title(this, "برنامه‌ریزی مالی", "قبض و قسط، هدف پس‌انداز و بدهی/طلب. همه‌چیز فقط روی همین گوشی می‌ماند."))
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(box) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)
        render()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun section(title: String, addLabel: String, onAdd: () -> Unit): LinearLayout {
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Ui.dp(this@PlanActivity, 14), 0, Ui.dp(this@PlanActivity, 6))
        }
        head.addView(Ui.text(this, title, 16f, Ui.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(Ui.soft(this, addLabel) { onAdd() })
        box.addView(head)
        return head
    }

    private fun empty(msg: String) = box.addView(Ui.glass(this, 14).apply { addView(Ui.text(context, msg, 12f, Ui.muted)) }, Ui.margins(this, 0, 8))

    private fun render() {
        box.removeAllViews()
        val now = System.currentTimeMillis()
        val today = Jx.dayOf(now)
        val data = PlanStore.load(this)

        // ---------- bills ----------
        section("قبض‌ها و قسط‌ها", "＋ افزودن") { addBill() }
        if (data.bills.isEmpty()) empty("هنوز موردی ثبت نشده. مثلاً قسط وام، اجاره، قبض برق…")
        BillCalc.all(data.bills, today).forEach { d ->
            val b = d.bill
            val card = Ui.glass(this, 14)
            card.addView(Ui.text(this, b.title, 15f, Ui.ink, true))
            val whenText = when {
                d.overdue -> "${fa("${-d.daysUntil}")} روز از سررسید گذشته"
                d.daysUntil == 0 -> "سررسید امروز است"
                d.nextMonth -> "این ماه پرداخت شد • سررسید بعدی ${fa("${d.daysUntil}")} روز دیگر"
                else -> "${fa("${d.daysUntil}")} روز تا سررسید"
            }
            card.addView(Ui.text(this, "${money(b.amountRial)} • هر ماه روز ${fa("${b.dayOfMonth}")} • $whenText", 12f, if (d.overdue) Ui.red else Ui.muted))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            if (!d.nextMonth) row.addView(Ui.primary(this, "پرداخت شد") { markPaid(b) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Ui.soft(this, "حذف") { confirmDelete("«${b.title}»") { PlanStore.removeBill(this, b.id); render() } }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row, Ui.margins(this, 8, 0))
            box.addView(card, Ui.margins(this, 0, 8))
        }

        // ---------- goals ----------
        section("هدف‌های پس‌انداز", "＋ افزودن") { addGoal() }
        if (data.goals.isEmpty()) empty("مثلاً «سفر»، «خرید گوشی»، «صندوق اضطراری». مبلغ هدف و (اختیاری) ماه رسیدن به آن را وارد کن.")
        val monthKey = Jx.monthKey(today)
        data.goals.forEach { g ->
            val card = Ui.glass(this, 14)
            card.addView(Ui.text(this, g.title, 15f, Ui.ink, true))
            card.addView(PlanUi.bar(this, GoalCalc.percent(g), if (GoalCalc.done(g)) Ui.green else Ui.purple), Ui.margins(this, 8, 4))
            card.addView(Ui.text(this, "${money(g.savedRial)} از ${money(g.targetRial)} (${fa("${GoalCalc.percent(g)}")}٪)", 12f, Ui.muted))
            when {
                GoalCalc.done(g) -> card.addView(Ui.text(this, "به هدف رسیدی 🎉", 12f, Ui.green, true))
                GoalCalc.monthlyNeeded(g, monthKey) != null -> card.addView(Ui.text(this,
                    "برای رسیدن تا ${fa(PlanInput.monthKeyText(g.deadlineMonthKey))} هر ماه حدود ${money(GoalCalc.monthlyNeeded(g, monthKey)!!)} کنار بگذار.", 12f, Ui.ink))
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            row.addView(Ui.primary(this, "افزودن پس‌انداز") { addSaving(g) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Ui.soft(this, "حذف") { confirmDelete("هدف «${g.title}»") { PlanStore.removeGoal(this, g.id); render() } }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row, Ui.margins(this, 8, 0))
            box.addView(card, Ui.margins(this, 0, 8))
        }

        // ---------- debts ----------
        section("بدهی و طلب", "＋ افزودن") { addDebt() }
        val sum = DebtCalc.summary(data.debts)
        if (data.debts.isEmpty()) empty("پول قرض‌گرفته یا قرض‌داده را اینجا ثبت کن تا فراموش نشود.")
        else box.addView(Ui.glass(this, 14).apply {
            addView(Ui.text(context, "بدهکاری: ${money(sum.iOweRial)}", 13f, Ui.red, true))
            addView(Ui.text(context, "طلبکاری: ${money(sum.owedToMeRial)}", 13f, Ui.green, true))
        }, Ui.margins(this, 0, 8))
        val todayKey = Jx.dateKey(today)
        data.debts.sortedWith(compareBy({ it.settled }, { if (it.dueKey == 0) Int.MAX_VALUE else it.dueKey })).forEach { d ->
            val card = Ui.glass(this, 14)
            card.addView(Ui.text(this, "${if (d.iOwe) "بدهی به" else "طلب از"} ${d.person}", 15f, Ui.ink, true))
            val late = DebtCalc.overdue(d, todayKey)
            card.addView(Ui.text(this, money(d.amountRial) + (if (d.dueKey > 0) " • سررسید ${fa(PlanInput.dateKeyText(d.dueKey))}" else "") +
                (if (d.settled) " • تسویه شده" else if (late) " • سررسید گذشته" else ""), 12f, if (late) Ui.red else Ui.muted))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            if (!d.settled) row.addView(Ui.primary(this, "تسویه شد") { PlanStore.updateDebt(this, d.copy(settled = true)); render() }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Ui.soft(this, "حذف") { confirmDelete("این مورد") { PlanStore.removeDebt(this, d.id); render() } }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row, Ui.margins(this, 8, 0))
            box.addView(card, Ui.margins(this, 0, 8))
        }
        box.addView(View(this), LinearLayout.LayoutParams(-1, Ui.dp(this, 24)))
        ComboWidget.updateAll(this)
    }

    private fun confirmDelete(what: String, action: () -> Unit) {
        AlertDialog.Builder(this).setTitle("حذف $what؟").setNegativeButton("انصراف", null)
            .setPositiveButton("حذف") { _, _ -> action() }.show()
    }

    private fun field(hint: String, numeric: Boolean) = EditText(this).apply {
        this.hint = hint; if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
    }

    private fun panel(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(context, 20), Ui.dp(context, 8), Ui.dp(context, 20), 0); v.forEach { addView(it) }
    }

    private fun addBill() {
        val title = field("عنوان (مثلاً قسط وام)", false)
        val amount = field("مبلغ به ${unit.labelFa}", true)
        val day = field("روز سررسید در هر ماه (۱ تا ۳۱)", true)
        AlertDialog.Builder(this).setTitle("قبض / قسط جدید").setView(panel(title, amount, day)).setNegativeButton("لغو", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val a = PlanInput.amount(amount.text.toString()); val d = PlanInput.dayOfMonth(day.text.toString())
                val t = title.text.toString().trim()
                if (t.isEmpty() || a == null || d == null) toast("عنوان، مبلغ و روز (۱ تا ۳۱) را درست وارد کن")
                else { PlanStore.addBill(this, t, Money.toRial(a, unit), d); render() }
            }.show()
    }

    private fun markPaid(b: Bill) {
        AlertDialog.Builder(this).setTitle("«${b.title}» پرداخت شد")
            .setMessage("می‌خواهی این مبلغ (${money(b.amountRial)}) به‌عنوان یک هزینه هم ثبت شود؟ اگر پیامک بانکی‌اش خودکار ثبت می‌شود، «فقط علامت‌گذاری» را بزن تا دو بار حساب نشود.")
            .setNegativeButton("لغو", null)
            .setNeutralButton("فقط علامت‌گذاری") { _, _ -> PlanStore.updateBill(this, BillCalc.markPaid(b, Jx.dayOf(System.currentTimeMillis()))); render() }
            .setPositiveButton("ثبت هزینه هم") { _, _ ->
                TransactionStore.add(this, b.title, b.amountRial, false, Currency.RIAL)
                PlanStore.updateBill(this, BillCalc.markPaid(b, Jx.dayOf(System.currentTimeMillis())))
                PendingTransactionsWidget.updateAll(this); render()
            }.show()
    }

    private fun addGoal() {
        val title = field("عنوان هدف", false)
        val target = field("مبلغ هدف به ${unit.labelFa}", true)
        val deadline = field("ماه رسیدن به هدف (اختیاری، مثل ۱۴۰۶/۰۳)", false)
        AlertDialog.Builder(this).setTitle("هدف پس‌انداز جدید").setView(panel(title, target, deadline)).setNegativeButton("لغو", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val a = PlanInput.amount(target.text.toString()); val t = title.text.toString().trim()
                val dtext = deadline.text.toString().trim()
                val dk = if (dtext.isEmpty()) -1 else PlanInput.monthKey(dtext)
                if (t.isEmpty() || a == null) toast("عنوان و مبلغ هدف را وارد کن")
                else if (dk == null) toast("ماه را مثل ۱۴۰۶/۰۳ وارد کن")
                else { PlanStore.addGoal(this, t, Money.toRial(a, unit), dk); render() }
            }.show()
    }

    private fun addSaving(g: Goal) {
        val amount = field("مبلغ پس‌انداز به ${unit.labelFa}", true)
        AlertDialog.Builder(this).setTitle("افزودن به «${g.title}»").setView(panel(amount)).setNegativeButton("لغو", null)
            .setPositiveButton("افزودن") { _, _ ->
                val a = PlanInput.amount(amount.text.toString())
                if (a == null) toast("مبلغ معتبر وارد کن") else { PlanStore.updateGoal(this, g.copy(savedRial = g.savedRial + Money.toRial(a, unit))); render() }
            }.show()
    }

    private fun addDebt() {
        val person = field("نام شخص", false)
        val amount = field("مبلغ به ${unit.labelFa}", true)
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@PlanActivity, android.R.layout.simple_spinner_dropdown_item, listOf("من بدهکارم", "او به من بدهکار است")) }
        val due = field("تاریخ سررسید (اختیاری، مثل ۱۴۰۵/۰۹/۱۵)", false)
        AlertDialog.Builder(this).setTitle("بدهی / طلب جدید").setView(panel(person, amount, type, due)).setNegativeButton("لغو", null)
            .setPositiveButton("ذخیره") { _, _ ->
                val a = PlanInput.amount(amount.text.toString()); val p = person.text.toString().trim()
                val dtext = due.text.toString().trim()
                val dk = if (dtext.isEmpty()) 0 else PlanInput.dateKey(dtext)
                if (p.isEmpty() || a == null) toast("نام و مبلغ را وارد کن")
                else if (dk == null) toast("تاریخ را مثل ۱۴۰۵/۰۹/۱۵ وارد کن")
                else { PlanStore.addDebt(this, p, Money.toRial(a, unit), type.selectedItemPosition == 0, dk); render() }
            }.show()
    }
}
