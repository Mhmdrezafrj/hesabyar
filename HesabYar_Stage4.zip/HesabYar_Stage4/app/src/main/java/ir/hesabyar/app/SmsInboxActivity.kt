package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.money.AmountFormatter
import ir.hesabyar.app.money.Currency
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SmsInboxActivity : Activity() {
    private val ink = Color.rgb(45, 36, 79)
    private lateinit var rows: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }
    override fun onResume() { super.onResume(); if (::rows.isInitialized) render() }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(18,24,18,18); setBackgroundColor(Color.rgb(246,242,255)) }
        root.addView(TextView(this).apply { text = "صندوق پیامک‌های بانکی"; textSize = 22f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "پیامک‌های بانک ملی با فرمت تأییدشده خودکار به تراکنش تبدیل می‌شوند؛ پیامک‌های نامطمئن برای بررسی دستی نگه داشته می‌شوند. سایر بانک‌ها هنوز تراکنش خودکار ایجاد نمی‌کنند."; textSize = 13f; setTextColor(Color.DKGRAY); setPadding(0,8,0,12) })
        root.addView(Button(this).apply { text = "ثبت دستی متن پیامک"; setOnClickListener { showManualSmsDialog() } })
        root.addView(Button(this).apply { text = "پردازش مجدد پیامک‌های ذخیره‌شده"; setOnClickListener { reprocess() } })
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(rows) }, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }

    private fun render() {
        rows.removeAllViews()
        val messages = SmsInboxStore(this).use { it.latest(300) }
        if (messages.isEmpty()) rows.addView(TextView(this).apply { text = "هنوز پیامک مالی ذخیره نشده است."; gravity = Gravity.CENTER; setPadding(8,40,8,40); setTextColor(ink) })
        val dateFormat = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale("fa"))
        messages.forEach { sms ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,12,14,12); setBackgroundColor(Color.WHITE); layoutDirection = View.LAYOUT_DIRECTION_RTL }
            card.addView(TextView(this).apply { text = sms.sender; textSize = 13f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply { text = dateFormat.format(Date(sms.receivedAt)) + " • " + if (sms.source == "LIVE_SMS") "دریافت جدید" else if (sms.source == "HISTORY_IMPORT") "واردشده از پیامک‌های قبلی" else "ثبت دستی"; textSize = 10f; setTextColor(Color.GRAY); setPadding(0,3,0,6) })
            card.addView(TextView(this).apply { text = statusText(sms); textSize = 13f; setTextColor(Color.rgb(90,60,160)); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0,0,0,4) })
            card.addView(TextView(this).apply { text = sms.body; textSize = 13f; setTextColor(Color.rgb(55,49,75)) })
            card.addView(Button(this).apply { text = "حذف از صندوق"; setOnClickListener { SmsInboxStore(this@SmsInboxActivity).use { store -> store.delete(sms.id) }; render() } })
            rows.addView(card, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = 10 })
        }
    }

    private fun statusText(sms: RawSms): String {
        val unit = DisplaySettings.get(this)
        return when (sms.parseStatus) {
            "PARSED" -> {
                val kind = if (sms.txType == "DEPOSIT") "واریز" else "برداشت"
                val money = sms.amount?.let { AmountFormatter.format(it, Currency.fromCode(sms.currency), unit) } ?: ""
                val bal = sms.balance?.let { " • مانده: " + AmountFormatter.format(it, Currency.fromCode(sms.currency), unit) } ?: ""
                "✓ تراکنش ثبت‌شده: $kind $money$bal"
            }
            "REVIEW" -> "⚠ نیازمند بررسی دستی (ثبت خودکار انجام نشد): " + reasonsText(sms.reviewReasons)
            "DUPLICATE" -> "تکراری (قبلاً ثبت شده)"
            "NOT_TRANSACTION" -> "غیرتراکنشی (ردشده)"
            else -> "فرمت ناشناخته؛ تراکنش خودکار ثبت نشد"
        }
    }

    private fun reasonsText(codes: String?): String {
        val labels = mapOf(
            "MISSING_TRANSFER_LINE" to "خط مبلغ انتقال نیست", "MISSING_SIGN" to "علامت + یا − ندارد",
            "CONFLICTING_SIGN" to "علامت‌ها متناقض‌اند", "INVALID_AMOUNT" to "مبلغ نامعتبر",
            "MISSING_BALANCE" to "مانده ندارد", "INVALID_BALANCE" to "مانده نامعتبر",
            "MISSING_ACCOUNT" to "حساب ندارد", "INVALID_ACCOUNT" to "حساب نامعتبر",
            "MISSING_TIME" to "تاریخ/ساعت ندارد", "INVALID_TIME" to "تاریخ/ساعت نامعتبر",
            "DUPLICATE_FIELD" to "بخش تکراری", "UNRECOGNIZED_LINE" to "خط ناشناخته",
            "AMBIGUOUS_BANK" to "بانک مبهم"
        )
        return codes.orEmpty().split(",").filter { it.isNotBlank() }.joinToString("، ") { labels[it] ?: it }
    }

    private fun reprocess() {
        try {
            val r = SmsInboxStore(this).use { it.reprocessStored() }
            PendingTransactionsWidget.updateAll(this)
            Toast.makeText(this, "بررسی‌شده: ${r.scanned} • تراکنش جدید: ${r.newTransactions} • نیازمند بررسی: ${r.review} • تکراری: ${r.duplicates}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در پردازش مجدد", Toast.LENGTH_LONG).show()
        }
        render()
    }

    private fun showManualSmsDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,4,18,0) }
        val sender = EditText(this).apply { hint = "شماره یا نام فرستنده (اختیاری)" }
        val body = EditText(this).apply { hint = "متن کامل پیامک بانکی را وارد یا جای‌گذاری کن"; minLines = 4; gravity = Gravity.TOP }
        panel.addView(sender); panel.addView(body)
        AlertDialog.Builder(this).setTitle("ثبت متن پیامک").setView(panel)
            .setNegativeButton("لغو", null).setPositiveButton("ذخیره") { _, _ ->
                val content = body.text.toString().trim()
                if (content.isNotBlank()) {
                    SmsInboxStore(this).use { it.insertCandidate(sender.text.toString(), content, System.currentTimeMillis(), "MANUAL") }
                    PendingTransactionsWidget.updateAll(this)
                    render()
                } else Toast.makeText(this, "متن پیامک خالی است", Toast.LENGTH_SHORT).show()
            }.show()
    }
}
