package ir.hesabyar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/** Ring chart with rounded segments and a text in the middle. Plain Canvas drawing, no libraries. */
class DonutView(context: Context) : View(context) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.argb(34, 124, 92, 255) }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD; color = Ui.ink }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Ui.muted }
    private val rect = RectF()
    private var fractions: List<Float> = emptyList()
    private var colors: List<Int> = emptyList()
    private var bigText = ""
    private var smallText = ""

    fun setData(fractions: List<Float>, colors: List<Int>, bigText: String, smallText: String) {
        this.fractions = fractions; this.colors = colors; this.bigText = bigText; this.smallText = smallText
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h)
        if (s <= 0f) return
        val stroke = s * 0.13f
        track.strokeWidth = stroke; arc.strokeWidth = stroke
        val inset = stroke / 2f + 2f
        rect.set((w - s) / 2f + inset, (h - s) / 2f + inset, (w + s) / 2f - inset, (h + s) / 2f - inset)
        val radius = rect.width() / 2f
        canvas.drawArc(rect, 0f, 360f, false, track)
        // A rounded cap sticks out by stroke/2 on each end; leave room for it plus a small gap.
        val capDeg = Math.toDegrees((stroke / 2f / radius).toDouble()).toFloat()
        val gapDeg = if (fractions.size > 1) 5f else 0f
        var start = -90f
        fractions.forEachIndexed { i, f ->
            val sweep = f * 360f
            val drawn = if (fractions.size > 1) (sweep - gapDeg - 2f * capDeg).coerceAtLeast(0.5f) else 359.9f
            arc.color = colors[i % colors.size]
            val from = if (fractions.size > 1) start + gapDeg / 2f + capDeg else start
            canvas.drawArc(rect, from, drawn, false, arc)
            start += sweep
        }
        bigPaint.textSize = s * 0.2f
        smallPaint.textSize = s * 0.095f
        canvas.drawText(bigText, w / 2f, h / 2f + bigPaint.textSize * 0.1f, bigPaint)
        canvas.drawText(smallText, w / 2f, h / 2f + bigPaint.textSize * 0.1f + smallPaint.textSize * 1.5f, smallPaint)
    }
}

/** Two smooth lines (expense, income) over the last months; oldest month on the RIGHT (Persian reading direction). */
class TrendView(context: Context) : View(context) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(40, 112, 103, 140) }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = Ui.muted }
    private val path = Path()
    private var expense: List<Long> = emptyList()
    private var income: List<Long> = emptyList()
    private var labels: List<String> = emptyList()

    fun setData(expense: List<Long>, income: List<Long>, labels: List<String>) {
        this.expense = expense; this.income = income; this.labels = labels
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val n = labels.size
        if (n < 2 || expense.size != n || income.size != n) return
        val w = width.toFloat(); val h = height.toFloat()
        val padX = Ui.dp(context, 18).toFloat()
        val top = Ui.dp(context, 10).toFloat()
        val bottom = h - Ui.dp(context, 22).toFloat()
        val chartH = (bottom - top).coerceAtLeast(1f)
        val maxV = maxOf(1L, expense.maxOrNull() ?: 0L, income.maxOrNull() ?: 0L).toFloat()
        fun x(i: Int) = padX + (n - 1 - i) * (w - 2 * padX) / (n - 1)      // i = 0 is the OLDEST month -> right side
        fun y(v: Long) = top + (1f - v / maxV) * chartH

        gridPaint.strokeWidth = 1f
        for (g in 0..2) canvas.drawLine(padX, top + chartH * g / 2f, w - padX, top + chartH * g / 2f, gridPaint)

        fun draw(values: List<Long>, color: Int) {
            linePaint.color = color; linePaint.strokeWidth = Ui.dp(context, 3).toFloat()
            path.reset(); path.moveTo(x(0), y(values[0]))
            for (i in 1 until n) {
                val cx = (x(i - 1) + x(i)) / 2f
                path.cubicTo(cx, y(values[i - 1]), cx, y(values[i]), x(i), y(values[i]))
            }
            canvas.drawPath(path, linePaint)
            dotPaint.color = color
            canvas.drawCircle(x(n - 1), y(values[n - 1]), Ui.dp(context, 5).toFloat(), dotPaint)   // newest month
        }
        draw(income, Ui.green)
        draw(expense, Ui.purple)

        labelPaint.textSize = Ui.dp(context, 10).toFloat()
        for (i in 0 until n) canvas.drawText(labels[i], x(i), h - Ui.dp(context, 5).toFloat(), labelPaint)
    }
}
