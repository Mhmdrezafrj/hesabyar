package ir.hesabyar.app.report

enum class BudgetLevel { OK, WARNING, OVER }

data class BudgetStatus(val category: String, val spentRial: Long, val limitRial: Long, val level: BudgetLevel) {
    /** Percent of the limit used (can exceed 100). */
    val percent: Int get() = if (limitRial <= 0) 0 else (spentRial * 100 / limitRial).toInt()
}

/** Compares this month's spending per category with the user's monthly limits (all in Rial). */
object BudgetCalc {
    const val WARNING_PERCENT = 80

    fun levelFor(spent: Long, limit: Long): BudgetLevel = when {
        limit <= 0 -> BudgetLevel.OK
        spent > limit -> BudgetLevel.OVER
        spent * 100 >= limit * WARNING_PERCENT -> BudgetLevel.WARNING
        else -> BudgetLevel.OK
    }

    /** Most-used budgets first. Categories without a (positive) limit are ignored. */
    fun statuses(monthSpent: List<CategoryTotal>, limits: Map<String, Long>): List<BudgetStatus> {
        val spentBy = monthSpent.associate { it.category to it.totalRial }
        return limits.filter { it.value > 0 }
            .map { (cat, limit) -> val s = spentBy[cat] ?: 0L; BudgetStatus(cat, s, limit, levelFor(s, limit)) }
            .sortedByDescending { it.spentRial * 1000 / it.limitRial }
    }
}
