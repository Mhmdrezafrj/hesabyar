package ir.hesabyar.app.plan

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.money.Money
import ir.hesabyar.app.report.BudgetLevel
import ir.hesabyar.app.report.BudgetStatus
import ir.hesabyar.app.report.CategoryTotal
import ir.hesabyar.app.widget.Categories
import ir.hesabyar.app.widget.JalaliCalendar
import java.util.Calendar
import java.util.TimeZone

/** Jalali date helpers shared by the planning logic. */
object Jx {
    fun dayOf(ts: Long, zone: TimeZone = TimeZone.getDefault()): JalaliCalendar.Date {
        val c = Calendar.getInstance(zone); c.timeInMillis = ts
        return JalaliCalendar.fromGregorian(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }
    fun monthKey(d: JalaliCalendar.Date) = d.year * 12 + (d.month - 1)
    /** yyyymmdd style key, comparable. */
    fun dateKey(d: JalaliCalendar.Date) = d.year * 10000 + d.month * 100 + d.day
}

// ---------------------------------------------------------------- daily allowance & projection

data class SpendingPlan(
    val hasBudget: Boolean,
    val totalLimitRial: Long,
    val spentInBudgetsRial: Long,
    val remainingRial: Long,          // can be negative
    val daysLeft: Int,                // including today
    val dailyAllowanceRial: Long,     // 0 when nothing left
    val daysInMonth: Int,
    val dayOfMonth: Int,
    val projectedMonthExpenseRial: Long,   // all spending, linear projection
    val projectedOverBudget: Boolean
)

object BudgetPlanner {
    fun plan(
        today: JalaliCalendar.Date,
        limits: Map<String, Long>,
        monthExpenseByCategory: List<CategoryTotal>,
        monthExpenseRial: Long
    ): SpendingPlan {
        val positive = limits.filter { it.value > 0 }
        val total = positive.values.sum()
        val spentBy = monthExpenseByCategory.associate { it.category to it.totalRial }
        val spentBudgeted = positive.keys.sumOf { spentBy[it] ?: 0L }
        val remaining = total - spentBudgeted
        val len = JalaliCalendar.monthLength(today.year, today.month)
        val daysLeft = (len - today.day + 1).coerceAtLeast(1)
        val allowance = if (positive.isEmpty() || remaining <= 0) 0L else remaining / daysLeft
        val projected = if (today.day <= 0) monthExpenseRial else monthExpenseRial * len / today.day
        return SpendingPlan(
            hasBudget = positive.isNotEmpty(), totalLimitRial = total, spentInBudgetsRial = spentBudgeted,
            remainingRial = remaining, daysLeft = daysLeft, dailyAllowanceRial = allowance,
            daysInMonth = len, dayOfMonth = today.day, projectedMonthExpenseRial = projected,
            projectedOverBudget = positive.isNotEmpty() && projected > total && monthExpenseRial > 0
        )
    }
}

// ---------------------------------------------------------------- alerts

data class AlertItem(val key: String, val title: String, val body: String)

object AlertEngine {
    /** One alert per (month, category, level). Keys already in [alreadySent] are skipped. */
    fun budgetAlerts(statuses: List<BudgetStatus>, monthKey: Int, alreadySent: Set<String>): List<AlertItem> =
        statuses.filter { it.level != BudgetLevel.OK }.mapNotNull { s ->
            val key = "$monthKey|${s.category}|${s.level.name}"
            if (key in alreadySent) null
            else AlertItem(
                key,
                if (s.level == BudgetLevel.OVER) "بودجه «${s.category}» تمام شد" else "بودجه «${s.category}» رو به پایان است",
                "${s.percent}٪ از بودجه این ماه مصرف شده"
            )
        }

    const val MIN_SAMPLES = 10
    const val FACTOR = 3

    /** True when an expense is at least FACTOR× the average of earlier expenses (needs enough history). */
    fun isUnusualExpense(amountRial: Long, earlierExpensesRial: List<Long>): Boolean {
        if (earlierExpensesRial.size < MIN_SAMPLES) return false
        val avg = earlierExpensesRial.sum() / earlierExpensesRial.size
        return avg > 0 && amountRial >= avg * FACTOR
    }

    /** Keeps the sent-keys set small: only keys of the current month are retained. */
    fun prune(sent: Set<String>, monthKey: Int): Set<String> = sent.filter { it.startsWith("$monthKey|") }.toSet()
}

// ---------------------------------------------------------------- bills / installments

data class Bill(val id: String, val title: String, val amountRial: Long, val dayOfMonth: Int, val lastPaidMonthKey: Int = -1)

data class BillDue(val bill: Bill, val daysUntil: Int, val dueDay: Int, val nextMonth: Boolean) {
    val overdue get() = daysUntil < 0
}

object BillCalc {
    fun due(bill: Bill, today: JalaliCalendar.Date): BillDue {
        val key = Jx.monthKey(today)
        val len = JalaliCalendar.monthLength(today.year, today.month)
        val thisDue = bill.dayOfMonth.coerceIn(1, len)
        if (bill.lastPaidMonthKey != key) {
            return BillDue(bill, thisDue - today.day, thisDue, false)
        }
        val ny = if (today.month == 12) today.year + 1 else today.year
        val nm = if (today.month == 12) 1 else today.month + 1
        val nextDue = bill.dayOfMonth.coerceIn(1, JalaliCalendar.monthLength(ny, nm))
        return BillDue(bill, (len - today.day) + nextDue, nextDue, true)
    }

    /** Dues sorted by urgency (overdue first). */
    fun all(bills: List<Bill>, today: JalaliCalendar.Date): List<BillDue> =
        bills.map { due(it, today) }.sortedBy { it.daysUntil }

    fun upcoming(bills: List<Bill>, today: JalaliCalendar.Date, withinDays: Int): List<BillDue> =
        all(bills, today).filter { it.daysUntil <= withinDays }

    fun markPaid(bill: Bill, today: JalaliCalendar.Date) = bill.copy(lastPaidMonthKey = Jx.monthKey(today))
}

// ---------------------------------------------------------------- savings goals

data class Goal(val id: String, val title: String, val targetRial: Long, val savedRial: Long, val deadlineMonthKey: Int = -1)

object GoalCalc {
    fun percent(g: Goal): Int = if (g.targetRial <= 0) 0 else (g.savedRial * 100 / g.targetRial).coerceIn(0L, 100L).toInt()
    fun remaining(g: Goal): Long = (g.targetRial - g.savedRial).coerceAtLeast(0L)
    fun done(g: Goal) = g.targetRial > 0 && g.savedRial >= g.targetRial

    /** Amount to save per month to reach the goal by its deadline month (inclusive); null without deadline / when done. */
    fun monthlyNeeded(g: Goal, thisMonthKey: Int): Long? {
        if (g.deadlineMonthKey < 0 || done(g)) return null
        val months = (g.deadlineMonthKey - thisMonthKey + 1).coerceAtLeast(1)
        return (remaining(g) + months - 1) / months
    }
}

// ---------------------------------------------------------------- debts

data class Debt(val id: String, val person: String, val amountRial: Long, val iOwe: Boolean, val dueKey: Int = 0, val settled: Boolean = false)

data class DebtSummary(val iOweRial: Long, val owedToMeRial: Long)

object DebtCalc {
    fun summary(list: List<Debt>): DebtSummary {
        val open = list.filter { !it.settled }
        return DebtSummary(open.filter { it.iOwe }.sumOf { it.amountRial }, open.filter { !it.iOwe }.sumOf { it.amountRial })
    }
    fun overdue(d: Debt, todayKey: Int) = !d.settled && d.dueKey > 0 && d.dueKey < todayKey
    fun dueSoon(list: List<Debt>, todayKey: Int, soonKey: Int) =
        list.filter { !it.settled && it.dueKey > 0 && it.dueKey <= soonKey }.sortedBy { it.dueKey }
}

// ---------------------------------------------------------------- accounts overview

data class AccountBalance(val accountId: String, val bank: String, val balanceRial: Long, val timestamp: Long)

object AccountsOverview {
    /** Latest known balance per account (from SMS "مانده"). Rows without account or balance are ignored. */
    fun balances(all: List<Transaction>): List<AccountBalance> =
        all.filter { it.accountId.isNotBlank() && it.balance != null && it.timestamp > 0 }
            .groupBy { it.accountId }
            .map { (acc, rows) ->
                val last = rows.maxByOrNull { it.timestamp }!!
                AccountBalance(acc, last.bank, Money.toRial(last.balance!!, last.currencyType), last.timestamp)
            }
            .sortedByDescending { it.balanceRial }

    fun total(b: List<AccountBalance>) = b.sumOf { it.balanceRial }
}

// ---------------------------------------------------------------- insights

data class CategoryChange(val category: String, val thisRial: Long, val prevRial: Long) {
    val percent: Int get() = if (prevRial <= 0) 0 else (((thisRial - prevRial) * 100.0) / prevRial).let { Math.round(it).toInt() }
}

data class InsightData(
    val topIncrease: CategoryChange?,
    val topDecrease: CategoryChange?,
    val busiestWeekday: Int?,          // java.util.Calendar.SATURDAY..FRIDAY constant
    val biggestExpense: Transaction?,  // this month
    val avgDailyRial: Long             // this month so far
)

object Insights {
    /** Calendar day-of-week -> Persian name. */
    fun weekdayName(dow: Int): String = when (dow) {
        Calendar.SATURDAY -> "شنبه"; Calendar.SUNDAY -> "یکشنبه"; Calendar.MONDAY -> "دوشنبه"
        Calendar.TUESDAY -> "سه‌شنبه"; Calendar.WEDNESDAY -> "چهارشنبه"; Calendar.THURSDAY -> "پنجشنبه"
        else -> "جمعه"
    }

    private const val MIN_CHANGE_RIAL = 1_000_000L   // ignore tiny categories (100k toman)

    fun compute(all: List<Transaction>, now: Long, zone: TimeZone = TimeZone.getDefault()): InsightData {
        val today = Jx.dayOf(now, zone)
        val key = Jx.monthKey(today)
        val exp = all.filter { !it.isIncome && it.timestamp > 0 && it.category != Categories.TRANSFER }
        fun rial(t: Transaction) = Money.toRial(t.amount, t.currencyType)
        fun label(t: Transaction) = if (t.category.isBlank()) Categories.UNCATEGORIZED_LABEL else t.category

        val thisM = exp.filter { Jx.monthKey(Jx.dayOf(it.timestamp, zone)) == key }
        val prevM = exp.filter { Jx.monthKey(Jx.dayOf(it.timestamp, zone)) == key - 1 }
        val thisBy = thisM.groupBy { label(it) }.mapValues { e -> e.value.sumOf { rial(it) } }
        val prevBy = prevM.groupBy { label(it) }.mapValues { e -> e.value.sumOf { rial(it) } }
        val changes = (thisBy.keys + prevBy.keys).map { CategoryChange(it, thisBy[it] ?: 0L, prevBy[it] ?: 0L) }
            .filter { it.prevRial >= MIN_CHANGE_RIAL && maxOf(it.thisRial, it.prevRial) >= MIN_CHANGE_RIAL }
        val inc = changes.filter { it.thisRial > it.prevRial }.maxByOrNull { it.thisRial - it.prevRial }
        val dec = changes.filter { it.thisRial < it.prevRial }.maxByOrNull { it.prevRial - it.thisRial }

        val since = now - 90L * 86_400_000L
        val recent = exp.filter { it.timestamp in since..now }
        val byDow = HashMap<Int, Long>()
        recent.forEach {
            val c = Calendar.getInstance(zone); c.timeInMillis = it.timestamp
            byDow[c.get(Calendar.DAY_OF_WEEK)] = (byDow[c.get(Calendar.DAY_OF_WEEK)] ?: 0L) + rial(it)
        }
        val busiest = if (recent.size < 7) null else byDow.maxByOrNull { it.value }?.key

        val total = thisM.sumOf { rial(it) }
        return InsightData(inc, dec, busiest, thisM.maxByOrNull { rial(it) }, if (today.day <= 0) 0L else total / today.day)
    }
}

// ---------------------------------------------------------------- CSV

object CsvExport {
    const val HEADER = "تاریخ شمسی,ساعت,عنوان,بانک,دسته,نوع,مبلغ (ریال),مانده (ریال)"

    fun escape(s: String): String {
        // neutralise spreadsheet formula injection, then quote when needed
        val safe = if (s.isNotEmpty() && s[0] in "=+-@") "'$s" else s
        return if (safe.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + safe.replace("\"", "\"\"") + "\"" else safe
    }

    /** UTF-8 text with BOM (so Excel reads Persian), newest first. Amounts are always Rial, expenses negative. */
    fun build(all: List<Transaction>, zone: TimeZone = TimeZone.getDefault()): String {
        val sb = StringBuilder("﻿").append(HEADER).append("\r\n")
        all.sortedByDescending { it.timestamp }.forEach { t ->
            val date: String; val time: String
            if (t.timestamp > 0) {
                val d = Jx.dayOf(t.timestamp, zone)
                date = "%04d/%02d/%02d".format(d.year, d.month, d.day)
                val c = Calendar.getInstance(zone); c.timeInMillis = t.timestamp
                time = "%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
            } else { date = ""; time = "" }
            val r = Money.toRial(t.amount, t.currencyType)
            val signed = if (t.isIncome) r else -r
            sb.append(listOf(
                date, time, escape(t.title), escape(t.bank),
                escape(if (t.category.isBlank()) Categories.UNCATEGORIZED_LABEL else t.category),
                if (t.category == Categories.TRANSFER) "انتقال" else if (t.isIncome) "درآمد" else "هزینه",
                signed.toString(),
                t.balance?.let { Money.toRial(it, t.currencyType).toString() } ?: ""
            ).joinToString(",")).append("\r\n")
        }
        return sb.toString()
    }
}
