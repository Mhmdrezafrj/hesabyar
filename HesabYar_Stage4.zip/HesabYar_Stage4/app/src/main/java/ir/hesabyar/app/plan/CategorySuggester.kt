package ir.hesabyar.app.plan

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.money.Money

data class CategorySuggestion(val category: String, val matches: Int, val basis: String)

/**
 * Suggests (never applies) a category for an uncategorised transaction, learning only from the user's own earlier choices:
 *  1) same type + same amount + same title      (e.g. a monthly installment)  -> needs >= 2 earlier matches
 *  2) same type + same, non-generic title        (e.g. a manual "نانوایی")      -> needs >= 2 earlier matches
 * The winning category must hold at least 2/3 of the matches. Bank-SMS titles like "برداشت از حساب …" are generic
 * and are only matched together with the exact amount.
 */
object CategorySuggester {
    private const val MIN_MATCHES = 2

    private fun norm(s: String) = s.trim().replace(Regex("\\s+"), " ").lowercase()
    private fun generic(title: String): Boolean {
        val t = norm(title)
        return t.isEmpty() || t.startsWith("واریز") || t.startsWith("برداشت") || t.startsWith("انتقال")
    }

    fun suggest(tx: Transaction, history: List<Transaction>): CategorySuggestion? {
        val learned = history.filter { it.id != tx.id && it.category.isNotBlank() && it.isIncome == tx.isIncome }
        val title = norm(tx.title)
        val rial = Money.toRial(tx.amount, tx.currencyType)

        val byAmount = learned.filter { norm(it.title) == title && Money.toRial(it.amount, it.currencyType) == rial }
        pick(byAmount)?.let { (c, n) -> return CategorySuggestion(c, n, "AMOUNT") }

        if (!generic(tx.title)) {
            val byTitle = learned.filter { norm(it.title) == title }
            pick(byTitle)?.let { (c, n) -> return CategorySuggestion(c, n, "TITLE") }
        }
        return null
    }

    private fun pick(matches: List<Transaction>): Pair<String, Int>? {
        if (matches.size < MIN_MATCHES) return null
        val top = matches.groupBy { it.category }.maxByOrNull { it.value.size } ?: return null
        return if (top.value.size >= MIN_MATCHES && top.value.size * 3 >= matches.size * 2) top.key to top.value.size else null
    }
}
