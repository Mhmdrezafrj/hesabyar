package ir.hesabyar.app.parser

import ir.hesabyar.app.money.Currency

/**
 * What the app could work out from an SMS that no verified parser handled.
 * It is only a SUGGESTION: the user confirms it with one tap; nothing here registers a transaction by itself.
 */
data class Suggestion(
    val bankName: String?,
    val type: TransactionType?,
    val amount: Long?,          // positive, exactly as written in the SMS
    val balance: Long?,
    val account: String?,
    val timeText: String?,
    val currencyHint: Currency?, // only when the SMS itself says ریال or تومان
    val notes: List<String>      // Persian explanation of the signals used / problems found
) {
    /** Enough to offer "confirm and register": a clear direction and one clear amount. */
    val registrable: Boolean get() = type != null && amount != null && amount > 0
}

/**
 * Signal-based reader for bank SMS (pure, unit-tested). It looks for:
 *  - the bank name ("بانک …"),
 *  - an amount introduced by a direction word (برداشت/خرید/پرداخت/کسر ← withdrawal, واریز/سپرده/دریافت/افزایش ← deposit,
 *    انتقال/مبلغ ← direction from the sign), with a '+' or '-' on either side of the number,
 *  - the balance (مانده/موجودی), account/card, date-time, and the unit word (ریال/تومان).
 * Contradictions (sign vs. word, several different amounts) mean "no suggestion", never a guess.
 */
object SmsSignals {
    private val WITHDRAW = listOf("برداشت", "خرید", "پرداخت", "پرداختی", "کسر", "بدهکار")
    private val DEPOSIT = listOf("واریز", "واریزی", "سپرده", "دریافت", "افزایش", "بستانکار")
    private val NEUTRAL = listOf("انتقالی", "انتقال", "مبلغ", "تراکنش")

    private const val NUM = "(\\d{1,3}(?:[,.]\\d{3})+|\\d{1,15})(?!\\d|[,.]\\d)"
    private val labels = (WITHDRAW + DEPOSIT + NEUTRAL).sortedByDescending { it.length }.joinToString("|")
    private val amountRegex = Regex("($labels)(?:[ \\t]*مبلغ)?[ \\t]*[:：]?[ \\t]*([+-]?)[ \\t]*$NUM[ \\t]*([+-]?)(?:[ \\t]*(ریال|تومان))?")
    private val balanceRegex = Regex("(?:باقی‌مانده|باقیمانده|مانده(?:[ \\t]*حساب)?|موجودی)[ \\t]*[:：]?[ \\t]*([+-]?)[ \\t]*$NUM[ \\t]*([+-]?)")
    private val accountRegex = Regex("(?:شماره[ \\t]*)?(?:حساب|کارت)[ \\t]*[:：]?[ \\t]*([0-9*xX#\\-]{3,30})")
    private val timeRegexes = listOf(
        Regex("\\b\\d{2}/?\\d{2}-\\d{1,2}:\\d{2}\\b"),
        Regex("\\b\\d{4}/\\d{1,2}/\\d{1,2}[ \\t-]*\\d{1,2}:\\d{2}\\b"),
        Regex("\\b\\d{1,2}:\\d{2}\\b")
    )
    private val bankInLine = Regex("بانک[ \\t]+[\\u0600-\\u06FF]+(?:[ \\t]+[\\u0600-\\u06FF]+)?")

    fun analyze(sender: String, body: String): Suggestion? {
        val text = TextNormalizer.normalize(body)
        val amounts = amountRegex.findAll(text).toList()
        val balanceMatch = balanceRegex.find(text)
        if (amounts.isEmpty()) return null            // nothing that looks like a transaction amount
        val notes = mutableListOf<String>()

        // ---- amount and direction ----
        data class Hit(val value: Long, val dir: TransactionType?, val conflict: Boolean, val unit: Currency?)
        val hits = amounts.map { m ->
            val label = m.groupValues[1]
            val lead = m.groupValues[2]; val trail = m.groupValues[4]
            val value = m.groupValues[3].replace(",", "").replace(".", "").toLongOrNull() ?: 0L
            val labelDir = when (label) { in WITHDRAW -> TransactionType.WITHDRAWAL; in DEPOSIT -> TransactionType.DEPOSIT; else -> null }
            val signs = (lead + trail)
            val signDir = when {
                signs.length > 1 -> null
                signs == "-" -> TransactionType.WITHDRAWAL
                signs == "+" -> TransactionType.DEPOSIT
                else -> null
            }
            val bothSigns = signs.length > 1
            val conflict = bothSigns || (labelDir != null && signDir != null && labelDir != signDir)
            val unit = when (m.groupValues[5]) { "ریال" -> Currency.RIAL; "تومان" -> Currency.TOMAN; else -> null }
            Hit(value, labelDir ?: signDir, conflict, unit)
        }
        val distinctAmounts = hits.map { it.value }.filter { it > 0 }.distinct()
        val amount: Long? = when {
            distinctAmounts.size == 1 -> distinctAmounts[0]
            distinctAmounts.isEmpty() -> { notes += "مبلغ معتبر پیدا نشد"; null }
            else -> { notes += "چند مبلغ متفاوت در پیامک هست"; null }
        }
        var type: TransactionType? = null
        if (hits.any { it.conflict }) {
            notes += "علامت و کلمهٔ جهت (برداشت/واریز) با هم نمی‌خوانند"
        } else {
            val dirs = hits.mapNotNull { it.dir }.distinct()
            when (dirs.size) {
                1 -> type = dirs[0]
                2 -> notes += "هم برداشت و هم واریز در پیامک آمده"
                else -> {
                    // No label/sign gave a direction (e.g. only "مبلغ: 500"): look at the words, but say it is a guess.
                    val words = text.replace(balanceRegex, " ")
                    val w = WITHDRAW.any { words.contains(it) }; val d = DEPOSIT.any { words.contains(it) }
                    if (w && !d) { type = TransactionType.WITHDRAWAL; notes += "جهت از روی کلمات پیامک حدس زده شد (برداشت)" }
                    else if (d && !w) { type = TransactionType.DEPOSIT; notes += "جهت از روی کلمات پیامک حدس زده شد (واریز)" }
                    else notes += "جهت (برداشت یا واریز) مشخص نیست"
                }
            }
        }
        // ---- unit ----
        val unitWords = hits.mapNotNull { it.unit }.distinct()
        val unit = when {
            unitWords.size == 1 -> unitWords[0]
            unitWords.isNotEmpty() -> null
            text.contains("ریال") && !text.contains("تومان") -> Currency.RIAL
            text.contains("تومان") && !text.contains("ریال") -> Currency.TOMAN
            else -> null
        }

        // ---- balance, account, time, bank ----
        val balance = balanceMatch?.let { m ->
            val v = m.groupValues[2].replace(",", "").replace(".", "").toLongOrNull()
            if (v == null) null else if (m.groupValues[1] == "-" || m.groupValues[3] == "-") -v else v
        }
        val account = accountRegex.find(text)?.groupValues?.get(1)
        val timeText = timeRegexes.firstNotNullOfOrNull { it.find(text)?.value }
        val firstLines = text.split('\n').map { it.trim() }.filter { it.isNotEmpty() }.take(2)
        val bank = firstLines.firstNotNullOfOrNull { l -> if (l.length <= 40) bankInLine.find(l)?.value else null }
            ?: bankInLine.find(text)?.value
            ?: sender.takeIf { it.contains("بانک") }

        return Suggestion(bank?.trim(), type, amount, balance, account, timeText, unit, notes)
    }
}
