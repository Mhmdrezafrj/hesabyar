package ir.hesabyar.app.report

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.parser.TextNormalizer
import ir.hesabyar.app.widget.Categories

/**
 * Search used by the history screen. Every word of the query must match somewhere in the
 * title, bank, category, account, time text or the stored amount (digits, with or without separators).
 * Persian/Arabic digits and letter variants are treated as equal. Pure and unit-tested.
 */
object HistorySearch {
    private fun norm(s: String) = TextNormalizer.normalize(s).lowercase()
    private fun digitsOnly(s: String) = norm(s).filter { it.isDigit() }

    fun filter(all: List<Transaction>, query: String): List<Transaction> {
        val words = query.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return all
        return all.filter { t ->
            val haystack = norm(listOf(t.title, t.bank, if (t.category.isBlank()) Categories.UNCATEGORIZED_LABEL else t.category,
                t.accountId, t.time).joinToString(" "))
            val amountText = t.amount.toString()
            words.all { w ->
                val nw = norm(w)
                haystack.contains(nw) || (digitsOnly(w).isNotEmpty() && digitsOnly(w) == nw.filter { it.isDigit() }.takeIf { nw.all { c -> c.isDigit() || c == ',' || c == '٬' || c == '،' } }
                    && amountText.contains(digitsOnly(w)))
            }
        }
    }
}
