package ir.hesabyar.app

import android.content.Context
import org.json.JSONObject

/** Monthly spending limit per category, in Rial (stored only on this phone). Limit <= 0 = no budget. */
object BudgetStore {
    private const val PREFS = "hesabyar_budgets"
    private const val KEY = "limits"

    @Synchronized
    fun all(context: Context): Map<String, Long> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            val out = LinkedHashMap<String, Long>()
            val keys = o.keys()
            while (keys.hasNext()) { val k = keys.next(); val v = o.getLong(k); if (v > 0) out[k] = v }
            out
        } catch (e: Exception) { emptyMap() }
    }

    private fun save(context: Context, map: Map<String, Long>) {
        val o = JSONObject(); map.forEach { (k, v) -> if (v > 0) o.put(k, v) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    @Synchronized
    fun set(context: Context, category: String, limitRial: Long) {
        val m = LinkedHashMap(all(context))
        if (limitRial > 0) m[category] = limitRial else m.remove(category)
        save(context, m)
    }

    @Synchronized
    fun rename(context: Context, old: String, new: String) {
        val m = LinkedHashMap(all(context))
        val v = m.remove(old) ?: return
        m[new] = (m[new] ?: 0L).coerceAtLeast(v)
        save(context, m)
    }

    @Synchronized
    fun remove(context: Context, category: String) = set(context, category, 0L)
}
