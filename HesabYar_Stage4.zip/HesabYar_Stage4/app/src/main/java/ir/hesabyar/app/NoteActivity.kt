package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.EditText

/** Small dialog opened from the note widget: write or change the note, the widget refreshes, no app screen is shown. */
class NoteActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val input = EditText(this).apply {
            setText(NoteStore.text(this@NoteActivity)); hint = "چه چیزی نباید فراموش کنی؟ (هر خط یک مورد)"
            minLines = 4; maxLines = 10; setPadding(48, 24, 48, 24)
        }
        Ui.dialog(this).setTitle("یادداشت چسبان").setView(input)
            .setOnCancelListener { finish() }
            .setNegativeButton("لغو") { _, _ -> finish() }
            .setPositiveButton("ذخیره") { _, _ ->
                NoteStore.save(this, input.text.toString()); ComboWidget.updateAll(this); finish()
            }.show()
    }
}
