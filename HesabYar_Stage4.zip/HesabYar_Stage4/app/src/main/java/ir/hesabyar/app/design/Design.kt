package ir.hesabyar.app.design

/** Pure design model for the composite widgets: themes, personal settings, grid layout. Fully unit-tested. */

data class FontInfo(val id: String, val label: String)

/** Fonts the user can pick for a widget (files are in res/font; mapping lives in Fonts.kt). */
object FontCatalog {
    val all = listOf(
        FontInfo("hamishe", "همیشه (پیش‌فرض)"), FontInfo("sarvenaz", "سرو ناز"), FontInfo("rastin", "راستین"),
        FontInfo("lalezar", "لاله‌زار پلاس"), FontInfo("lalezar_grunge", "لاله‌زار گرانج"), FontInfo("lalezar_circle", "لاله‌زار دایره‌ای"),
        FontInfo("craft", "کرفت اولترا بلک")
    )
    const val DEFAULT = "hamishe"
    fun valid(id: String) = all.any { it.id == id }
}

enum class WidgetSize { SMALL, WIDE, LARGE }
enum class CardShape { ROUND, NOTCH, TICKET }

enum class BlockType(val label: String, val core: Boolean) {
    ALLOWANCE("سقف خرج امروز", true), URGENT("مهم‌ترین کار فوری", true), QUICK_ADD("ثبت سریع", true),
    RING("حلقهٔ بودجه", false), WEEK_BARS("هزینهٔ ۷ روز (میله)", false), WEEK_STRIP("نوار روزهای هفته", false),
    GOAL("هدف پس‌انداز", false), STREAK("زنجیرهٔ ثبت", false), NUDGE("یادآوری روز", false),
    NOTE("یادداشت چسبان", false), DUES("سررسیدهای نزدیک", false), ACCOUNTS("موجودی حساب‌ها", false);
    companion object {
        val extras: List<BlockType> = values().filter { !it.core }
        fun parse(s: String): BlockType? = values().firstOrNull { it.name == s }
    }
}

/** One cell of the 4-column x 6-row grid (inclusive indices). */
data class Cell(val block: BlockType, val c0: Int, val r0: Int, val c1: Int, val r1: Int) {
    val core get() = block.core
}

object Grid {
    const val COLS = 4
    const val ROWS = 6

    fun extraCount(size: WidgetSize) = when (size) { WidgetSize.SMALL -> 2; WidgetSize.WIDE -> 2; WidgetSize.LARGE -> 3 }

    /** Core blocks are fixed; the extra slots take [extras] in order. [mirror] flips left/right. */
    fun cells(size: WidgetSize, extras: List<BlockType>, mirror: Boolean): List<Cell> {
        val e = Design.fillExtras(extras, extraCount(size))
        val l: List<Cell> = when (size) {
            WidgetSize.SMALL -> listOf(Cell(BlockType.ALLOWANCE, 0, 0, 3, 3), Cell(e[0], 0, 4, 1, 5), Cell(e[1], 2, 4, 3, 5))
            WidgetSize.WIDE -> listOf(Cell(BlockType.ALLOWANCE, 0, 0, 1, 5), Cell(BlockType.URGENT, 2, 0, 3, 2), Cell(e[0], 2, 3, 2, 5), Cell(e[1], 3, 3, 3, 5))
            WidgetSize.LARGE -> listOf(Cell(BlockType.ALLOWANCE, 0, 0, 1, 1), Cell(BlockType.URGENT, 2, 0, 3, 1), Cell(e[0], 0, 2, 3, 3),
                Cell(e[1], 0, 4, 1, 4), Cell(e[2], 2, 4, 3, 4), Cell(BlockType.QUICK_ADD, 0, 5, 3, 5))
        }
        return if (mirror) l.map { it.copy(c0 = COLS - 1 - it.c1, c1 = COLS - 1 - it.c0) } else l
    }

    data class RectF(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val width get() = right - left
        val height get() = bottom - top
    }

    /** Pixel rectangle of a cell inside a widget of [w] x [h] px with [pad] around and [gap] between cells. */
    fun rect(cell: Cell, w: Float, h: Float, pad: Float, gap: Float): RectF {
        val cw = (w - 2 * pad - (COLS - 1) * gap) / COLS
        val ch = (h - 2 * pad - (ROWS - 1) * gap) / ROWS
        return RectF(pad + cell.c0 * (cw + gap), pad + cell.r0 * (ch + gap), pad + (cell.c1 + 1) * cw + cell.c1 * gap, pad + (cell.r1 + 1) * ch + cell.r1 * gap)
    }

    /** Overlay grid positions (col,row) covered by a cell. */
    fun covered(cell: Cell): List<Pair<Int, Int>> =
        (cell.r0..cell.r1).flatMap { r -> (cell.c0..cell.c1).map { c -> c to r } }
}

object Contrast {
    private fun lin(v: Int): Double { val s = v / 255.0; return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4) }
    fun luminance(argb: Int): Double = 0.2126 * lin((argb shr 16) and 255) + 0.7152 * lin((argb shr 8) and 255) + 0.0722 * lin(argb and 255)
    /** Dark ink on light colours, white on dark ones. */
    fun textOn(argb: Int): Int = if (luminance(argb) > 0.4) 0xFF1B1B2F.toInt() else 0xFFFFFFFF.toInt()
    fun withAlpha(argb: Int, alpha: Int): Int = (argb and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
    /** Blend [fg] over [bg] (both opaque-ish) — used to compute the colour a translucent card really has. */
    fun blend(fg: Int, bg: Int): Int {
        val a = ((fg ushr 24) and 255) / 255.0
        fun ch(s: Int) = (((fg shr s) and 255) * a + ((bg shr s) and 255) * (1 - a)).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}

data class Theme(
    val id: String, val name: String, val bg1: Int, val bg2: Int, val cards: List<Int>, val accent: Int,
    val cornerDp: Int, val shape: CardShape, val opacity: Int = 100
)

object Themes {
    private fun c(h: Long) = h.toInt()
    val all = listOf(
        Theme("glass", "شب شیشه‌ای", c(0xFF050B2E), c(0xFF1F3FD0), listOf(c(0xFF2B4FB8), c(0xFF1B2F7F)), c(0xFF4DA3FF), 26, CardShape.ROUND, 100),
        Theme("pastel", "پاستلیِ نچ‌دار", c(0xFFE9F7F1), c(0xFFDFF3EA), listOf(c(0xFFC8F43A), c(0xFFFFB3D9), c(0xFF8EC5FF), c(0xFFB8F2DF)), c(0xFF1B1B2F), 22, CardShape.NOTCH),
        Theme("journal", "ژورنال گرم", c(0xFFF4EFE8), c(0xFFEDE3D3), listOf(c(0xFFFFFFFF), c(0xFFFFC83D), c(0xFFF6D3CA)), c(0xFFFFB830), 26, CardShape.ROUND),
        Theme("neu", "نئومورفیک تیره", c(0xFF23232B), c(0xFF2C2C36), listOf(c(0xFF30303B), c(0xFF292933)), c(0xFFA99BFF), 24, CardShape.ROUND),
        Theme("crimson", "سرخابی", c(0xFF8E0B3A), c(0xFFB01248), listOf(c(0xFFFFFFFF), c(0xFFFCE4EC)), c(0xFFE11D48), 24, CardShape.NOTCH),
        Theme("ticket", "بنفش-هلویی بلیتی", c(0xFF453A78), c(0xFF54479A), listOf(c(0xFFF2C48D), c(0xFF5D4F9F), c(0xFFF7DDBB)), c(0xFFF2C48D), 18, CardShape.TICKET),
        Theme("bento", "بنتوی تیره", c(0xFF1C1D29), c(0xFF2B2D42), listOf(c(0xFFFFB347), c(0xFFFFFFFF), c(0xFF8B7CF6), c(0xFFFF7A90)), c(0xFFFFB347), 30, CardShape.ROUND),
        Theme("learn", "رنگارنگ آموزشی", c(0xFFFDF3D8), c(0xFFFCE8C5), listOf(c(0xFFE8527A), c(0xFFF2B233), c(0xFF2E8B6E), c(0xFFFFFFFF)), c(0xFF2E8B6E), 28, CardShape.ROUND),
        Theme("minimal", "مینیمال سفید", c(0xFFFFFFFF), c(0xFFF1F3F8), listOf(c(0xFFF3F5FA), c(0xFFE8ECF6)), c(0xFF5B5BD6), 20, CardShape.ROUND),
        Theme("ocean", "اقیانوس", c(0xFF0B3C5D), c(0xFF1D7FA6), listOf(c(0xFF14597F), c(0xFF22A6B3), c(0xFF0E4666)), c(0xFFFFD166), 24, CardShape.ROUND)
    )
    fun byId(id: String): Theme = all.firstOrNull { it.id == id } ?: all[0]
}

/** Everything the user can change about one widget. Always valid after [Design.sanitize]. */
data class DesignConfig(
    val themeId: String = "glass",
    val bg1: Int = Themes.all[0].bg1, val bg2: Int = Themes.all[0].bg2,
    val cards: List<Int> = Themes.all[0].cards, val accent: Int = Themes.all[0].accent,
    val cornerDp: Int = 26, val shape: CardShape = CardShape.ROUND, val opacity: Int = 100,
    val fontLevel: Int = 1, val density: Int = 1, val mirror: Boolean = false, val shuffleDaily: Boolean = false,
    val extras: List<BlockType> = listOf(BlockType.WEEK_BARS, BlockType.STREAK, BlockType.GOAL),
    val persianDigits: Boolean = true,
    val fontId: String = FontCatalog.DEFAULT
)

object Design {
    val defaultExtras = listOf(BlockType.WEEK_BARS, BlockType.STREAK, BlockType.GOAL, BlockType.DUES, BlockType.NUDGE, BlockType.RING)

    fun fromTheme(t: Theme, keep: DesignConfig? = null) = DesignConfig(
        themeId = t.id, bg1 = t.bg1, bg2 = t.bg2, cards = t.cards, accent = t.accent, cornerDp = t.cornerDp, shape = t.shape, opacity = t.opacity,
        fontLevel = keep?.fontLevel ?: 1, density = keep?.density ?: 1, mirror = keep?.mirror ?: false, shuffleDaily = keep?.shuffleDaily ?: false,
        extras = keep?.extras ?: DesignConfig().extras, persianDigits = keep?.persianDigits ?: true,
        fontId = keep?.fontId ?: FontCatalog.DEFAULT
    )

    /** Extras without duplicates / core types, padded from defaults to exactly [n]. */
    fun fillExtras(extras: List<BlockType>, n: Int): List<BlockType> {
        val out = ArrayList<BlockType>()
        extras.filter { !it.core }.forEach { if (it !in out && out.size < n) out.add(it) }
        (defaultExtras + BlockType.extras).forEach { if (out.size < n && it !in out) out.add(it) }
        return out
    }

    fun sanitize(c: DesignConfig) = c.copy(
        cards = c.cards.take(4).ifEmpty { Themes.all[0].cards },
        cornerDp = c.cornerDp.coerceIn(0, 40), opacity = c.opacity.coerceIn(30, 100),
        fontId = if (FontCatalog.valid(c.fontId)) c.fontId else FontCatalog.DEFAULT,
        fontLevel = c.fontLevel.coerceIn(0, 2), density = c.density.coerceIn(0, 2),
        extras = fillExtras(c.extras, BlockType.extras.size).take(BlockType.extras.size)
    )

    /** Daily variety: with shuffle on, the user's extras are replaced by a rotating, duplicate-free selection. */
    fun effectiveExtras(c: DesignConfig, dayIndex: Long, n: Int): List<BlockType> {
        if (!c.shuffleDaily) return fillExtras(c.extras, n)
        val pool = BlockType.extras
        val start = Math.floorMod(dayIndex * 3, pool.size.toLong()).toInt()
        return (0 until n).map { pool[(start + it) % pool.size] }
    }
}

/** Text form of a design (stored per widget and shareable): "HYD1|key=value;key=value". Never throws. */
object DesignCodec {
    private const val PREFIX = "HYD1|"
    private fun hex(c: Int) = "%08X".format(c)

    fun encode(c0: DesignConfig): String {
        val c = Design.sanitize(c0)
        return PREFIX + listOf(
            "t=${c.themeId}", "b1=${hex(c.bg1)}", "b2=${hex(c.bg2)}", "cd=${c.cards.joinToString(",") { hex(it) }}", "ac=${hex(c.accent)}",
            "cr=${c.cornerDp}", "sh=${c.shape.name}", "op=${c.opacity}", "fs=${c.fontLevel}", "dn=${c.density}",
            "mi=${if (c.mirror) 1 else 0}", "sf=${if (c.shuffleDaily) 1 else 0}", "pd=${if (c.persianDigits) 1 else 0}",
            "ex=${c.extras.joinToString(",") { it.name }}", "fn=${c.fontId}"
        ).joinToString(";")
    }

    private fun color(s: String?): Int? = s?.takeIf { it.length == 8 }?.toLongOrNull(16)?.toInt()

    /** Returns null when the text is not a design at all; unknown/bad fields fall back to the theme's values. */
    fun decode(text: String): DesignConfig? {
        val t = text.trim()
        if (!t.startsWith(PREFIX)) return null
        val m = HashMap<String, String>()
        t.removePrefix(PREFIX).split(';').forEach { kv -> val i = kv.indexOf('='); if (i > 0) m[kv.substring(0, i)] = kv.substring(i + 1) }
        val theme = Themes.byId(m["t"] ?: "")
        val base = Design.fromTheme(theme)
        val cards = m["cd"]?.split(',')?.mapNotNull { color(it) }?.takeIf { it.isNotEmpty() }
        return Design.sanitize(base.copy(
            bg1 = color(m["b1"]) ?: base.bg1, bg2 = color(m["b2"]) ?: base.bg2, cards = cards ?: base.cards, accent = color(m["ac"]) ?: base.accent,
            cornerDp = m["cr"]?.toIntOrNull() ?: base.cornerDp,
            shape = CardShape.values().firstOrNull { it.name == m["sh"] } ?: base.shape,
            opacity = m["op"]?.toIntOrNull() ?: base.opacity,
            fontLevel = m["fs"]?.toIntOrNull() ?: 1, density = m["dn"]?.toIntOrNull() ?: 1,
            fontId = m["fn"] ?: FontCatalog.DEFAULT,
            mirror = m["mi"] == "1", shuffleDaily = m["sf"] == "1", persianDigits = m["pd"] != "0",
            extras = m["ex"]?.split(',')?.mapNotNull { BlockType.parse(it) } ?: base.extras
        ))
    }
}
