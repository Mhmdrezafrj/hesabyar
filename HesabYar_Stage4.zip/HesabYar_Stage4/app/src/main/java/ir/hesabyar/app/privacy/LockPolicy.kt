package ir.hesabyar.app.privacy

/** When must the app ask for the phone's screen lock again? Pure and unit-tested. */
object LockPolicy {
    const val GRACE_MS = 2 * 60 * 1000L

    fun needsUnlock(enabled: Boolean, now: Long, lastUnlock: Long, graceMs: Long = GRACE_MS): Boolean {
        if (!enabled) return false
        if (lastUnlock <= 0L) return true
        if (now < lastUnlock) return true      // clock went backwards: do not trust it
        return now - lastUnlock > graceMs
    }
}
