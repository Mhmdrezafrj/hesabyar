package ir.hesabyar.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Saves the technical text of a crash on the phone only, so it can be shown (and copied by the user) on next launch. */
object CrashLog {
    private fun file(c: Context) = File(c.filesDir, "last_crash.txt")

    fun install(c: Context) {
        val app = c.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
                file(app).writeText("thread=${t.name}\nversion=${try { app.packageManager.getPackageInfo(app.packageName, 0).versionName } catch (_: Throwable) { "?" }}\n$sw".take(6000))
            } catch (_: Throwable) { }
            old?.uncaughtException(t, e)
        }
    }

    /** Records a handled-but-unexpected error (app keeps running); shown on the next launch like a crash. */
    fun record(c: Context, e: Throwable) {
        val sw = StringWriter(); e.printStackTrace(PrintWriter(sw))
        val f = file(c.applicationContext)
        val old = try { if (f.exists()) f.readText() else "" } catch (_: Throwable) { "" }
        f.writeText((old + "\n--- handled ---\n" + sw).takeLast(6000))
    }

    fun pending(c: Context): String? = try { file(c).takeIf { it.exists() }?.readText() } catch (_: Throwable) { null }
    fun clear(c: Context) { try { file(c).delete() } catch (_: Throwable) { } }
}
