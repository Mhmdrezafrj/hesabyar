package ir.hesabyar.app.plan

import ir.hesabyar.app.parser.TextNormalizer
import ir.hesabyar.app.widget.JalaliCalendar

/** Parsing of what the user types in the planning dialogs (Persian or English digits). */
object PlanInput {
    private fun clean(s: String) = TextNormalizer.normalize(s).replace(",", "").replace("٬", "").trim()

    fun amount(s: String): Long? = clean(s).toLongOrNull()?.takeIf { it > 0 && it < 1_000_000_000_000L }

    /** "1406/03" -> month key; null when invalid or empty. */
    fun monthKey(s: String): Int? {
        val p = clean(s).split('/', '-', '.')
        if (p.size != 2) return null
        val y = p[0].toIntOrNull() ?: return null; val m = p[1].toIntOrNull() ?: return null
        if (y !in 1300..1700 || m !in 1..12) return null
        return y * 12 + (m - 1)
    }

    /** "1405/09/15" -> 14050915; null when invalid. */
    fun dateKey(s: String): Int? {
        val p = clean(s).split('/', '-', '.')
        if (p.size != 3) return null
        val y = p[0].toIntOrNull() ?: return null; val m = p[1].toIntOrNull() ?: return null; val d = p[2].toIntOrNull() ?: return null
        if (y !in 1300..1700 || m !in 1..12 || d !in 1..JalaliCalendar.monthLength(y, m)) return null
        return y * 10000 + m * 100 + d
    }

    fun dayOfMonth(s: String): Int? = clean(s).toIntOrNull()?.takeIf { it in 1..31 }

    fun monthKeyText(key: Int): String = "${key / 12}/${"%02d".format(key % 12 + 1)}"
    fun dateKeyText(key: Int): String = "${key / 10000}/${"%02d".format(key / 100 % 100)}/${"%02d".format(key % 100)}"
}
