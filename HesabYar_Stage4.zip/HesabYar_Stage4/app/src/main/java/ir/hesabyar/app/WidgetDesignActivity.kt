package ir.hesabyar.app

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import ir.hesabyar.app.design.*

/**
 * Widget designer. Opened (a) by the launcher when a combo widget is added / reconfigured (has an appWidgetId),
 * or (b) from the app settings to edit the default design for all widgets.
 */
class WidgetDesignActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var size = WidgetSize.WIDE
    private lateinit var cfg: DesignConfig
    private lateinit var preview: ImageView
    private lateinit var controls: LinearLayout
    private val data by lazy { ComboData(this) }
    private val configureMode get() = widgetId != AppWidgetManager.INVALID_APPWIDGET_ID
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        if (configureMode) size = ComboWidget.sizeOf(this, widgetId) ?: WidgetSize.WIDE
        cfg = Design.sanitize(if (configureMode) DesignStore.get(this, widgetId) else DesignStore.default(this))

        val root = Ui.page(this)
        root.addView(Ui.title(this, "طراحی ویجت", if (configureMode) "ظاهر همین ویجت را شخصی کن" else "طرح پیش‌فرض ویجت‌ها را بساز"))
        preview = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        root.addView(preview, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(8)) })
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(controls) }, LinearLayout.LayoutParams(-1, 0, 1f))
        SystemInsets.apply(root)
        setContentView(root)
        buildControls(); refresh()
    }

    // ---------------------------------------------------------------- preview
    private fun refresh() {
        try {
            val baseW = if (size == WidgetSize.SMALL) 150 else 310
            val baseH = if (size == WidgetSize.LARGE) 310 else 150
            val screenW = resources.displayMetrics.widthPixels - dp(32)
            val wPx = minOf(screenW, if (size == WidgetSize.SMALL || size == WidgetSize.LARGE) dp(260) else screenW).coerceAtLeast(100)
            val scale = wPx.toFloat() / baseW
            val hPx = (baseH * scale).toInt()
            preview.setImageBitmap(ComboRenderer.render(Design.sanitize(cfg), size, wPx, hPx, scale, data))
        } catch (e: Exception) { toast("پیش‌نمایش ساخته نشد") }
    }

    private fun change(newCfg: DesignConfig) { cfg = Design.sanitize(newCfg); refresh() }

    // ---------------------------------------------------------------- controls
    private fun label(t: String) = Ui.text(this, t, 13f, Ui.muted, true).apply { setPadding(0, dp(12), 0, dp(4)) }

    private fun <T> spinner(items: List<String>, selected: Int, onPick: (Int) -> Unit): Spinner {
        var first = true
        return Spinner(this).apply {
            adapter = ArrayAdapter(this@WidgetDesignActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(selected.coerceIn(0, items.size - 1))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { if (first) { first = false; return }; onPick(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
    }

    private fun slider(min: Int, max: Int, value: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max - min; progress = (value - min).coerceIn(0, max - min)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun toggle(text: String, on: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        this.text = text; isChecked = on; setOnCheckedChangeListener { _, v -> onChange(v) }; setPadding(0, dp(6), 0, dp(6))
    }

    private fun colorButton(title: String, color: Int, onPick: (Int) -> Unit) = Button(this).apply {
        text = title; isAllCaps = false
        background = Ui.rounded(dp(14).toFloat(), color, Color.argb(90, 120, 120, 150), dp(1))
        setTextColor(Contrast.textOn(Contrast.blend(color, 0xFFFFFFFF.toInt())))
        setOnClickListener { pickColor(title, color, onPick) }
    }

    private val palette = longArrayOf(
        0xFF050B2E, 0xFF1F3FD0, 0xFF4DA3FF, 0xFF0B3C5D, 0xFF22A6B3, 0xFF12A872,
        0xFFC8F43A, 0xFFFFD166, 0xFFFFB347, 0xFFE9960B, 0xFFFF7A90, 0xFFE0334F,
        0xFF8E0B3A, 0xFF8B7CF6, 0xFF453A78, 0xFF1C1D29, 0xFF30303B, 0xFF6B7280,
        0xFFFFFFFF, 0xFFF4EFE8, 0xFFFFB3D9, 0xFFB8F2DF, 0xFF8EC5FF, 0xFFF2C48D
    ).map { it.toInt() }

    private fun pickColor(title: String, current: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val hex = EditText(this).apply { hint = "کد رنگ مثل #4DA3FF"; setText("#%06X".format(current and 0xFFFFFF)); setSingleLine() }
        var dialog: AlertDialog? = null
        palette.chunked(6).forEach { rowColors ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            rowColors.forEach { col ->
                row.addView(View(this).apply {
                    background = Ui.rounded(dp(10).toFloat(), col, Color.argb(90, 120, 120, 150), dp(1))
                    setOnClickListener { onPick(col); dialog?.dismiss() }
                }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            box.addView(row)
        }
        box.addView(hex)
        dialog = AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("لغو", null)
            .setPositiveButton("اعمال کد") { _, _ ->
                val t = hex.text.toString().trim().removePrefix("#")
                val v = if (t.length == 6) t.toLongOrNull(16) else null
                if (v == null) toast("کد رنگ باید ۶ رقم هگز باشد، مثل 4DA3FF") else onPick((0xFF000000 or v).toInt())
            }.show()
    }

    private fun buildControls() {
        controls.removeAllViews()
        if (!configureMode) {
            controls.addView(label("اندازهٔ پیش‌نمایش"))
            controls.addView(spinner<Int>(listOf("کوچک ۲×۲", "عریض ۴×۲", "بزرگ ۴×۴"), size.ordinal) { size = WidgetSize.values()[it]; buildControls(); refresh() })
        }
        controls.addView(label("تم آماده"))
        val themes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Themes.all.forEach { t ->
            themes.addView(Button(this).apply {
                text = t.name; isAllCaps = false
                background = Ui.rounded(dp(14).toFloat(), if (t.id == cfg.themeId) Color.argb(60, 112, 87, 232) else Color.argb(25, 120, 120, 150), null, 0)
                setOnClickListener { change(Design.fromTheme(t, cfg)); buildControls() }
            }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        controls.addView(HorizontalScrollView(this).apply { addView(themes) })

        controls.addView(label("رنگ‌ها (روی هر کدام بزن)"))
        val colors = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        colors.addView(colorButton("پس‌زمینه ۱", cfg.bg1) { change(cfg.copy(bg1 = it)); buildControls() })
        colors.addView(colorButton("پس‌زمینه ۲", cfg.bg2) { change(cfg.copy(bg2 = it)); buildControls() })
        colors.addView(colorButton("رنگ کارت ۱", cfg.cards[0]) { change(cfg.copy(cards = listOf(it) + cfg.cards.drop(1))); buildControls() })
        colors.addView(colorButton("رنگ کارت ۲", cfg.cards.getOrElse(1) { cfg.cards[0] }) { change(cfg.copy(cards = listOf(cfg.cards[0], it) + cfg.cards.drop(2))); buildControls() })
        colors.addView(colorButton("رنگ اصلی (دکمه‌ها و تأکید)", cfg.accent) { change(cfg.copy(accent = it)); buildControls() })
        controls.addView(colors)
        controls.addView(Ui.text(this, "رنگ متن خودکار انتخاب می‌شود تا روی هر کارت خوانا بماند.", 11f, Ui.muted))

        controls.addView(label("گردی گوشه‌ها"))
        controls.addView(slider(0, 40, cfg.cornerDp) { change(cfg.copy(cornerDp = it)) })
        controls.addView(label("شفافیت"))
        controls.addView(slider(30, 100, cfg.opacity) { change(cfg.copy(opacity = it)) })

        controls.addView(label("شکل کارت‌ها"))
        controls.addView(spinner<Int>(listOf("گرد", "نچ‌دار (بریدگی گوشه)", "بلیتی"), cfg.shape.ordinal) { change(cfg.copy(shape = CardShape.values()[it])) })
        controls.addView(label("فونت نوشته‌ها"))
        controls.addView(spinner<Int>(FontCatalog.all.map { it.label }, FontCatalog.all.indexOfFirst { it.id == cfg.fontId }) { change(cfg.copy(fontId = FontCatalog.all[it].id)) })
        controls.addView(label("اندازهٔ نوشته"))
        controls.addView(spinner<Int>(listOf("کوچک", "معمولی", "بزرگ"), cfg.fontLevel) { change(cfg.copy(fontLevel = it)) })
        controls.addView(label("فاصلهٔ بین کارت‌ها"))
        controls.addView(spinner<Int>(listOf("فشرده", "معمولی", "جادار"), cfg.density) { change(cfg.copy(density = it)) })

        controls.addView(toggle("چیدمان آینه‌ای (چپ و راست عوض شود)", cfg.mirror) { change(cfg.copy(mirror = it)) })
        controls.addView(toggle("ارقام فارسی", cfg.persianDigits) { change(cfg.copy(persianDigits = it)) })
        controls.addView(toggle("تغییر خودکار بلوک‌ها هر روز (برای جلب توجه)", cfg.shuffleDaily) { change(cfg.copy(shuffleDaily = it)) })

        controls.addView(label("بلوک‌های دلخواه (بلوک‌های اصلی ثابت می‌مانند)"))
        val names = BlockType.extras.map { it.label }
        for (i in 0 until Grid.extraCount(size)) {
            controls.addView(spinner<Int>(names, BlockType.extras.indexOf(cfg.extras[i])) { pos ->
                val pick = BlockType.extras[pos]
                change(cfg.copy(extras = cfg.extras.toMutableList().also { it.remove(pick); it.add(i, pick) }))
            })
        }

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        row1.addView(Ui.soft(this, "خروجی طراحی") { showExport() }, LinearLayout.LayoutParams(0, -2, 1f))
        row1.addView(Ui.soft(this, "ورودی طراحی") { showImport() }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(row1, Ui.margins(this, 14, 0))
        controls.addView(Ui.soft(this, "بازگشت به تم انتخابی") { change(Design.fromTheme(Themes.byId(cfg.themeId), cfg)); buildControls() }, Ui.margins(this, 0, 6))

        controls.addView(Ui.primary(this, if (configureMode) "ذخیره و افزودن ویجت" else "ذخیره به‌عنوان طرح پیش‌فرض") { save(false) }, Ui.margins(this, 8, 6))
        if (!configureMode) controls.addView(Ui.soft(this, "ذخیره و اعمال روی همهٔ ویجت‌های روی صفحه") { save(true) }, Ui.margins(this, 0, 24))
        else controls.addView(View(this), LinearLayout.LayoutParams(-1, dp(24)))
    }

    private fun save(applyAll: Boolean) {
        cfg = Design.sanitize(cfg)
        if (configureMode) {
            DesignStore.save(this, widgetId, cfg)
            ComboWidget.updateAll(this)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
            finish()
        } else {
            DesignStore.saveDefault(this, cfg)
            if (applyAll) ComboWidget.existing(this).forEach { (id, _) -> DesignStore.save(this, id, cfg) }
            ComboWidget.updateAll(this)
            toast(if (applyAll) "روی همهٔ ویجت‌ها اعمال شد" else "طرح پیش‌فرض ذخیره شد")
        }
    }

    private fun showExport() {
        val text = DesignCodec.encode(cfg)
        val box = EditText(this).apply { setText(text); setTextIsSelectable(true); setPadding(dp(16), dp(8), dp(16), dp(8)); textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("خروجی طراحی").setMessage("این متن را نگه دار یا روی ویجت دیگر وارد کن.").setView(box)
            .setNegativeButton("بستن", null)
            .setPositiveButton("کپی") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("design", text)); toast("کپی شد")
            }.show()
    }

    private fun showImport() {
        val box = EditText(this).apply { hint = "متن طراحی (شروع با HYD1|) را اینجا بچسبان"; setPadding(dp(16), dp(8), dp(16), dp(8)); textDirection = View.TEXT_DIRECTION_LTR }
        AlertDialog.Builder(this).setTitle("ورودی طراحی").setView(box).setNegativeButton("لغو", null)
            .setPositiveButton("اعمال") { _, _ ->
                val d = DesignCodec.decode(box.text.toString())
                if (d == null) toast("این متن یک طراحی معتبر نیست") else { change(d); buildControls() }
            }.show()
    }
}
