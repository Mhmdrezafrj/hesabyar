package ir.hesabyar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/**
 * Receives newly delivered SMS broadcasts. Only candidate financial messages are persisted.
 * Safety nets (see SmsSync): even if this broadcast is never delivered (battery savers, vendor restrictions),
 * a background job notices the SMS database change or runs every ~15 minutes and imports what was missed.
 */
class IncomingSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (!SmsSettings.autoEnabled(context)) return
        val app = context.applicationContext
        val pending = goAsync()
        // Capture the message now (the intent is only valid during onReceive), process on a worker thread.
        val parsed: List<Triple<String, String, Long>> = try {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            // A multipart SMS can arrive as several PDUs; combine segments from the same sender.
            (messages ?: emptyArray()).groupBy { it.originatingAddress.orEmpty() }.map { (sender, parts) ->
                Triple(sender, parts.sortedBy { it.timestampMillis }.joinToString("") { it.messageBody.orEmpty() },
                    parts.minOfOrNull { it.timestampMillis } ?: System.currentTimeMillis())
            }
        } catch (e: Exception) { SmsSettings.setLiveError(app, "read: " + e.javaClass.simpleName); emptyList() }

        Thread {
            try {
                if (parsed.isNotEmpty()) {
                    val store = SmsInboxStore(app)
                    try { parsed.forEach { (sender, body, ts) -> store.insertCandidate(sender, body, ts, "LIVE_SMS") } } finally { store.close() }
                    SmsSettings.markLive(app); SmsSettings.setLiveError(app, "")
                }
            } catch (e: Exception) {
                SmsSettings.setLiveError(app, "store: " + e.javaClass.simpleName)   // the background job will retry from the SMS inbox
            } finally {
                try { PendingTransactionsWidget.updateAll(app) } catch (_: Exception) {}
                try { Notifier.check(app) } catch (_: Exception) {}
                try { SmsSync.schedule(app) } catch (_: Exception) {}
                pending.finish()
            }
        }.start()
    }
}
