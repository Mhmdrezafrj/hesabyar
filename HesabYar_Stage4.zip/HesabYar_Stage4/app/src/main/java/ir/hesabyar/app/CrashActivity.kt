package ir.hesabyar.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Shown once after a crash: plain views only (must not depend on the rest of the app). */
class CrashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = CrashLog.pending(this) ?: ""
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        root.addView(TextView(this).apply { text = "حساب‌یار دفعهٔ قبل با خطا بسته شد"; textSize = 20f; setTypeface(null, Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "متن فنی خطا پایین است (فقط روی همین گوشی ذخیره شده). «کپی» را بزن و برای من بفرست."; textSize = 13f; setPadding(0, pad / 2, 0, pad / 2) })
        root.addView(ScrollView(this).apply {
            addView(TextView(this@CrashActivity).apply { text = report; textSize = 11f; typeface = Typeface.MONOSPACE; setTextIsSelectable(true); layoutDirection = View.LAYOUT_DIRECTION_LTR })
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply {
            text = "کپی متن خطا"
            setOnClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("crash", report))
                Toast.makeText(this@CrashActivity, "کپی شد", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply { text = "بستن و ادامه"; setOnClickListener { CrashLog.clear(this@CrashActivity); finish() } })
        setContentView(root)
    }
}
