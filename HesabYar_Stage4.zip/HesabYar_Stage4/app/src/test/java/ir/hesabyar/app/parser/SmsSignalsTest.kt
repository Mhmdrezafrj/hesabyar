package ir.hesabyar.app.parser

import ir.hesabyar.app.money.Currency
import org.junit.Assert.*
import org.junit.Test

class SmsSignalsTest {
    private fun s(body: String, sender: String = "98700717+") = SmsSignals.analyze(sender, body)

    @Test fun melliWithdrawLabel_realSample() {
        val r = s("بانك ملي ايران\nبرداشت:-5,500,000\nحساب:60007\nمانده:355,816\n0823-09:41")!!
        assertEquals(TransactionType.WITHDRAWAL, r.type); assertEquals(5_500_000L, r.amount)
        assertEquals(355_816L, r.balance); assertEquals("60007", r.account); assertEquals("0823-09:41", r.timeText)
        assertEquals("بانک ملی ایران", r.bankName); assertTrue(r.registrable)
    }
    @Test fun trailingSignAndTransferLabel() {
        val r = s("بانک ملی ایران\nانتقال:2,011,000-\nحساب:60007\nمانده:2,433,816\n0818-18:03")!!
        assertEquals(TransactionType.WITHDRAWAL, r.type); assertEquals(2_011_000L, r.amount)
        val d = s("بانک ملی ایران\nانتقالی:1,000,000+\nحساب:60007\nمانده:3,433,816\n0818-18:06")!!
        assertEquals(TransactionType.DEPOSIT, d.type); assertEquals(1_000_000L, d.amount)
    }
    @Test fun unknownDepositLabelVariant() {
        val r = s("بانک ملت\nواریز: 750,000 ریال\nمانده: 1,250,000 ریال\n1405/08/23 10:15")!!
        assertEquals(TransactionType.DEPOSIT, r.type); assertEquals(750_000L, r.amount)
        assertEquals(1_250_000L, r.balance); assertEquals(Currency.RIAL, r.currencyHint)
        assertEquals("بانک ملت", r.bankName)
    }
    @Test fun singleLineMessagePersianDigits() {
        val r = s("بانک صادرات: برداشت ۲۵۰٬۰۰۰ تومان از حساب ۱۲۳۴۵ موجودی ۹۰۰٬۰۰۰ تومان")!!
        assertEquals(TransactionType.WITHDRAWAL, r.type); assertEquals(250_000L, r.amount)
        assertEquals(900_000L, r.balance); assertEquals(Currency.TOMAN, r.currencyHint); assertEquals("12345", r.account)
    }
    @Test fun purchaseWordIsWithdrawal() {
        val r = s("بانک پاسارگاد\nخرید: 120,000 ریال\nمانده: 5,000,000")!!
        assertEquals(TransactionType.WITHDRAWAL, r.type); assertEquals(120_000L, r.amount)
    }
    @Test fun balanceIsNeverTheAmount() {
        val r = s("بانک ملی ایران\nبرداشت:-600,000\nمانده:5,855,816")!!
        assertEquals(600_000L, r.amount); assertNotEquals(r.balance, r.amount)
    }
    @Test fun signContradictsWord_noType() {
        val r = s("بانک ملی ایران\nبرداشت:+600,000\nمانده:5,855,816")!!
        assertNull(r.type); assertFalse(r.registrable)
    }
    @Test fun signsOnBothSides_noType() {
        val r = s("بانک ملی ایران\nانتقال:-600,000+\nمانده:1")!!
        assertFalse(r.registrable)
    }
    @Test fun neutralLabelWithoutSign_noGuessFromNothing() {
        val r = s("بانک ملی ایران\nمبلغ: 600,000\nمانده:5,855,816")!!
        assertNull(r.type); assertFalse(r.registrable)
    }
    @Test fun twoDifferentAmounts_notRegistrable() {
        val r = s("بانک ملی ایران\nبرداشت:-600,000\nبرداشت:-700,000\nمانده:1,000")!!
        assertNull(r.amount); assertFalse(r.registrable)
    }
    @Test fun sameAmountRepeated_isFine() {
        val r = s("بانک ملی ایران\nبرداشت:-600,000\nمبلغ -600,000\nمانده:1,000")!!
        assertEquals(600_000L, r.amount); assertEquals(TransactionType.WITHDRAWAL, r.type)
    }
    @Test fun depositAndWithdrawWordsTogether_notRegistrable() {
        val r = s("بانک ملی ایران\nبرداشت:-600,000\nواریز:+700,000\nمانده:1")!!
        assertFalse(r.registrable)
    }
    @Test fun otpAndPromoGiveNothing() {
        assertNull(s("بانک ملی ایران\nرمز یکبار مصرف شما: 123456"))
        assertNull(s("مشتری گرامی تلفن: 8136827242\nبا عضویت در باشگاه مشتریان مخابرات از تخفیف بهره مند شوید\n271150", "Mokhaberat"))
        assertNull(s("سلام"))
        assertNull(s(""))
    }
    @Test fun phoneAndCardNumbersAreNotAmounts() {
        assertNull(s("بانک ملی ایران\nکارت: 6037991234567890\nحساب: 60007"))
    }
    @Test fun noBankName_stillSuggests() {
        val r = s("برداشت:-5,500,000\nمانده:355,816")!!
        assertNull(r.bankName); assertTrue(r.registrable)
    }
    @Test fun decimalLookingNumberIsNotMisread() {
        val r = s("بانک ملی ایران\nبرداشت:-12,34\nمانده:1")
        // "12,34" is not a valid grouped amount: must not become 12
        assertTrue(r == null || r.amount != 12L)
    }
    @Test fun unitNotStated_noHint() {
        assertNull(s("بانک ملی ایران\nبرداشت:-5,500,000\nمانده:355,816")!!.currencyHint)
    }
}
