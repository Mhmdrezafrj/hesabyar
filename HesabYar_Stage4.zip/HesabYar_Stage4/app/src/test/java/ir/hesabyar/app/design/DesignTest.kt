package ir.hesabyar.app.design

import org.junit.Assert.*
import org.junit.Test

class DesignTest {
    @Test fun everyLayoutHasNoOverlapAndStaysInGrid() {
        for (size in WidgetSize.values()) for (mirror in listOf(false, true)) {
            val cells = Grid.cells(size, BlockType.extras.take(3), mirror)
            val seen = HashSet<Pair<Int, Int>>()
            cells.forEach { c ->
                assertTrue(c.c0 in 0 until Grid.COLS && c.c1 in c.c0 until Grid.COLS && c.r0 in 0 until Grid.ROWS && c.r1 in c.r0 until Grid.ROWS)
                Grid.covered(c).forEach { p -> assertTrue("overlap $size $mirror $p", seen.add(p)) }
            }
        }
    }
    @Test fun coreBlocksAlwaysPresentAndExtrasCountMatches() {
        for (size in WidgetSize.values()) {
            val cells = Grid.cells(size, emptyList(), false)
            assertTrue(cells.any { it.block == BlockType.ALLOWANCE })
            assertEquals(Grid.extraCount(size), cells.count { !it.core })
            assertEquals(cells.size, cells.map { it.block }.toSet().size)  // no block twice
        }
        assertTrue(Grid.cells(WidgetSize.LARGE, emptyList(), false).any { it.block == BlockType.QUICK_ADD })
        assertTrue(Grid.cells(WidgetSize.WIDE, emptyList(), false).any { it.block == BlockType.URGENT })
    }
    @Test fun coreExtrasInputAreIgnored() {
        val cells = Grid.cells(WidgetSize.SMALL, listOf(BlockType.ALLOWANCE, BlockType.RING, BlockType.RING, BlockType.NOTE), false)
        assertEquals(listOf(BlockType.RING, BlockType.NOTE), cells.filter { !it.core }.map { it.block })
        assertEquals(1, cells.count { it.block == BlockType.ALLOWANCE })
    }
    @Test fun mirrorFlipsColumns() {
        val a = Grid.cells(WidgetSize.WIDE, emptyList(), false).first { it.block == BlockType.ALLOWANCE }
        val b = Grid.cells(WidgetSize.WIDE, emptyList(), true).first { it.block == BlockType.ALLOWANCE }
        assertEquals(0, a.c0); assertEquals(1, a.c1); assertEquals(2, b.c0); assertEquals(3, b.c1)
    }
    @Test fun rectsInsidePaddedArea() {
        val w = 800f; val h = 600f
        for (size in WidgetSize.values()) Grid.cells(size, emptyList(), false).forEach {
            val r = Grid.rect(it, w, h, 12f, 8f)
            assertTrue(r.left >= 12f - 0.01 && r.top >= 12f - 0.01 && r.right <= w - 12f + 0.01 && r.bottom <= h - 12f + 0.01)
            assertTrue(r.width > 0 && r.height > 0)
        }
        val full = Grid.rect(Cell(BlockType.ALLOWANCE, 0, 0, 3, 5), w, h, 12f, 8f)
        assertEquals(12f, full.left, 0.01f); assertEquals(w - 12f, full.right, 0.01f); assertEquals(h - 12f, full.bottom, 0.01f)
    }
    @Test fun contrast() {
        assertEquals(0xFFFFFFFF.toInt(), Contrast.textOn(0xFF050B2E.toInt()))
        assertNotEquals(0xFFFFFFFF.toInt(), Contrast.textOn(0xFFC8F43A.toInt()))
        assertNotEquals(0xFFFFFFFF.toInt(), Contrast.textOn(0xFFFFFFFF.toInt()))
        assertEquals(0xFFFFFFFF.toInt(), Contrast.textOn(0xFF8E0B3A.toInt()))
        assertEquals(0x80123456.toInt(), Contrast.withAlpha(0xFF123456.toInt(), 128))
        assertEquals(0xFF000000.toInt(), Contrast.blend(0x00FFFFFF, 0xFF000000.toInt()))
        assertEquals(0xFFFFFFFF.toInt(), Contrast.blend(0xFFFFFFFF.toInt(), 0xFF000000.toInt()))
    }
    @Test fun allThemesAreUsable() {
        assertTrue(Themes.all.size >= 10)
        assertEquals(Themes.all.size, Themes.all.map { it.id }.toSet().size)
        Themes.all.forEach { t -> assertTrue(t.cards.isNotEmpty() && t.cards.size <= 4); assertTrue(t.cornerDp in 0..40) }
        assertEquals("glass", Themes.byId("nope").id)
    }
    @Test fun sanitizeClampsAndFills() {
        val bad = DesignConfig(cornerDp = 999, opacity = -5, fontLevel = 9, density = -2, cards = emptyList(), extras = listOf(BlockType.URGENT, BlockType.NOTE, BlockType.NOTE))
        val s = Design.sanitize(bad)
        assertEquals(40, s.cornerDp); assertEquals(30, s.opacity); assertEquals(2, s.fontLevel); assertEquals(0, s.density)
        assertTrue(s.cards.isNotEmpty()); assertEquals(BlockType.NOTE, s.extras[0]); assertEquals(BlockType.extras.size, s.extras.toSet().size)
    }
    @Test fun codecRoundTrip() {
        val c = Design.sanitize(Design.fromTheme(Themes.byId("ticket")).copy(accent = 0xFF112233.toInt(), cornerDp = 12, mirror = true, shuffleDaily = true,
            fontLevel = 2, extras = listOf(BlockType.NOTE, BlockType.RING, BlockType.DUES), persianDigits = false, opacity = 70))
        val back = DesignCodec.decode(DesignCodec.encode(c))!!
        assertEquals(c, back)
    }
    @Test fun codecIsLenient() {
        assertNull(DesignCodec.decode("hello")); assertNull(DesignCodec.decode(""))
        val d = DesignCodec.decode("HYD1|t=pastel;cr=abc;b1=zzzz;ex=NOTE,BOGUS;;=;x")!!
        assertEquals(Themes.byId("pastel").cornerDp, d.cornerDp); assertEquals(Themes.byId("pastel").bg1, d.bg1)
        assertEquals(BlockType.NOTE, d.extras[0])
        assertNotNull(DesignCodec.decode("HYD1|"))
    }
    @Test fun dailyShuffleVariesAndHasNoDuplicates() {
        val c = DesignConfig(shuffleDaily = true)
        val a = Design.effectiveExtras(c, 100, 3); val b = Design.effectiveExtras(c, 101, 3)
        assertEquals(3, a.toSet().size); assertNotEquals(a, b)
        assertEquals(a, Design.effectiveExtras(c, 100, 3))
        assertEquals(3, Design.effectiveExtras(c, -7, 3).toSet().size)
        val fixed = DesignConfig(shuffleDaily = false, extras = listOf(BlockType.NOTE, BlockType.RING))
        assertEquals(listOf(BlockType.NOTE, BlockType.RING), Design.effectiveExtras(fixed, 5, 2))
    }
    @Test fun combinationCount() {
        // 3 sizes x 10 themes x mirror x ordered choice of extras: large number of distinct looks
        val n = 3 * Themes.all.size * 2 * (9 * 8 * 7)
        assertTrue(n > 30000)
    }
}
