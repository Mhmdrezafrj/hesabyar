package ir.hesabyar.app.widget

import ir.hesabyar.app.Transaction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WidgetLogicTest {
    private fun tx(id: String, ts: Long, cat: String = "", bal: Long? = null) =
        Transaction(id = id, title = id, bank = "b", amount = 1000, time = "t", isIncome = false, category = cat, balance = bal, timestamp = ts)

    // ---- the 10-transactions example from the brief ----
    @Test fun tenTransactions_eightCategorised_onlyTwoShown() {
        val all = (1..10).map { tx("t$it", it.toLong(), if (it <= 8) "خوراک" else "") }
        val shown = PendingQueue.visible(all, 3)
        assertEquals(listOf("t10", "t9"), shown.map { it.id })
    }

    @Test fun newestFirst_andLimitedToCount() {
        val all = (1..10).map { tx("t$it", it.toLong()) }
        assertEquals(listOf("t10", "t9", "t8"), PendingQueue.visible(all, 3).map { it.id })
        assertEquals(5, PendingQueue.visible(all, 5).size)
        assertEquals(7, PendingQueue.visible(all, 7).size)
    }

    @Test fun oldDaysStayInQueue_andNextOneReplacesCategorised() {
        val day = 86_400_000L
        val all = listOf(tx("today", 5 * day), tx("yesterday", 4 * day), tx("lastWeek", day), tx("old", 1))
        assertEquals(listOf("today", "yesterday", "lastWeek"), PendingQueue.visible(all, 3).map { it.id })
        // categorise "today": the next oldest pending one takes its place immediately
        val after = all.map { if (it.id == "today") it.copy(category = "قبوض") else it }
        assertEquals(listOf("yesterday", "lastWeek", "old"), PendingQueue.visible(after, 3).map { it.id })
    }

    @Test fun categorisedNeverReappears() {
        val all = listOf(tx("a", 2, "سایر"), tx("b", 1))
        assertTrue(PendingQueue.pending(all).none { it.id == "a" })
    }

    @Test fun emptyQueue() {
        assertTrue(PendingQueue.visible(emptyList(), 3).isEmpty())
        assertTrue(PendingQueue.visible(listOf(tx("a", 1, "x")), 3).isEmpty())
    }

    @Test fun latestBalance_onlyFromRealBalances() {
        assertNull(PendingQueue.latestBalance(listOf(tx("manual", 9))))
        val all = listOf(tx("old", 1, bal = 100), tx("new", 5, bal = 300), tx("manualNewest", 9))
        assertEquals("new", PendingQueue.latestBalance(all)!!.id)
    }

    // ---- config ----
    @Test fun configSanitised() {
        val c = WidgetConfig(count = 4, titleFont = 9, amountFont = -3, opacityPercent = 5, style = 7).sanitized()
        assertEquals(3, c.count); assertEquals(2, c.titleFont); assertEquals(0, c.amountFont)
        assertEquals(30, c.opacityPercent); assertEquals(1, c.style)
        assertEquals(7, WidgetConfig(count = 7).sanitized().count)
        assertEquals(WidgetConfig(), WidgetConfig().sanitized())
    }

    @Test fun rowsThatFit() {
        assertEquals(3, WidgetLayoutMath.rowsThatFit(0, 3, true))
        assertEquals(7, WidgetLayoutMath.rowsThatFit(500, 7, true))
        assertEquals(1, WidgetLayoutMath.rowsThatFit(60, 7, true))
        assertTrue(WidgetLayoutMath.rowsThatFit(200, 7, false) >= WidgetLayoutMath.rowsThatFit(200, 7, true))
    }

    // ---- Jalali date ----
    private fun j(gy: Int, gm: Int, gd: Int) = JalaliCalendar.fromGregorian(gy, gm, gd).let { Triple(it.year, it.month, it.day) }

    @Test fun jalali_knownDates() {
        assertEquals(Triple(1405, 8, 19), j(2026, 11, 10))
        assertEquals(Triple(1405, 1, 1), j(2026, 3, 21))
        assertEquals(Triple(1404, 1, 1), j(2025, 3, 21))
        assertEquals(Triple(1403, 1, 1), j(2024, 3, 20))
        assertEquals(Triple(1403, 12, 30), j(2025, 3, 20))   // 1403 is a leap year
        assertEquals(Triple(1404, 12, 29), j(2026, 3, 20))   // 1404 is not
        assertEquals(Triple(1404, 7, 1), j(2025, 9, 23))
        assertEquals(Triple(1404, 10, 11), j(2026, 1, 1))
    }
}
