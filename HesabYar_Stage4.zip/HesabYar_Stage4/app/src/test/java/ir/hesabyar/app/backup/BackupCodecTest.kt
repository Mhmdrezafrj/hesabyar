package ir.hesabyar.app.backup

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.privacy.LockPolicy
import org.junit.Assert.*
import org.junit.Test

class BackupCodecTest {
    private val tx1 = Transaction("id-1", "واریز به حساب ۱۲۳", "بانک ملی ایران", 2_011_000, "۰۸/۱۹ ۱۴:۳۰", true, "درآمد", "IRR", "SMS", "MELLI|123|2011000|5000|1119-1430", 9_000_000L, "123", 1_700_000_000_000L)
    private val tx2 = Transaction("id-2", "خط اول\nخط\tدوم \\ و \r آخر", "ثبت دستی", 500, "همین الان", false, "", "IRT", "MANUAL", "", null, "", 0L)

    @Test fun roundTrip_keepsEverything() {
        val text = BackupCodec.encode(listOf(tx1, tx2), listOf("خوراک و مواد غذایی", "دسته\tعجیب"), mapOf("قبوض" to 3_000_000L))
        val r = BackupCodec.decode(text)
        assertNull(r.error)
        assertEquals(listOf(tx1, tx2), r.data!!.transactions)
        assertEquals(listOf("خوراک و مواد غذایی", "دسته\tعجیب"), r.data!!.categories)
        assertEquals(mapOf("قبوض" to 3_000_000L), r.data!!.budgets)
    }
    @Test fun emptyBackupIsValid() {
        val r = BackupCodec.decode(BackupCodec.encode(emptyList(), emptyList(), emptyMap()))
        assertNull(r.error); assertTrue(r.data!!.transactions.isEmpty())
    }
    @Test fun windowsLineEndingsAccepted() {
        val text = BackupCodec.encode(listOf(tx1), emptyList(), emptyMap()).replace("\n", "\r\n")
        assertEquals(listOf(tx1), BackupCodec.decode(text).data!!.transactions)
    }
    @Test fun rejectsForeignFile() {
        assertNotNull(BackupCodec.decode("hello world").error)
        assertNotNull(BackupCodec.decode("").error)
        assertNotNull(BackupCodec.decode("HESABYAR-BACKUP\tabc").error)
    }
    @Test fun rejectsNewerVersion() { assertNotNull(BackupCodec.decode("HESABYAR-BACKUP\t99\n").error) }
    @Test fun rejectsCorruptTransactionLines() {
        val head = "HESABYAR-BACKUP\t1\n"
        assertNotNull(BackupCodec.decode(head + "T\tonly\tthree\tfields\n").error)
        val good = BackupCodec.encode(listOf(tx1), emptyList(), emptyMap()).lines()[1]
        assertNotNull(BackupCodec.decode(head + good.replace("2011000", "abc")).error)
        assertNotNull(BackupCodec.decode(head + good.replace("\t1\t", "\t7\t")).error)
        assertNotNull(BackupCodec.decode(head + "C\tbad\\x\n").error)
    }
    @Test fun badFileChangesNothing_noPartialResult() {
        val text = BackupCodec.encode(listOf(tx1), emptyList(), emptyMap()) + "T\tbroken\n"
        val r = BackupCodec.decode(text)
        assertNull(r.data); assertNotNull(r.error)
    }
    @Test fun unknownRecordTypesAreIgnored() {
        val text = BackupCodec.encode(listOf(tx1), emptyList(), emptyMap()) + "X\tfuture\n"
        assertEquals(1, BackupCodec.decode(text).data!!.transactions.size)
    }

    // ---- lock policy ----
    @Test fun lock_disabledNeverAsks() { assertFalse(LockPolicy.needsUnlock(false, 1000, 0)) }
    @Test fun lock_firstTimeAsks() { assertTrue(LockPolicy.needsUnlock(true, 1000, 0)) }
    @Test fun lock_graceWindow() {
        assertFalse(LockPolicy.needsUnlock(true, 1_000_000, 1_000_000 - LockPolicy.GRACE_MS))
        assertTrue(LockPolicy.needsUnlock(true, 1_000_000, 1_000_000 - LockPolicy.GRACE_MS - 1))
    }
    @Test fun lock_clockGoingBackwardsAsks() { assertTrue(LockPolicy.needsUnlock(true, 1000, 5000)) }
}
