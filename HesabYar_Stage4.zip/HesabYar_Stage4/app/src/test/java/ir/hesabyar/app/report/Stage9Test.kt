package ir.hesabyar.app.report

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.widget.Categories
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.util.TimeZone

class Stage9Test {
    private fun ms(iso: String) = Instant.parse(iso).toEpochMilli()
    private val utc = TimeZone.getTimeZone("UTC")
    private fun tx(id: String, title: String = "t", amount: Long = 1000, cat: String = "", income: Boolean = false, iso: String? = "2026-11-10T08:00:00Z", bank: String = "بانک ملی ایران", acc: String = "") =
        Transaction(id, title, bank, amount, "", income, cat, "IRR", accountId = acc, timestamp = iso?.let { ms(it) } ?: 0L)

    // ---- search ----
    @Test fun search_emptyQueryReturnsAll() { assertEquals(2, HistorySearch.filter(listOf(tx("a"), tx("b")), "  ").size) }
    @Test fun search_titleAndCategoryAndBank() {
        val l = listOf(tx("a", "واریز به حساب", cat = "قبوض"), tx("b", "خرید نان", cat = "خوراک و مواد غذایی"))
        assertEquals(listOf("b"), HistorySearch.filter(l, "نان").map { it.id })
        assertEquals(listOf("a"), HistorySearch.filter(l, "قبوض").map { it.id })
        assertEquals(2, HistorySearch.filter(l, "ملی").size)
    }
    @Test fun search_persianAndArabicVariants() {
        val l = listOf(tx("a", "كتاب و آموزش"))
        assertEquals(1, HistorySearch.filter(l, "کتاب").size)
    }
    @Test fun search_allWordsMustMatch() {
        val l = listOf(tx("a", "خرید نان", cat = "خوراک و مواد غذایی"), tx("b", "خرید کتاب", cat = "آموزش"))
        assertEquals(listOf("b"), HistorySearch.filter(l, "خرید آموزش").map { it.id })
    }
    @Test fun search_amountWithPersianDigitsAndSeparators() {
        val l = listOf(tx("a", amount = 2_011_000), tx("b", amount = 500))
        assertEquals(listOf("a"), HistorySearch.filter(l, "۲٬۰۱۱٬۰۰۰").map { it.id })
        assertEquals(listOf("a"), HistorySearch.filter(l, "2011").map { it.id })
    }
    @Test fun search_uncategorisedLabel() {
        val l = listOf(tx("a", cat = ""), tx("b", cat = "قبوض"))
        assertEquals(listOf("a"), HistorySearch.filter(l, Categories.UNCATEGORIZED_LABEL).map { it.id })
    }
    @Test fun search_noMatch() { assertTrue(HistorySearch.filter(listOf(tx("a")), "zzzz").isEmpty()) }

    // ---- trend ----
    @Test fun trend_lastSixMonthsOldestFirstZeroFilled() {
        val now = ms("2026-11-10T08:00:00Z")           // Aban 1405
        val l = listOf(tx("a", amount = 100, iso = "2026-11-09T10:00:00Z"), tx("b", amount = 300, income = true, iso = "2026-10-10T10:00:00Z"),
            tx("c", amount = 70, iso = "2026-06-01T10:00:00Z"), tx("old", amount = 5, iso = null),
            tx("tr", amount = 999, cat = Categories.TRANSFER, iso = "2026-11-09T10:00:00Z"))
        val t = MonthlyTrend.last(l, 6, now, utc)
        assertEquals(6, t.size)
        assertEquals(listOf(7 to 1405, 8 to 1405), t.takeLast(2).map { it.month to it.year })
        assertEquals("آبان", t.last().monthName)
        assertEquals(100L, t.last().expenseRial)
        assertEquals(300L, t[4].incomeRial)             // Mehr
        assertEquals(0L, t[3].expenseRial)              // Shahrivar empty
    }
    @Test fun trend_crossesYearBoundary() {
        val t = MonthlyTrend.last(emptyList(), 4, ms("2026-04-10T00:00:00Z"), utc)   // Farvardin 1405
        assertEquals(listOf(1404 to 10, 1404 to 11, 1404 to 12, 1405 to 1), t.map { it.year to it.month })
    }

    // ---- budget ----
    @Test fun budget_levels() {
        assertEquals(BudgetLevel.OK, BudgetCalc.levelFor(79, 100))
        assertEquals(BudgetLevel.WARNING, BudgetCalc.levelFor(80, 100))
        assertEquals(BudgetLevel.WARNING, BudgetCalc.levelFor(100, 100))
        assertEquals(BudgetLevel.OVER, BudgetCalc.levelFor(101, 100))
        assertEquals(BudgetLevel.OK, BudgetCalc.levelFor(500, 0))
    }
    @Test fun budget_statusesSortedAndZeroSpend() {
        val spent = listOf(CategoryTotal("قبوض", 90), CategoryTotal("تفریح", 150))
        val s = BudgetCalc.statuses(spent, mapOf("قبوض" to 100L, "تفریح" to 100L, "آموزش" to 200L, "x" to 0L))
        assertEquals(listOf("تفریح", "قبوض", "آموزش"), s.map { it.category })
        assertEquals(BudgetLevel.OVER, s[0].level); assertEquals(150, s[0].percent)
        assertEquals(BudgetLevel.WARNING, s[1].level)
        assertEquals(0L, s[2].spentRial); assertEquals(BudgetLevel.OK, s[2].level)
    }
}
