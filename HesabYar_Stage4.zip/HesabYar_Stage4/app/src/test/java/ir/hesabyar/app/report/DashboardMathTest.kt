package ir.hesabyar.app.report

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DashboardMathTest {
    private fun c(n: String, v: Long) = CategoryTotal(n, v)

    @Test fun emptyAndZero() {
        assertTrue(DashboardMath.donut(emptyList()).isEmpty())
        assertTrue(DashboardMath.donut(listOf(c("a", 0), c("b", -5))).isEmpty())
    }
    @Test fun singleCategoryIs100() {
        val s = DashboardMath.donut(listOf(c("خوراک", 500)))
        assertEquals(1, s.size); assertEquals(100, s[0].percent)
    }
    @Test fun percentsAlwaysSumTo100() {
        for (vals in listOf(listOf(1L, 1L, 1L), listOf(1L, 2L, 3L, 4L, 5L, 6L, 7L), listOf(333L, 333L, 334L), listOf(1L, 1_000_000L))) {
            val s = DashboardMath.donut(vals.mapIndexed { i, v -> c("c$i", v) })
            assertEquals("for $vals", 100, s.sumOf { it.percent })
        }
    }
    @Test fun sortedBiggestFirst() {
        val s = DashboardMath.donut(listOf(c("کم", 10), c("زیاد", 90)))
        assertEquals(listOf("زیاد", "کم"), s.map { it.label }); assertEquals(90, s[0].percent)
    }
    @Test fun extraCategoriesAreMergedIntoOthers() {
        val s = DashboardMath.donut((1..8).map { c("c$it", it * 10L) }, maxSlices = 5)
        assertEquals(5, s.size)
        assertEquals(DashboardMath.OTHERS_LABEL, s.last().label)
        assertEquals(10L + 20 + 30 + 40, s.last().valueRial)   // the 4 smallest
        assertEquals(listOf("c8", "c7", "c6", "c5"), s.take(4).map { it.label })
    }
    @Test fun exactlyMaxSlicesIsNotMerged() {
        val s = DashboardMath.donut((1..5).map { c("c$it", 10L) }, maxSlices = 5)
        assertEquals(5, s.size); assertTrue(s.none { it.label == DashboardMath.OTHERS_LABEL })
    }
}
