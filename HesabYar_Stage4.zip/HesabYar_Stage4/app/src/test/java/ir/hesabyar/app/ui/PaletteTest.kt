package ir.hesabyar.app.ui

import org.junit.Assert.*
import org.junit.Test

class PaletteTest {
    private val both = listOf(Palettes.light, Palettes.dark)
    private fun name(p: Palette) = if (p.dark) "dark" else "light"

    @Test fun bodyTextIsHighContrastOnEverySurface() {
        for (p in both) {
            val page = listOf(p.bgTop, p.bgMid, p.bgBottom)
            val surfaces = listOf(p.card, p.soft, p.sheet, p.navBg)
            page.forEach { assertTrue("${name(p)} ink on page", Palettes.ratio(p.ink, it) >= 7.0) }
            surfaces.forEach { s -> assertTrue("${name(p)} ink on surface ${s.toString(16)}", Palettes.ratio(p.ink, s, p.bgMid) >= 7.0) }
        }
    }
    @Test fun secondaryTextMeetsAA() {
        for (p in both) {
            (listOf(p.bgTop, p.bgMid, p.bgBottom)).forEach { assertTrue("${name(p)} muted on page ${Palettes.ratio(p.muted, it)}", Palettes.ratio(p.muted, it) >= 4.5) }
            listOf(p.card, p.soft, p.sheet, p.navBg).forEach { s -> assertTrue("${name(p)} muted on surface ${Palettes.ratio(p.muted, s, p.bgMid)}", Palettes.ratio(p.muted, s, p.bgMid) >= 4.5) }
        }
    }
    @Test fun statusColoursReadableOnCards() {
        for (p in both) listOf(p.green, p.red, p.amber, p.accent).forEach {
            assertTrue("${name(p)} status ${it.toString(16)} ${Palettes.ratio(it, p.card, p.bgMid)}", Palettes.ratio(it, p.card, p.bgMid) >= 3.0)
        }
    }
    @Test fun textOnAccentButtonsIsReadable() {
        for (p in both) {
            assertTrue("${name(p)} onAccent/accent ${Palettes.ratio(p.onAccent, p.accent)}", Palettes.ratio(p.onAccent, p.accent) >= 3.0)
            assertTrue("${name(p)} onAccent/accent2 ${Palettes.ratio(p.onAccent, p.accent2)}", Palettes.ratio(p.onAccent, p.accent2) >= 3.0)
        }
    }
    @Test fun resolveModes() {
        assertSame(Palettes.light, Palettes.resolve(Palettes.LIGHT, true))
        assertSame(Palettes.dark, Palettes.resolve(Palettes.DARK, false))
        assertSame(Palettes.dark, Palettes.resolve(Palettes.SYSTEM, true))
        assertSame(Palettes.light, Palettes.resolve(Palettes.SYSTEM, false))
        assertSame(Palettes.light, Palettes.resolve(99, false))
    }
    @Test fun ratioSanity() {
        assertEquals(21.0, Palettes.ratio(0xFF000000.toInt(), 0xFFFFFFFF.toInt()), 0.01)
        assertEquals(1.0, Palettes.ratio(0xFF777777.toInt(), 0xFF777777.toInt()), 0.001)
        assertEquals(5, Palettes.light.pastel.size); assertEquals(5, Palettes.dark.pastel.size)
    }
}
