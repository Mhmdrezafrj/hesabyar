package ir.hesabyar.app.plan

import ir.hesabyar.app.Transaction
import ir.hesabyar.app.money.Currency
import ir.hesabyar.app.report.*
import ir.hesabyar.app.widget.Categories
import ir.hesabyar.app.widget.JalaliCalendar
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class PlanningTest {
    private val tz = TimeZone.getTimeZone("UTC")
    private fun ts(y: Int, m: Int, d: Int, h: Int = 12): Long {
        val c = Calendar.getInstance(tz); c.clear(); c.set(y, m - 1, d, h, 0); return c.timeInMillis
    }
    private fun tx(id: String, rial: Long, income: Boolean, t: Long, cat: String = "خوراک", acc: String = "", bal: Long? = null, bank: String = "ملی") =
        Transaction(id, "t$id", bank, rial, "", income, cat, Currency.RIAL.code, "SMS", "", bal, acc, t)
    private val J = JalaliCalendar.Date(1405, 8, 23)

    @Test fun monthLengths() {
        assertEquals(31, JalaliCalendar.monthLength(1405, 1))
        assertEquals(31, JalaliCalendar.monthLength(1405, 6))
        assertEquals(30, JalaliCalendar.monthLength(1405, 7))
        assertEquals(30, JalaliCalendar.monthLength(1405, 11))
        assertEquals(29, JalaliCalendar.monthLength(1404, 12))
        assertEquals(30, JalaliCalendar.monthLength(1403, 12)) // 1403 is leap
        // sanity: total days 365/366
        val sum = (1..12).sumOf { JalaliCalendar.monthLength(1403, it) }
        assertEquals(366, sum)
        assertEquals(365, (1..12).sumOf { JalaliCalendar.monthLength(1404, it) })
    }

    @Test fun allowanceMath() {
        val p = BudgetPlanner.plan(J, mapOf("خوراک" to 6_000_000L, "حمل" to 3_000_000L),
            listOf(CategoryTotal("خوراک", 2_000_000), CategoryTotal("سایر", 9_000_000)), 11_000_000)
        assertTrue(p.hasBudget)
        assertEquals(9_000_000, p.totalLimitRial)
        assertEquals(2_000_000, p.spentInBudgetsRial)      // unbudgeted category not counted
        assertEquals(7_000_000, p.remainingRial)
        assertEquals(8, p.daysLeft)                          // aban has 30 days: 30-23+1
        assertEquals(875_000, p.dailyAllowanceRial)
        assertEquals(11_000_000L * 30 / 23, p.projectedMonthExpenseRial)
        assertTrue(p.projectedOverBudget)
    }

    @Test fun allowanceZeroWhenOverOrNoBudget() {
        val over = BudgetPlanner.plan(J, mapOf("خوراک" to 1_000_000L), listOf(CategoryTotal("خوراک", 3_000_000)), 3_000_000)
        assertEquals(0, over.dailyAllowanceRial); assertTrue(over.remainingRial < 0)
        val none = BudgetPlanner.plan(J, emptyMap(), emptyList(), 5)
        assertFalse(none.hasBudget); assertFalse(none.projectedOverBudget)
        val zeroLimit = BudgetPlanner.plan(J, mapOf("x" to 0L), emptyList(), 0)
        assertFalse(zeroLimit.hasBudget)
    }

    @Test fun lastDayOfMonthHasOneDayLeft() {
        val p = BudgetPlanner.plan(JalaliCalendar.Date(1405, 8, 30), mapOf("a" to 100L), emptyList(), 0)
        assertEquals(1, p.daysLeft); assertEquals(100, p.dailyAllowanceRial)
    }

    @Test fun budgetAlertsDedupe() {
        val st = listOf(BudgetStatus("خوراک", 85, 100, BudgetLevel.WARNING), BudgetStatus("حمل", 10, 100, BudgetLevel.OK), BudgetStatus("تفریح", 120, 100, BudgetLevel.OVER))
        val a = AlertEngine.budgetAlerts(st, 17000, emptySet())
        assertEquals(2, a.size)
        val again = AlertEngine.budgetAlerts(st, 17000, a.map { it.key }.toSet())
        assertTrue(again.isEmpty())
        // WARNING sent, later OVER is a new alert
        val up = AlertEngine.budgetAlerts(listOf(BudgetStatus("خوراک", 120, 100, BudgetLevel.OVER)), 17000, setOf("17000|خوراک|WARNING"))
        assertEquals(1, up.size)
        // next month resets
        assertEquals(1, AlertEngine.budgetAlerts(listOf(BudgetStatus("خوراک", 85, 100, BudgetLevel.WARNING)), 17001, setOf("17000|خوراک|WARNING")).size)
        assertEquals(setOf("17001|a|OVER"), AlertEngine.prune(setOf("17000|a|OVER", "17001|a|OVER"), 17001))
    }

    @Test fun unusualExpense() {
        val hist = List(10) { 100_000L }
        assertTrue(AlertEngine.isUnusualExpense(300_000, hist))
        assertFalse(AlertEngine.isUnusualExpense(299_999, hist))
        assertFalse(AlertEngine.isUnusualExpense(10_000_000, List(9) { 100_000L })) // not enough history
        assertFalse(AlertEngine.isUnusualExpense(5, List(10) { 0L }))
    }

    @Test fun billDueSameMonthAndOverdue() {
        val b = Bill("1", "قسط", 1000, 28)
        val d = BillCalc.due(b, J)
        assertEquals(5, d.daysUntil); assertFalse(d.nextMonth); assertFalse(d.overdue)
        val late = BillCalc.due(Bill("2", "برق", 1, 20), J)
        assertEquals(-3, late.daysUntil); assertTrue(late.overdue)
        assertEquals(0, BillCalc.due(Bill("3", "x", 1, 23), J).daysUntil)
    }

    @Test fun billPaidMovesToNextMonth() {
        val paid = BillCalc.markPaid(Bill("1", "قسط", 1, 20), J)
        val d = BillCalc.due(paid, J)
        assertTrue(d.nextMonth)
        assertEquals((30 - 23) + 20, d.daysUntil)
        // new month: unpaid again
        val nextMonthDay = JalaliCalendar.Date(1405, 9, 1)
        assertFalse(BillCalc.due(paid, nextMonthDay).nextMonth)
    }

    @Test fun billDayClampedToMonthLength() {
        val b = Bill("1", "x", 1, 31)
        val d = BillCalc.due(b, JalaliCalendar.Date(1405, 11, 10)) // bahman = 30 days
        assertEquals(30, d.dueDay); assertEquals(20, d.daysUntil)
        // paid in esfand, next is farvardin 31
        val p = BillCalc.markPaid(b, JalaliCalendar.Date(1404, 12, 5))
        val n = BillCalc.due(p, JalaliCalendar.Date(1404, 12, 5))
        assertEquals(31, n.dueDay); assertEquals(29 - 5 + 31, n.daysUntil)
    }

    @Test fun billOrderingAndUpcoming() {
        val l = listOf(Bill("a", "a", 1, 30), Bill("b", "b", 1, 10), Bill("c", "c", 1, 25))
        assertEquals(listOf("b", "c", "a"), BillCalc.all(l, J).map { it.bill.id })
        assertEquals(listOf("b", "c"), BillCalc.upcoming(l, J, 3).map { it.bill.id })
    }

    @Test fun goals() {
        val g = Goal("1", "سفر", 10_000_000, 2_500_000, 17000 + 4) // deadline key
        assertEquals(25, GoalCalc.percent(g))
        assertEquals(7_500_000, GoalCalc.remaining(g))
        assertEquals(1_500_000L, GoalCalc.monthlyNeeded(g, 17000)) // 5 months incl. this
        assertEquals(7_500_000L, GoalCalc.monthlyNeeded(g.copy(deadlineMonthKey = 16990), 17000)) // past deadline -> all now
        assertNull(GoalCalc.monthlyNeeded(g.copy(deadlineMonthKey = -1), 17000))
        val done = g.copy(savedRial = 10_000_000)
        assertTrue(GoalCalc.done(done)); assertNull(GoalCalc.monthlyNeeded(done, 17000)); assertEquals(100, GoalCalc.percent(done))
        assertEquals(100, GoalCalc.percent(g.copy(savedRial = 99_000_000)))
        assertEquals(0, GoalCalc.percent(g.copy(targetRial = 0)))
        assertEquals(4L, GoalCalc.monthlyNeeded(Goal("x", "x", 10, 0, 17002), 17000)) // ceil(10/3)
    }

    @Test fun debts() {
        val l = listOf(Debt("1", "علی", 500, true, 14050901), Debt("2", "رضا", 300, false), Debt("3", "م", 900, true, settled = true))
        val s = DebtCalc.summary(l)
        assertEquals(500, s.iOweRial); assertEquals(300, s.owedToMeRial)
        assertTrue(DebtCalc.overdue(l[0], 14050923)); assertFalse(DebtCalc.overdue(l[0], 14050901))
        assertFalse(DebtCalc.overdue(l[1], 14059999)); assertFalse(DebtCalc.overdue(l[2], 14059999))
        assertEquals(listOf("1"), DebtCalc.dueSoon(l, 14050923, 14050930).map { it.id })
    }

    @Test fun accountsLatestBalance() {
        val l = listOf(
            tx("1", 10, false, 100, acc = "A", bal = 900), tx("2", 10, false, 200, acc = "A", bal = 800),
            tx("3", 10, true, 150, acc = "B", bal = 5000), tx("4", 10, false, 300, acc = ""), tx("5", 10, false, 400, acc = "C"),
            tx("6", 10, false, 0, acc = "D", bal = 7)
        )
        val b = AccountsOverview.balances(l)
        assertEquals(listOf("B", "A"), b.map { it.accountId })
        assertEquals(800, b[1].balanceRial)
        assertEquals(5800, AccountsOverview.total(b))
    }

    @Test fun accountsConvertTomanBalance() {
        val t = Transaction("1", "x", "ملی", 5, "", false, "", Currency.TOMAN.code, "SMS", "", 100L, "A", 10)
        assertEquals(1000, AccountsOverview.balances(listOf(t))[0].balanceRial)
    }

    @Test fun insightsCategoryChangeAndBiggest() {
        val now = ts(2026, 11, 14)  // jalali 1405/08/23
        val thisM = ts(2026, 11, 5); val prevM = ts(2026, 10, 5)
        val l = listOf(
            tx("1", 5_000_000, false, thisM, "خوراک"), tx("2", 2_000_000, false, prevM, "خوراک"),
            tx("3", 1_000_000, false, thisM, "حمل"), tx("4", 4_000_000, false, prevM, "حمل"),
            tx("5", 9_000_000, true, thisM, "حقوق"), tx("6", 100_000_000, false, thisM, Categories.TRANSFER)
        )
        val r = Insights.compute(l, now, tz)
        assertEquals("خوراک", r.topIncrease!!.category); assertEquals(150, r.topIncrease!!.percent)
        assertEquals("حمل", r.topDecrease!!.category); assertEquals(-75, r.topDecrease!!.percent)
        assertEquals("1", r.biggestExpense!!.id)            // transfer & income excluded
        assertEquals(6_000_000L / 23, r.avgDailyRial)
        assertNull(r.busiestWeekday)                         // fewer than 7 samples
    }

    @Test fun insightsIgnoreTinyCategoriesAndBusiestWeekday() {
        val now = ts(2026, 11, 14)
        val l = ArrayList<Transaction>()
        // 2026-11-07 is a Saturday
        repeat(7) { l.add(tx("s$it", 100_000, false, ts(2026, 11, 7))) }
        l.add(tx("x", 50_000, false, ts(2026, 11, 9)))
        l.add(tx("tiny1", 100, false, ts(2026, 11, 5), "ریز")); l.add(tx("tiny0", 10, false, ts(2026, 10, 5), "ریز"))
        val r = Insights.compute(l, now, tz)
        assertEquals(Calendar.SATURDAY, r.busiestWeekday)
        assertNull(r.topIncrease)
        assertEquals("شنبه", Insights.weekdayName(Calendar.SATURDAY))
        assertEquals("جمعه", Insights.weekdayName(Calendar.FRIDAY))
    }

    @Test fun insightsEmpty() {
        val r = Insights.compute(emptyList(), ts(2026, 11, 14), tz)
        assertNull(r.topIncrease); assertNull(r.biggestExpense); assertEquals(0, r.avgDailyRial)
    }

    @Test fun csvEscapeAndFormulaGuard() {
        assertEquals("a", CsvExport.escape("a"))
        assertEquals("\"a,b\"", CsvExport.escape("a,b"))
        assertEquals("\"a\"\"b\"", CsvExport.escape("a\"b"))
        assertEquals("'=SUM(A1)", CsvExport.escape("=SUM(A1)"))
        assertEquals("'-5", CsvExport.escape("-5"))
        assertEquals("\"x\ny\"", CsvExport.escape("x\ny"))
    }

    @Test fun csvBuild() {
        val l = listOf(
            tx("1", 150_000, false, ts(2026, 11, 14, 9), "خوراک", bal = 2_000_000),
            tx("2", 5_000_000, true, ts(2026, 11, 10, 15), "حقوق"),
            Transaction("3", "قدیمی, ساده", "", 100, "", false, "", Currency.TOMAN.code, "MANUAL", "", null, "", 0L),
            tx("4", 7, false, ts(2026, 11, 12), Categories.TRANSFER)
        )
        val s = CsvExport.build(l, tz)
        assertTrue(s.startsWith("﻿" + CsvExport.HEADER + "\r\n"))
        val lines = s.trimEnd().split("\r\n")
        assertEquals(5, lines.size)
        assertEquals("1405/08/23,09:00,t1,ملی,خوراک,هزینه,-150000,2000000", lines[1])
        assertEquals("1405/08/19,15:00,t2,ملی,حقوق,درآمد,5000000,", lines[3].let { if (it.contains("t2")) it else lines[4] }.let { it })
        assertTrue(lines.any { it.contains("انتقال,-7") })
        assertTrue(lines.last().startsWith(",,\"قدیمی, ساده\",,دسته‌بندی‌نشده,هزینه,-1000,"))
    }
}

class PlanCodecTest {
    private val data = PlanData(
        listOf(Bill("b1", "قسط\tوام", 5_000_000, 5, 17003), Bill("b2", "برق", 1, 31)),
        listOf(Goal("g1", "سفر\nشمال", 10_000_000, 2_000_000, 17010)),
        listOf(Debt("d1", "علی", 700, true, 14050901, false), Debt("d2", "رضا", 5, false, 0, true))
    )

    @Test fun roundTrip() {
        val back = PlanCodec.decode(PlanCodec.encode(data))
        assertEquals(data.bills, back.bills); assertEquals(data.goals, back.goals); assertEquals(data.debts, back.debts)
        assertEquals(0, back.badLines)
    }

    @Test fun badLinesSkippedNotFatal() {
        val txt = "BILL\tb1\tx\tabc\t5\t-1\nBILL\tb2\tok\t10\t40\t-1\nGOAL\tg\tx\t1\n\\q\nBILL\tb3\tok\t10\t5\t-1\nJUNK\n"
        val r = PlanCodec.decode(txt)
        assertEquals(listOf("b3"), r.bills.map { it.id })
        assertEquals(5, r.badLines)
        assertEquals(PlanData(), PlanCodec.decode(""))
    }

    @Test fun mergeKeepsExisting() {
        val cur = PlanData(listOf(Bill("b1", "mine", 1, 1)))
        val m = PlanCodec.mergeMissing(cur, data)
        assertEquals("mine", m.bills.first { it.id == "b1" }.title)
        assertEquals(2, m.bills.size); assertEquals(1, m.goals.size); assertEquals(2, m.debts.size)
    }

    @Test fun backupExtrasRoundTrip() {
        val text = ir.hesabyar.app.backup.BackupCodec.encode(emptyList(), listOf("خوراک"), mapOf("خوراک" to 5L), mapOf("plan" to PlanCodec.encode(data)))
        val d = ir.hesabyar.app.backup.BackupCodec.decode(text).data!!
        assertEquals(data.bills, PlanCodec.decode(d.extras["plan"]!!).bills)
        // old files without extras still decode
        assertTrue(ir.hesabyar.app.backup.BackupCodec.decode(ir.hesabyar.app.backup.BackupCodec.encode(emptyList(), emptyList(), emptyMap())).data!!.extras.isEmpty())
    }
}

class PlanInputTest {
    @Test fun amounts() {
        assertEquals(1_500_000L, PlanInput.amount("۱٬۵۰۰٬۰۰۰"))
        assertEquals(250L, PlanInput.amount(" 250 "))
        assertNull(PlanInput.amount("0")); assertNull(PlanInput.amount("-5")); assertNull(PlanInput.amount("abc")); assertNull(PlanInput.amount(""))
        assertNull(PlanInput.amount("99999999999999999999"))
    }
    @Test fun months() {
        assertEquals(1406 * 12 + 2, PlanInput.monthKey("1406/03"))
        assertEquals(1406 * 12 + 2, PlanInput.monthKey("۱۴۰۶/۳"))
        assertNull(PlanInput.monthKey("1406/13")); assertNull(PlanInput.monthKey("1406")); assertNull(PlanInput.monthKey("12/03")); assertNull(PlanInput.monthKey(""))
        assertEquals("1406/03", PlanInput.monthKeyText(1406 * 12 + 2))
    }
    @Test fun dates() {
        assertEquals(14050915, PlanInput.dateKey("1405/09/15"))
        assertEquals(14050915, PlanInput.dateKey("۱۴۰۵/۹/۱۵"))
        assertNull(PlanInput.dateKey("1405/07/31")); assertNull(PlanInput.dateKey("1404/12/30")); assertEquals(14031230, PlanInput.dateKey("1403/12/30"))
        assertNull(PlanInput.dateKey("1405/00/10")); assertNull(PlanInput.dateKey("x"))
        assertEquals("1405/09/05", PlanInput.dateKeyText(14050905))
    }
    @Test fun dayOfMonth() { assertEquals(31, PlanInput.dayOfMonth("31")); assertNull(PlanInput.dayOfMonth("32")); assertNull(PlanInput.dayOfMonth("0")); assertEquals(5, PlanInput.dayOfMonth("۵")) }
}

class CategorySuggesterTest {
    private fun t(id: String, title: String, rial: Long, income: Boolean, cat: String) =
        Transaction(id, title, "", rial, "", income, cat, Currency.RIAL.code, "SMS", "", null, "", 1)

    @Test fun sameAmountSmsTitleLearnsFromTwo() {
        val h = listOf(t("1", "برداشت از حساب 1", 5_000_000, false, "قسط"), t("2", "برداشت از حساب 1", 5_000_000, false, "قسط"))
        val s = CategorySuggester.suggest(t("9", "برداشت از حساب 1", 5_000_000, false, ""), h)!!
        assertEquals("قسط", s.category); assertEquals("AMOUNT", s.basis)
    }
    @Test fun oneMatchIsNotEnough() {
        assertNull(CategorySuggester.suggest(t("9", "برداشت از حساب 1", 5, false, ""), listOf(t("1", "برداشت از حساب 1", 5, false, "قسط"))))
    }
    @Test fun genericTitleNeedsSameAmount() {
        val h = listOf(t("1", "برداشت از حساب 1", 100, false, "خوراک"), t("2", "برداشت از حساب 1", 200, false, "خوراک"))
        assertNull(CategorySuggester.suggest(t("9", "برداشت از حساب 1", 300, false, ""), h))
    }
    @Test fun manualTitleMatchesAcrossAmounts() {
        val h = listOf(t("1", "نانوایی", 100, false, "خوراک"), t("2", " نانوایی ", 200, false, "خوراک"))
        val s = CategorySuggester.suggest(t("9", "نانوایی", 999, false, ""), h)!!
        assertEquals("خوراک", s.category); assertEquals("TITLE", s.basis)
    }
    @Test fun mixedCategoriesBelowTwoThirdsGiveNothing() {
        val h = listOf(t("1", "کافه", 1, false, "خوراک"), t("2", "کافه", 1, false, "تفریح"), t("3", "کافه", 1, false, "خوراک"), t("4", "کافه", 1, false, "تفریح"))
        assertNull(CategorySuggester.suggest(t("9", "کافه", 1, false, ""), h))
    }
    @Test fun majorityAtTwoThirdsWins() {
        val h = listOf(t("1", "کافه", 1, false, "خوراک"), t("2", "کافه", 1, false, "خوراک"), t("3", "کافه", 1, false, "تفریح"))
        assertEquals("خوراک", CategorySuggester.suggest(t("9", "کافه", 1, false, ""), h)!!.category)
    }
    @Test fun typeMustMatchAndUncategorisedIgnored() {
        val h = listOf(t("1", "حقوق", 1, true, "حقوق"), t("2", "حقوق", 1, true, "حقوق"), t("3", "حقوق", 1, false, ""), t("4", "حقوق", 1, false, ""))
        assertNull(CategorySuggester.suggest(t("9", "حقوق", 1, false, ""), h))
        assertNotNull(CategorySuggester.suggest(t("9", "حقوق", 1, true, ""), h))
    }
    @Test fun amountsCompareInRial() {
        val toman = Transaction("1", "x", "", 500, "", false, "قسط", Currency.TOMAN.code, "SMS", "", null, "", 1)
        val toman2 = toman.copy(id = "2")
        val s = CategorySuggester.suggest(t("9", "x", 5000, false, ""), listOf(toman, toman2))
        assertEquals("قسط", s!!.category)
    }
}

class WidgetContentTest {
    private val tz = TimeZone.getTimeZone("UTC")
    private fun ts(y: Int, m: Int, d: Int, h: Int = 12): Long { val c = Calendar.getInstance(tz); c.clear(); c.set(y, m - 1, d, h, 0); return c.timeInMillis }
    private fun tx(id: String, rial: Long, income: Boolean, t: Long, cat: String = "خوراک") =
        Transaction(id, "t$id", "", rial, "", income, cat, Currency.RIAL.code, "SMS", "", null, "", t)
    private val fa = { s: String -> s }; private val money = { r: Long -> "$r R" }
    private val J = JalaliCalendar.Date(1405, 8, 23)

    @Test fun streakCountsConsecutiveDays() {
        val now = ts(2026, 11, 14)
        val s = Streak.compute(listOf(ts(2026, 11, 14, 8), ts(2026, 11, 13), ts(2026, 11, 12), ts(2026, 11, 10)), now, tz)
        assertEquals(3, s.days); assertTrue(s.loggedToday)
    }
    @Test fun streakAliveThroughYesterday() {
        val s = Streak.compute(listOf(ts(2026, 11, 13), ts(2026, 11, 12)), ts(2026, 11, 14), tz)
        assertEquals(2, s.days); assertFalse(s.loggedToday)
    }
    @Test fun streakBrokenAfterGap() {
        assertEquals(0, Streak.compute(listOf(ts(2026, 11, 11)), ts(2026, 11, 14), tz).days)
        assertEquals(0, Streak.compute(emptyList(), ts(2026, 11, 14), tz).days)
        assertEquals(0, Streak.compute(listOf(0L), ts(2026, 11, 14), tz).days)
    }
    @Test fun streakAcrossMonthBoundary() {
        assertEquals(3, Streak.compute(listOf(ts(2026, 10, 30), ts(2026, 10, 31), ts(2026, 11, 1)), ts(2026, 11, 1, 20), tz).days)
    }
    @Test fun weekBars() {
        val now = ts(2026, 11, 14)
        val l = listOf(tx("1", 100, false, ts(2026, 11, 14, 1)), tx("2", 50, false, ts(2026, 11, 14, 23)), tx("3", 70, false, ts(2026, 11, 8)),
            tx("4", 999, false, ts(2026, 11, 7)), tx("5", 500, true, ts(2026, 11, 14)), tx("6", 400, false, ts(2026, 11, 14), Categories.TRANSFER))
        val w = WeekMath.last7(l, now, tz)
        assertEquals(7, w.expenseRial.size)
        assertEquals(150, w.expenseRial[6]); assertEquals(70, w.expenseRial[0])   // 8 Nov = 6 days back; 7 Nov is out
        assertEquals(Calendar.SATURDAY, w.weekdays[6])                              // 14 Nov 2026 is a Saturday
        assertEquals(Calendar.SUNDAY, w.weekdays[0])
    }
    @Test fun trafficLight() {
        val none = BudgetPlanner.plan(J, emptyMap(), emptyList(), 0)
        assertEquals(Light.NONE, TrafficLight.of(none))
        val red = BudgetPlanner.plan(J, mapOf("a" to 100L), listOf(ir.hesabyar.app.report.CategoryTotal("a", 150)), 150)
        assertEquals(Light.RED, TrafficLight.of(red)); assertEquals(100, TrafficLight.percentUsed(red))
        val amber = BudgetPlanner.plan(J, mapOf("a" to 1000L), listOf(ir.hesabyar.app.report.CategoryTotal("a", 800)), 800)
        assertEquals(Light.AMBER, TrafficLight.of(amber))
        val green = BudgetPlanner.plan(J, mapOf("a" to 1000L), listOf(ir.hesabyar.app.report.CategoryTotal("a", 100)), 100)
        assertEquals(Light.GREEN, TrafficLight.of(green)); assertEquals(10, TrafficLight.percentUsed(green))
    }
    @Test fun urgentPriorityOrder() {
        val late = Bill("1", "قسط", 5, 20); val soon = Bill("2", "برق", 6, 24)
        val u = UrgentPicker.pick(listOf(soon, late), emptyList(), J, 3, listOf("خوراک"), fa, money)
        assertEquals(UrgentLevel.HIGH, u.level); assertTrue(u.title.contains("قسط")); assertTrue(u.title.contains("عقب"))
        val u2 = UrgentPicker.pick(listOf(soon), emptyList(), J, 3, listOf("خوراک"), fa, money)
        assertEquals(UrgentLevel.HIGH, u2.level); assertTrue(u2.title.contains("برق"))
        val u3 = UrgentPicker.pick(emptyList(), emptyList(), J, 3, listOf("خوراک"), fa, money)
        assertEquals(UrgentLevel.MEDIUM, u3.level); assertTrue(u3.title.contains("خوراک"))
        val u4 = UrgentPicker.pick(emptyList(), emptyList(), J, 3, emptyList(), fa, money)
        assertTrue(u4.title.contains("3")); assertEquals(UrgentTarget.MAIN, u4.target)
        val none = UrgentPicker.pick(emptyList(), emptyList(), J, 0, emptyList(), fa, money)
        assertEquals(UrgentLevel.NONE, none.level)
    }
    @Test fun urgentDebts() {
        val od = Debt("d", "علی", 9, true, 14050801)
        val u = UrgentPicker.pick(emptyList(), listOf(od), J, 0, emptyList(), fa, money)
        assertEquals(UrgentLevel.HIGH, u.level); assertTrue(u.title.contains("علی"))
        val soonD = Debt("e", "رضا", 9, false, 14050824)
        assertEquals(UrgentLevel.MEDIUM, UrgentPicker.pick(emptyList(), listOf(soonD), J, 0, emptyList(), fa, money).level)
        val settled = od.copy(settled = true)
        assertEquals(UrgentLevel.NONE, UrgentPicker.pick(emptyList(), listOf(settled), J, 0, emptyList(), fa, money).level)
    }
    @Test fun nudgesPersonalisedFirstAndRotate() {
        val f = NudgeFacts(false, 0, 2, 500, 100)
        val c = Nudges.candidates(f, fa, money)
        assertTrue(c[0].contains("ثبت نکرده"))
        assertTrue(c.any { it.contains("2 تراکنش") }); assertTrue(c.any { it.contains("500 R") }); assertTrue(c.any { it.contains("100 R") })
        assertEquals(Nudges.pick(c, 100), Nudges.pick(c, 100))
        assertNotEquals(Nudges.pick(c, 100), Nudges.pick(c, 101))
        assertEquals(c[0], Nudges.pick(c, c.size.toLong() * 7))
        assertEquals("", Nudges.pick(emptyList(), 5))
        assertNotNull(Nudges.pick(c, -3))
    }
    @Test fun nudgesQuietWhenNothingToSay() {
        val c = Nudges.candidates(NudgeFacts(true, 0, 0, 0, 0), fa, money)
        assertTrue(c.none { it.contains("ثبت نکرده") || it.contains("منتظر") || it.contains("دیروز") })
        assertTrue(c.isNotEmpty())
        assertTrue(Nudges.candidates(NudgeFacts(true, 5, 0, 0, 0), fa, money).any { it.contains("5 روز") })
    }
}
