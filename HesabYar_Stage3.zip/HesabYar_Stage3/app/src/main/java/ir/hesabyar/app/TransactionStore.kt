package ir.hesabyar.app

import android.content.Context
import ir.hesabyar.app.money.Currency
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object TransactionStore {
    private const val PREFS = "hesabyar_local"
    private const val KEY = "transactions"

    fun all(context: Context): MutableList<Transaction> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw == null) {
            val samples = mutableListOf(
                Transaction("sample-1", "خرید سوپرمارکت", "بانک ملت", 320000, "امروز ۱۹:۴۷", false),
                Transaction("sample-2", "واریز حقوق", "بانک ملی", 8500000, "امروز ۱۰:۲۵", true),
                Transaction("sample-3", "هزینه تاکسی", "بانک سامان", 95000, "دیروز ۱۸:۱۰", false)
            )
            save(context, samples)
            return samples
        }
        val result = mutableListOf<Transaction>()
        val array = JSONArray(raw)
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(Transaction(
                id = o.getString("id"),
                title = o.getString("title"),
                bank = o.getString("bank"),
                amount = o.getLong("amount"),
                time = o.getString("time"),
                isIncome = o.getBoolean("income"),
                category = o.optString("category", ""),
                // Old rows have no currency: they were entered in Toman. Same number, no conversion.
                currency = Currency.fromCode(o.optString("currency", "")).code,
                source = o.optString("source", "MANUAL"),
                sourceRef = o.optString("sourceRef", ""),
                balance = if (o.has("balance") && !o.isNull("balance")) o.getLong("balance") else null,
                accountId = o.optString("accountId", ""),
                timestamp = o.optLong("ts", 0L)
            ))
        }
        return result
    }

    /** Uncategorised transactions, newest first. */
    fun pending(context: Context) =
        all(context).filter { it.category.isBlank() }.sortedByDescending { it.timestamp }

    fun save(context: Context, transactions: List<Transaction>) {
        val array = JSONArray()
        transactions.forEach { t ->
            array.put(JSONObject().apply {
                put("id", t.id); put("title", t.title); put("bank", t.bank)
                put("amount", t.amount); put("time", t.time)
                put("income", t.isIncome); put("category", t.category)
                put("currency", t.currency); put("source", t.source)
                put("sourceRef", t.sourceRef); put("accountId", t.accountId)
                put("ts", t.timestamp)
                t.balance?.let { put("balance", it) }
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }

    /** Manual entry. [amount] is stored exactly as typed, in [currency]; no conversion. */
    fun add(context: Context, title: String, amount: Long, income: Boolean, currency: Currency = Currency.TOMAN) {
        val items = all(context)
        items.add(0, Transaction(
            id = UUID.randomUUID().toString(),
            title = title.ifBlank { "تراکنش دستی" },
            bank = "ثبت دستی",
            amount = amount,
            time = "همین الان",
            isIncome = income,
            currency = currency.code,
            source = "MANUAL",
            timestamp = System.currentTimeMillis()
        ))
        save(context, items)
    }

    /** Adds a transaction parsed from an SMS unless one with the same [Transaction.sourceRef] exists. */
    fun addFromSms(context: Context, tx: Transaction): Boolean {
        val items = all(context)
        if (tx.sourceRef.isNotBlank() && items.any { it.sourceRef == tx.sourceRef }) return false
        items.add(0, tx)
        save(context, items)
        return true
    }

    fun categorize(context: Context, id: String, category: String) {
        val items = all(context).map {
            if (it.id == id) it.copy(category = category) else it
        }
        save(context, items)
    }
}
