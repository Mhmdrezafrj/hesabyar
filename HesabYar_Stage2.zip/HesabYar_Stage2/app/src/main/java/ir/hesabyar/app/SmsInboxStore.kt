package ir.hesabyar.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest

/** Stores only likely financial/bank SMS candidates. No SMS content leaves this device. */
class SmsInboxStore(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE sms_inbox (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fingerprint TEXT NOT NULL UNIQUE,
            sender TEXT NOT NULL,
            body TEXT NOT NULL,
            received_at INTEGER NOT NULL,
            source TEXT NOT NULL,
            review_state TEXT NOT NULL DEFAULT 'NEW'
        )""")
        db.execSQL("CREATE INDEX idx_sms_received_at ON sms_inbox(received_at DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Stage 2 is the first SMS schema. Future schema changes will use explicit migrations.
    }

    fun insertCandidate(sender: String?, body: String?, receivedAt: Long, source: String): Boolean {
        val safeSender = sender.orEmpty().trim().ifBlank { "فرستنده نامشخص" }
        val safeBody = body.orEmpty().trim()
        if (safeBody.isBlank() || !SmsCandidateFilter.isLikelyFinancial(safeSender, safeBody)) return false
        val fingerprint = fingerprint(safeSender, safeBody, receivedAt)
        val values = ContentValues().apply {
            put("fingerprint", fingerprint)
            put("sender", safeSender)
            put("body", safeBody)
            put("received_at", receivedAt)
            put("source", source)
            put("review_state", "NEW")
        }
        val id = writableDatabase.insertWithOnConflict("sms_inbox", null, values, SQLiteDatabase.CONFLICT_IGNORE)
        return id != -1L
    }

    fun latest(limit: Int = 300): List<RawSms> {
        val result = mutableListOf<RawSms>()
        readableDatabase.query("sms_inbox", arrayOf("id", "sender", "body", "received_at", "source", "review_state"),
            null, null, null, null, "received_at DESC", limit.toString()).use { c ->
            while (c.moveToNext()) result.add(RawSms(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getString(4), c.getString(5)))
        }
        return result
    }

    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM sms_inbox", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }

    fun delete(id: Long) { writableDatabase.delete("sms_inbox", "id=?", arrayOf(id.toString())) }

    private fun fingerprint(sender: String, body: String, time: Long): String {
        val normalized = (sender.trim() + "|" + body.replace(Regex("\\s+"), " ").trim() + "|" + time).toByteArray(Charsets.UTF_8)
        return MessageDigest.getInstance("SHA-256").digest(normalized).joinToString("") { "%02x".format(it) }
    }

    companion object { private const val DB_NAME = "hesabyar_sms.db"; private const val DB_VERSION = 1 }
}

data class RawSms(val id: Long, val sender: String, val body: String, val receivedAt: Long, val source: String, val reviewState: String)

/** Broad intake filter only. It is not the bank/parser engine; Stage 3 adds bank-specific parsing. */
object SmsCandidateFilter {
    private val terms = listOf(
        "برداشت", "واریز", "خرید", "انتقال", "تراکنش", "مانده", "موجودی", "کارت",
        "پرداخت", "شاپرک", "شتاب", "مبلغ", "حساب", "بانک", "رسید", "شارژ", "تومان", "ریال",
        "withdraw", "deposit", "transaction", "balance", "purchase", "transfer", "irr", "rial"
    )
    fun isLikelyFinancial(sender: String, body: String): Boolean {
        val text = normalize(sender + " " + body)
        return terms.any { text.contains(normalize(it)) } && body.length >= 5
    }
    private fun normalize(value: String): String = value
        .replace('ي', 'ی').replace('ك', 'ک')
        .replace('۰','0').replace('۱','1').replace('۲','2').replace('۳','3').replace('۴','4')
        .replace('۵','5').replace('۶','6').replace('۷','7').replace('۸','8').replace('۹','9')
        .lowercase()
}
