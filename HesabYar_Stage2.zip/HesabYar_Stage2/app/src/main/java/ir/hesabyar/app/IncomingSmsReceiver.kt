package ir.hesabyar.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsMessage

/** Receives newly delivered SMS broadcasts. Only candidate financial messages are persisted. */
class IncomingSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        try {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            if (messages.isNullOrEmpty()) return
            // A multipart SMS can arrive as several PDUs; combine segments from the same sender.
            val grouped = messages.groupBy { it.originatingAddress.orEmpty() }
            val store = SmsInboxStore(context.applicationContext)
            grouped.forEach { (sender, parts) ->
                val body = parts.sortedBy { it.timestampMillis }.joinToString("") { it.messageBody.orEmpty() }
                val timestamp = parts.minOfOrNull { it.timestampMillis } ?: System.currentTimeMillis()
                store.insertCandidate(sender, body, timestamp, "LIVE_SMS")
            }
            store.close()
        } catch (_: SecurityException) {
            // Permission may have been revoked between delivery and processing.
        } catch (_: Exception) {
            // A malformed or vendor-specific SMS must not crash the receiving process.
        }
    }
}
