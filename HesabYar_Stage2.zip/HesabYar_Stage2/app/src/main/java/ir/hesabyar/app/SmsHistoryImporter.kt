package ir.hesabyar.app

import android.content.Context
import android.provider.Telephony

object SmsHistoryImporter {
    data class ImportResult(val scanned: Int, val saved: Int, val duplicatesOrSkipped: Int)

    /** Imports at most 1000 recent inbox messages from the last 90 days. */
    fun importRecent(context: Context): ImportResult {
        val since = System.currentTimeMillis() - 90L * 24 * 60 * 60 * 1000
        val projection = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE)
        var scanned = 0
        var saved = 0
        var skipped = 0
        val store = SmsInboxStore(context.applicationContext)
        try {
            context.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                projection,
                "${Telephony.Sms.DATE} >= ?",
                arrayOf(since.toString()),
                "${Telephony.Sms.DATE} DESC"
            )?.use { cursor ->
                val addressIndex = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
                val bodyIndex = cursor.getColumnIndex(Telephony.Sms.BODY)
                val dateIndex = cursor.getColumnIndex(Telephony.Sms.DATE)
                while (cursor.moveToNext() && scanned < 1000) {
                    scanned++
                    val address = if (addressIndex >= 0) cursor.getString(addressIndex) else null
                    val body = if (bodyIndex >= 0) cursor.getString(bodyIndex) else null
                    val date = if (dateIndex >= 0) cursor.getLong(dateIndex) else System.currentTimeMillis()
                    if (store.insertCandidate(address, body, date, "HISTORY_IMPORT")) saved++ else skipped++
                }
            }
        } finally { store.close() }
        return ImportResult(scanned, saved, skipped)
    }
}
